package udistrital.edu.co.model;

import java.util.ArrayList;

public class Vivero {
    private ArrayList<PlantaFlyweight> lista = new ArrayList<>();
    private PlantaFactory factory = new PlantaFactory();

    public void agregarPlanta(String especie, String color, String tamaño, int cantidad) {
        PlantaFlyweight planta = factory.getPlanta(especie, color);
        lista.add(planta);
    }

    public String imprimirPlanta(String especie, String color, String tamaño, int cantidad) {
        PlantaFlyweight planta = factory.getPlanta(especie, color);
        PlantaDetalle detalle = new PlantaDetalle(tamaño, cantidad);
        return planta.toString() + " | " + detalle.toString();
    }
}