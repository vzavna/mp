package udistrital.edu.co.controller;

import udistrital.edu.co.model.Vivero;
import udistrital.edu.co.view.Vista;

public class Controller {
    private Vista vista;
    private Vivero vivero;

    public Controller() {
        vista = new Vista();
        vivero = new Vivero();
    }

    public void run() {
        vista.mostrarInformacion("=== Registro de plantas ===");

        String especie = vista.leerCadenaDeTexto("Especie: ");
        String color = vista.leerCadenaDeTexto("Color: ");
        String tamaño = vista.leerCadenaDeTexto("Tamaño (pequeña, mediana, grande): ");
        int cantidad = vista.leerEntero("Cantidad: ");

        vivero.agregarPlanta(especie, color, tamaño, cantidad);
        String resultado = vivero.imprimirPlanta(especie, color, tamaño, cantidad);

        vista.mostrarInformacion("Planta registrada: " + resultado);
    }
}