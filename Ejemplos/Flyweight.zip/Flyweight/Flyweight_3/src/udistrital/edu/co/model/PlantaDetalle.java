package udistrital.edu.co.model;

public class PlantaDetalle {
    private String tamaño;
    private int cantidad;

    public PlantaDetalle(String tamaño, int cantidad) {
        this.tamaño = tamaño;
        this.cantidad = cantidad;
    }

    @Override
    public String toString() {
        return tamaño + ", x" + cantidad;
    }
}