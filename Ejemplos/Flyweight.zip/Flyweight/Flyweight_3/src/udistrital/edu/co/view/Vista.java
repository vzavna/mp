package udistrital.edu.co.view;

import java.util.Scanner;

public class Vista {
    private Scanner sc = new Scanner(System.in);

    public String leerCadenaDeTexto(String mensaje) {
        System.out.print(mensaje);
        return sc.nextLine();
    }

    public int leerEntero(String mensaje) {
        System.out.print(mensaje);
        return Integer.parseInt(sc.nextLine());
    }

    public void mostrarInformacion(String mensaje) {
        System.out.println(mensaje);
    }
}