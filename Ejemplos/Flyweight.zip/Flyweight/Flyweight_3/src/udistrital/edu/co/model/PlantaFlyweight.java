package udistrital.edu.co.model;

public class PlantaFlyweight {
    private String especie;
    private String color;

    public PlantaFlyweight(String especie, String color) {
        this.especie = especie;
        this.color = color;
    }

    @Override
    public String toString() {
        return especie + " de color " + color;
    }
}