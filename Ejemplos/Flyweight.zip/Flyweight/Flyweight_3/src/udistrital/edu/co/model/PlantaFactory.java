package udistrital.edu.co.model;

import java.util.HashMap;

public class PlantaFactory {
    private HashMap<String, PlantaFlyweight> mapa = new HashMap<>();

    public PlantaFlyweight getPlanta(String especie, String color) {
        String clave = especie + "-" + color;
        if (!mapa.containsKey(clave)) {
            mapa.put(clave, new PlantaFlyweight(especie, color));
        }
        return mapa.get(clave);
    }
}