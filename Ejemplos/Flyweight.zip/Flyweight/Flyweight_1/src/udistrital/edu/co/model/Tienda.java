package udistrital.edu.co.model;

import java.util.ArrayList;

public class Tienda {
    private ArrayList<CafeFlyweight> lista = new ArrayList<>();
    private CafeFactory factory = new CafeFactory();

    public void agregarCafe(String tipo, String leche, String tamaño, int azucar) {
        CafeFlyweight cafe = factory.getCafe(tipo, leche);
        lista.add(cafe);
    }

    public String imprimirCafe(String tipo, String leche, String tamaño, int azucar) {
        CafeFlyweight cafe = factory.getCafe(tipo, leche);
        CafeDetalle detalle = new CafeDetalle(tamaño, azucar);
        return cafe.toString() + " | " + detalle.toString();
    }
}