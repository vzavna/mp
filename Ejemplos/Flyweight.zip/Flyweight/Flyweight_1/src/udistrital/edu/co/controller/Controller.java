package udistrital.edu.co.controller;

import udistrital.edu.co.model.Tienda;
import udistrital.edu.co.view.Vista;

public class Controller {
    private Vista vista;
    private Tienda tienda;

    public Controller() {
        vista = new Vista();
        tienda = new Tienda();
    }

    public void run() {
        vista.mostrarInformacion("=== Bienvenido a la cafetería ===");

        String tipo = vista.leerCadenaDeTexto("Tipo de café (ej: Espresso): ");
        String leche = vista.leerCadenaDeTexto("Tipo de leche (ej: deslactosada): ");
        String tam = vista.leerCadenaDeTexto("Tamaño (pequeño, mediano, grande): ");
        int azucar = vista.leerEntero("Cantidad de azúcar: ");

        tienda.agregarCafe(tipo, leche, tam, azucar);
        String resultado = tienda.imprimirCafe(tipo, leche, tam, azucar);

        vista.mostrarInformacion("Café agregado: " + resultado);
    }
}