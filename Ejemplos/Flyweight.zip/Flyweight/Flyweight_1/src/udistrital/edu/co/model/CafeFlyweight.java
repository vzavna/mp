package udistrital.edu.co.model;

public class CafeFlyweight {
    private String tipo;
    private String leche;

    public CafeFlyweight(String tipo, String leche) {
        this.tipo = tipo;
        this.leche = leche;
    }

    @Override
    public String toString() {
        return tipo + " con " + leche;
    }

    public String getTipo() { return tipo; }
    public String getLeche() { return leche; }
}