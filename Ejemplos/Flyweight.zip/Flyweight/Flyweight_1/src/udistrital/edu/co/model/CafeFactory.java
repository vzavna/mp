package udistrital.edu.co.model;

import java.util.HashMap;


public class CafeFactory {
    private HashMap<String, CafeFlyweight> map = new HashMap<>();

    public CafeFlyweight getCafe(String tipo, String leche) {
        String clave = tipo + "-" + leche;
        if (!map.containsKey(clave)) {
            map.put(clave, new CafeFlyweight(tipo, leche));
        }
        return map.get(clave);
    }
}