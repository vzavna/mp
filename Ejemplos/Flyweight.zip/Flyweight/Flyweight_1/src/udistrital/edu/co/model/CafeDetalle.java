package udistrital.edu.co.model;

public class CafeDetalle {
    private String tamaño;
    private int azucar;

    public CafeDetalle(String tamaño, int azucar) {
        this.tamaño = tamaño;
        this.azucar = azucar;
    }

    @Override
    public String toString() {
        return tamaño + ", " + azucar + " cucharadas de azúcar";
    }

    public String getTamaño() { return tamaño; }
    public int getAzucar() { return azucar; }
}