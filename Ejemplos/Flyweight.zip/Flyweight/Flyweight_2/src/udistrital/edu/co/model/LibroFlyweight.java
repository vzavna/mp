package udistrital.edu.co.model;

public class LibroFlyweight {
    private String titulo;
    private String autor;

    public LibroFlyweight(String titulo, String autor) {
        this.titulo = titulo;
        this.autor = autor;
    }

    @Override
    public String toString() {
        return "\"" + titulo + "\" por " + autor;
    }

    public String getTitulo() { return titulo; }
    public String getAutor() { return autor; }
}