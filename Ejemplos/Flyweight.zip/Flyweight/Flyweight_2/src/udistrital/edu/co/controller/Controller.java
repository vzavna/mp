package udistrital.edu.co.controller;

import udistrital.edu.co.model.Biblioteca;
import udistrital.edu.co.view.Vista;

public class Controller {
    private Vista vista;
    private Biblioteca biblioteca;

    public Controller() {
        vista = new Vista();
        biblioteca = new Biblioteca();
    }

    public void run() {
        vista.mostrarInformacion("=== Registro de libros en la biblioteca ===");

        String titulo = vista.leerCadenaDeTexto("Título: ");
        String autor = vista.leerCadenaDeTexto("Autor: ");
        String estado = vista.leerCadenaDeTexto("Estado (nuevo/usado): ");
        String ubicacion = vista.leerCadenaDeTexto("Ubicación (estante/caja): ");

        biblioteca.agregarLibro(titulo, autor, estado, ubicacion);
        String resultado = biblioteca.imprimirLibro(titulo, autor, estado, ubicacion);

        vista.mostrarInformacion("Libro agregado: " + resultado);
    }
}