package udistrital.edu.co.model;

public class LibroDetalle {
    private String estado;
    private String ubicacion;

    public LibroDetalle(String estado, String ubicacion) {
        this.estado = estado;
        this.ubicacion = ubicacion;
    }

    @Override
    public String toString() {
        return estado + ", en " + ubicacion;
    }
}