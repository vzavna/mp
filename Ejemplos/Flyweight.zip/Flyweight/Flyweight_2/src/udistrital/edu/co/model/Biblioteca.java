package udistrital.edu.co.model;

import java.util.ArrayList;

public class Biblioteca {
    private ArrayList<LibroFlyweight> lista = new ArrayList<>();
    private LibroFactory factory = new LibroFactory();

    public void agregarLibro(String titulo, String autor, String estado, String ubicacion) {
        LibroFlyweight libro = factory.getLibro(titulo, autor);
        lista.add(libro);
    }

    public String imprimirLibro(String titulo, String autor, String estado, String ubicacion) {
        LibroFlyweight libro = factory.getLibro(titulo, autor);
        LibroDetalle detalle = new LibroDetalle(estado, ubicacion);
        return libro + " | " + detalle;
    }
}