package udistrital.edu.co.model;

import java.util.HashMap;

public class LibroFactory {
    private HashMap<String, LibroFlyweight> libros = new HashMap<>();

    public LibroFlyweight getLibro(String titulo, String autor) {
        String clave = titulo + "-" + autor;
        if (!libros.containsKey(clave)) {
            libros.put(clave, new LibroFlyweight(titulo, autor));
        }
        return libros.get(clave);
    }
}