package co.edu.udistrital.model;

import co.edu.udistrital.model.abstracto.Semaforo;

public class EnRojo implements Semaforo{

	@Override
	public String accionColor() {
		return "\n\u2022 Se debe para el vehiculo por completo!";
	}

}
