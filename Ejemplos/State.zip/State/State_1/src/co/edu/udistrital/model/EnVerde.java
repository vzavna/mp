package co.edu.udistrital.model;

import co.edu.udistrital.model.abstracto.Semaforo;

public class EnVerde implements Semaforo{

	@Override
	public String accionColor() {
		return "\n\u2022 Se puede avanzar con tranquilidad";
	}

}
