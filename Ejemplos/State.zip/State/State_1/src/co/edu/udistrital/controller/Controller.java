package co.edu.udistrital.controller;

import co.edu.udistrital.model.EnAmarillo;
import co.edu.udistrital.model.EnRojo;
import co.edu.udistrital.model.EnVerde;
import co.edu.udistrital.model.abstracto.Semaforo;
import co.edu.udistrital.view.Vista;

public class Controller {
	private Vista vista;
	
	public Controller()
	{
		vista = new Vista();
	}
	
	public void run()
	{
		vista.mostrarInformacion("Acciones segun el color de un semaforo");
		
		Semaforo semaforo;
		
		while(true)
		{
			String estado = vista.leerCadenaDeTexto("En que color esta el semaforo?(Rojo, Amarillo, Verde)");
			
			if(estado.toLowerCase().equals("rojo"))
			{
				semaforo = new EnRojo();
				vista.mostrarInformacion(semaforo.accionColor());
			}
			else if(estado.toLowerCase().equals("amarillo"))
			{
				semaforo = new EnAmarillo();
				vista.mostrarInformacion(semaforo.accionColor());
			}
			else if(estado.toLowerCase().equals("verde"))
			{
				semaforo = new EnVerde();
				vista.mostrarInformacion(semaforo.accionColor());
			}
			else
			{
				vista.mostrarInformacion("Color No Reconocido");
			}
			
			int cont = Integer.parseInt(vista.leerCadenaDeTexto("Desea continuar en el programa?"
					+ "\n1. si"
					+ "\n2. no"));
			
			if(cont == 1)
			{
				cont = 0;
				continue;
			}
			else
			{
				vista.mostrarInformacion("Gracias por usar el programa!");
				System.exit(0);
			}
		}
	}
}
