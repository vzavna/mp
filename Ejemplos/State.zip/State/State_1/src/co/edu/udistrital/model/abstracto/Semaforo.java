package co.edu.udistrital.model.abstracto;

public interface Semaforo {
	public String accionColor();
}
