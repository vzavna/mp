package co.edu.udistrital.model;

import co.edu.udistrital.model.abstracto.Semaforo;

public class EnAmarillo implements Semaforo{

	@Override
	public String accionColor() {
		return "\n\u2022 Se debe reducir la velocidad para poder parar";
	}


}
