package co.edu.udistrital.model;

import co.edu.udistrital.model.abstracto.Jugador;

public class EnDefensa implements Jugador{

	@Override
	public String estrategiaDeJuego() {
		return "\n\u2022 Bajar y presionar hasta obtener la posesion del balon";
	}
	

}
