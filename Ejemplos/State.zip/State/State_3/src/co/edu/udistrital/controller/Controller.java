package co.edu.udistrital.controller;

import co.edu.udistrital.model.EnAtaque;
import co.edu.udistrital.model.EnDefensa;
import co.edu.udistrital.model.abstracto.Jugador;
import co.edu.udistrital.view.Vista;

public class Controller {
	private Vista vista;
	
	public Controller()
	{
		vista = new Vista();
	}
	
	public void run()
	{
		vista.mostrarInformacion("Acciones de un jugador de futbol");
		
		Jugador jugador;
		
		while(true)
		{
			String estado = vista.leerCadenaDeTexto("El quipo tiene el balon?(si, no)");
			
			if(estado.toLowerCase().equals("si"))
			{
				jugador = new EnAtaque();
				vista.mostrarInformacion(jugador.estrategiaDeJuego());
			}
			else if(estado.toLowerCase().equals("no"))
			{
				jugador = new EnDefensa();
				vista.mostrarInformacion(jugador.estrategiaDeJuego());
			}
			else
			{
				vista.mostrarInformacion("Era un pregunta de si o no :p");
			}
			
			int cont = Integer.parseInt(vista.leerCadenaDeTexto("Desea continuar en el programa?"
					+ "\n1. si"
					+ "\n2. no"));
			
			if(cont == 1)
			{
				cont = 0;
				continue;
			}
			else
			{
				vista.mostrarInformacion("Gracias por usar el programa!");
				System.exit(0);
			}
		}
	}
}
