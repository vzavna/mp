package co.edu.udistrital.model;

import co.edu.udistrital.model.abstracto.Jugador;

public class EnAtaque implements Jugador{

	@Override
	public String estrategiaDeJuego() {
		return "\n\u2022 Crear situaciones de gol";
	}
	
}
