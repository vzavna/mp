package co.edu.udistrital.model.abstracto;

public interface Jugador {
	public String estrategiaDeJuego();
}
