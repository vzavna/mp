package co.edu.udistrital.model;

import co.edu.udistrital.model.abstracto.Reproductor;

public class EnReproducir implements Reproductor{

	@Override
	public String accion() {
		return "\n\u2022 Se esta reproduciendo el contenido con normalidad";
	}

}
