package co.edu.udistrital.model;

import co.edu.udistrital.model.abstracto.Reproductor;

public class EnApagado implements Reproductor{

	@Override
	public String accion() {
		return "\n\u2022 Se esta apagando el dispositivo, deteniendo todo el contenido";
	}

}
