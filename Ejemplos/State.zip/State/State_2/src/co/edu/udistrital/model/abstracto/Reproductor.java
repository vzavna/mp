package co.edu.udistrital.model.abstracto;

public interface Reproductor {
	public String accion();
}	
