package co.edu.udistrital.controller;

import co.edu.udistrital.model.EnApagado;
import co.edu.udistrital.model.EnPausa;
import co.edu.udistrital.model.EnReproducir;
import co.edu.udistrital.model.abstracto.Reproductor;
import co.edu.udistrital.view.Vista;

public class Controller {
	private Vista vista;
	
	public Controller()
	{
		vista = new Vista();
	}
	
	public void run()
	{
		vista.mostrarInformacion("Acciones de un reproductor de contenido");
		
		Reproductor reproductor;
		
		while(true)
		{
			String estado = vista.leerCadenaDeTexto("En que estado esta el reproductor?(reproduccion, pausa, apagado)");
			
			if(estado.toLowerCase().equals("reproduciendo"))
			{
				reproductor = new EnReproducir();
				vista.mostrarInformacion(reproductor.accion());
			}
			else if(estado.toLowerCase().equals("pausa"))
			{
				reproductor = new EnPausa();
				vista.mostrarInformacion(reproductor.accion());
			}
			else if(estado.toLowerCase().equals("apagado"))
			{
				reproductor = new EnApagado();
				vista.mostrarInformacion(reproductor.accion());
			}
			else
			{
				vista.mostrarInformacion("El Reprductor no reconoce ese estado!");
			}
			
			int cont = Integer.parseInt(vista.leerCadenaDeTexto("Desea continuar en el programa?"
					+ "\n1. si"
					+ "\n2. no"));
			
			if(cont == 1)
			{
				cont = 0;
				continue;
			}
			else
			{
				vista.mostrarInformacion("Gracias por usar el programa!");
				System.exit(0);
			}
		}
	}
		
}
