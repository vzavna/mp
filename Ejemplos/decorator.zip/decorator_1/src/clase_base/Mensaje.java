package clase_base;

public interface Mensaje {
    String getTexto();
}
