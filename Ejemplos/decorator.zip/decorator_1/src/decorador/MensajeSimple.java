package decorador;

import clase_base.Mensaje;

public class MensajeSimple implements Mensaje {
    private String texto;

    public MensajeSimple(String texto) {
        this.texto = texto;
    }

    public String getTexto() {
        return texto;
    }
}