package decorador;

import abstraccion.MensajeDecorador;
import clase_base.Mensaje;

public class SubrayadoDecorador extends MensajeDecorador {
    public SubrayadoDecorador(Mensaje mensaje) {
        super(mensaje);
    }

    public String getTexto() {
        return "<u>" + mensaje.getTexto() + "</u>";
    }
}