package decorador;

import abstraccion.MensajeDecorador;
import clase_base.Mensaje;

public class NegritaDecorador extends MensajeDecorador {
    public NegritaDecorador(Mensaje mensaje) {
        super(mensaje);
    }

    public String getTexto() {
        return "<b>" + mensaje.getTexto() + "</b>";
    }
}
