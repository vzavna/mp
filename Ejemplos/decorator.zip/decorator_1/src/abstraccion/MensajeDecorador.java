package abstraccion;

import clase_base.Mensaje;

public abstract class MensajeDecorador implements Mensaje {
    protected Mensaje mensaje;

    public MensajeDecorador(Mensaje mensaje) {
        this.mensaje = mensaje;
    }
}