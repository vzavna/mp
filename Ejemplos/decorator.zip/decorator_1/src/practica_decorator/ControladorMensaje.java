package practica_decorator;

import clase_base.Mensaje;
import decorador.MensajeSimple;
import decorador.NegritaDecorador;
import decorador.SubrayadoDecorador;

public class ControladorMensaje {
    public static void main(String[] args) {
        Mensaje mensaje = new MensajeSimple("tuchi tuchi");
        mensaje = new NegritaDecorador(mensaje);
        mensaje = new SubrayadoDecorador(mensaje);

        System.out.println(mensaje.getTexto());
    }
}