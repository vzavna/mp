package decorador;

import clase_base.Cafe;
import abstraccion.CafeDecorador;

public class ChocolateDecorador extends CafeDecorador {
    public ChocolateDecorador(Cafe cafe) {
        super(cafe);
    }

    public String getDescripcion() {
        return cafe.getDescripcion() + ", chocolate";
    }

    public double getCosto() {
        return cafe.getCosto() + 3.0;
    }
}
