package decorador;

import clase_base.Cafe;

public class CafeBase implements Cafe {
    public String getDescripcion() {
        return "Café";
    }

    public double getCosto() {
        return 10.0;
    }
}
