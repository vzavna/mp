package decorador;

import clase_base.Cafe;
import abstraccion.CafeDecorador;

public class LecheDecorador extends CafeDecorador {
    public LecheDecorador(Cafe cafe) {
        super(cafe);
    }

    public String getDescripcion() {
        return cafe.getDescripcion() + ", leche";
    }

    public double getCosto() {
        return cafe.getCosto() + 2.0;
    }
}