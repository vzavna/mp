package practica_decorador;

import clase_base.Cafe;
import decorador.CafeBase;
import decorador.LecheDecorador;
import decorador.ChocolateDecorador;

public class ControladorCafeteria {
    public static void main(String[] args) {
        Cafe cafe = new CafeBase();
        cafe = new LecheDecorador(cafe);
        cafe = new ChocolateDecorador(cafe);

        System.out.println(cafe.getDescripcion());
        System.out.println("Costo: $" + cafe.getCosto());
    }
}