package clase_base;

public interface Cafe {
    String getDescripcion();
    double getCosto();
}
