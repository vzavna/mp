package decorador;

import clase_base.Notificador;

public class NotificadorBase implements Notificador {
    public void enviar(String mensaje) {
        System.out.println("Enviando notificación base: " + mensaje);
    }
}