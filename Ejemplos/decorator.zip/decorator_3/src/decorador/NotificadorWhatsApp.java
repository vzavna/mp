package decorador;

import clase_base.Notificador;
import abstraccion.NotificadorDecorador;

public class NotificadorWhatsApp extends NotificadorDecorador {
    public NotificadorWhatsApp(Notificador notificador) {
        super(notificador);
    }

    public void enviar(String mensaje) {
        super.enviar(mensaje);
        System.out.println("Enviando por WhatsApp: " + mensaje);
    }
}