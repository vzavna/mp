package decorador;

import clase_base.Notificador;
import abstraccion.NotificadorDecorador;

public class NotificadorEmail extends NotificadorDecorador {
    public NotificadorEmail(Notificador notificador) {
        super(notificador);
    }

    public void enviar(String mensaje) {
        super.enviar(mensaje);
        System.out.println("Enviando por Email: " + mensaje);
    }
}