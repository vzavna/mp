package clase_base;

public interface Notificador {
    void enviar(String mensaje);
}
