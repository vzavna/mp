package abstraccion;

import clase_base.Notificador;

public abstract class NotificadorDecorador implements Notificador {
    protected Notificador notificador;

    public NotificadorDecorador(Notificador notificador) {
        this.notificador = notificador;
    }

    public void enviar(String mensaje) {
        notificador.enviar(mensaje);
    }
}