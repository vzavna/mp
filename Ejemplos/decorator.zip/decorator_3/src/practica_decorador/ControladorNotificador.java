package practica_decorador;

import clase_base.Notificador;
import decorador.NotificadorBase;
import decorador.NotificadorEmail;
import decorador.NotificadorWhatsApp;

public class ControladorNotificador {
    public static void main(String[] args) {
        Notificador notificador = new NotificadorBase();
        notificador = new NotificadorEmail(notificador);
        notificador = new NotificadorWhatsApp(notificador);

        notificador.enviar("¡Hola! Tienes una nueva oferta.");
    }
}
