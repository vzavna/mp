package co.edu.udistrital.model;

import co.edu.udistrital.model.abstracto.TipoAtaque;

public class Cercano implements TipoAtaque{

	@Override
	public String atacar() {
		return "------"
				+ "\n\u2022 Acercarse al objetivo"
				+ "\n\u2022 Encontrar su punto debil"
				+ "\n\u2022 Acertar un golpe con fuerza";
	}
	
}
