package co.edu.udistrital.controller;

import co.edu.udistrital.model.Cercano;
import co.edu.udistrital.model.Lejano;
import co.edu.udistrital.model.abstracto.TipoAtaque;
import co.edu.udistrital.view.Vista;

public class Controller {
	private Vista vista;
	
	public Controller()
	{
		vista = new Vista();
	}
	
	public void run()
	{
		TipoAtaque ataque;
		
		vista.mostrarInformacion("Estrategias de ataque de un videojuego: ");
		
		ataque = new Cercano();
		vista.mostrarInformacion("Ataque Cercano: " + "\n" + ataque.atacar());
		
		vista.mostrarInformacion("------------------------------------------");
		
		ataque = new Lejano();
		vista.mostrarInformacion("Ataque Lejano: " + "\n" + ataque.atacar());
	}
}
