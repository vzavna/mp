package co.edu.udistrital.model;

import co.edu.udistrital.model.abstracto.TipoAtaque;

public class Lejano implements TipoAtaque{

	@Override
	public String atacar() {
		return "------"
				+ "\n\u2022 Alejarse del objetivo"
				+ "\n\u2022 Esperar que baje la guardia"
				+ "\n\u2022 Atacar con un arma a distancia";
	}
	

}
