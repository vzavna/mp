package co.edu.udistrital.model.abstracto;

public interface TipoAtaque {
	public String atacar();
}
