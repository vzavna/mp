/**
 * 
 */
/**
 * 
 */
module Strategy_2 {
}