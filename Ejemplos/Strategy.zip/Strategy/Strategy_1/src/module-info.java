/**
 * 
 */
/**
 * 
 */
module Strategy_1 {
}