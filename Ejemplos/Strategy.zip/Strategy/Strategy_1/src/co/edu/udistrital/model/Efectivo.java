package co.edu.udistrital.model;

import co.edu.udistrital.model.abstracto.MetodoDePago;

public class Efectivo implements MetodoDePago{

	@Override
	public String realizarPago() {
		return "------"
				+ "\n\u2022 Confirmar la cantidad a pagar"
				+ "\n\u2022 Sacar la cantidad de billetes que cubra la cantidad de dinero"
				+ "\n\u2022 Disfrutar del servicio adquirido";
	}
	
}
