package co.edu.udistrital.controller;

import co.edu.udistrital.model.Efectivo;
import co.edu.udistrital.model.Nequi;
import co.edu.udistrital.model.Tarjeta;
import co.edu.udistrital.model.abstracto.MetodoDePago;
import co.edu.udistrital.view.Vista;

public class Controller {
	private Vista vista;
	
	public Controller()
	{
		vista = new Vista();
	}
	
	public void run()
	{
		MetodoDePago metodoDePago;
		
		while(true)
		{
			String estrategia = vista.leerCadenaDeTexto("Va a pagar con: "
					+ "\nEfectivo"
					+ "\nTarjeta"
					+ "\nNequi");
			
			if(estrategia.toLowerCase().equals("efectivo"))
			{
				metodoDePago = new Efectivo();
				vista.mostrarInformacion("Asegurese de: " + "\n" + metodoDePago.realizarPago());
			}
			else if(estrategia.toLowerCase().equals("tarjeta"))
			{
				metodoDePago = new Tarjeta();
				vista.mostrarInformacion("Asegurese de: " + "\n" + metodoDePago.realizarPago());
			}
			else if(estrategia.toLowerCase().equals("nequi"))
			{
				metodoDePago = new Nequi();
				vista.mostrarInformacion("Asegurese de: " + "\n" + metodoDePago.realizarPago());
			}
			
			int cont = Integer.parseInt(vista.leerCadenaDeTexto("Desea continuar en el programa?"
					+ "\n1. si"
					+ "\n2. no"));
			
			if(cont == 1)
			{
				cont = 0;
				continue;
			}
			else
			{
				vista.mostrarInformacion("Gracias por usar el programa!");
				System.exit(0);
			}
		}
	}
}
