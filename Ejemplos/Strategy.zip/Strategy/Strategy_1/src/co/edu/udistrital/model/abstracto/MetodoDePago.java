package co.edu.udistrital.model.abstracto;

public interface MetodoDePago {
	public String realizarPago();
}
