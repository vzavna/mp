package co.edu.udistrital.model;

import co.edu.udistrital.model.abstracto.MetodoDePago;

public class Tarjeta implements MetodoDePago{

	@Override
	public String realizarPago() {
		return "------"
				+ "\n\u2022 Confirmar la cantidad a pagar"
				+ "\n\u2022 Verificar los fondos de la tarjeta"
				+ "\n\u2022 Escoger los fondos(ahorrros)"
				+ "\n\u2022 Disfrutar del servicio adquirido";
	}
	

}
