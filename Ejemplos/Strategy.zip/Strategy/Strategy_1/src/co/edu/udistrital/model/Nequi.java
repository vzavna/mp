package co.edu.udistrital.model;

import co.edu.udistrital.model.abstracto.MetodoDePago;

public class Nequi implements MetodoDePago{

	@Override
	public String realizarPago() {
		return "------"
				+ "\n\u2022 Confirmar la cantidad a pagar"
				+ "\n\u2022 En la app, escoger el \"bolsillo\" de donde sale el dinero"
				+ "\n\u2022 Esperar la confirmacion del pago"
				+ "\n\u2022 Disfrutar del servicio adquirido";
	}
	
}
