package co.edu.udistrital.controller;

import co.edu.udistrital.model.Practico;
import co.edu.udistrital.model.Teorico;
import co.edu.udistrital.model.abstracto.Estudio;
import co.edu.udistrital.view.Vista;

public class Controller {
	private Vista vista;
	
	public Controller()
	{
		vista = new Vista();
	}
	
	public void run()
	{
		Estudio estudio;
		
		vista.mostrarInformacion("Estrategias de estudio: ");
		
		estudio = new Teorico();
		vista.mostrarInformacion("\n" + estudio.estudiar());
		
		vista.mostrarInformacion("------------------------------------------");
		
		estudio = new Practico();
		vista.mostrarInformacion("\n" + estudio.estudiar());
	}
}
