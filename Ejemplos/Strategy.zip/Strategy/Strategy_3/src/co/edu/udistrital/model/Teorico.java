package co.edu.udistrital.model;

import co.edu.udistrital.model.abstracto.Estudio;

public class Teorico implements Estudio{

	@Override
	public String estudiar() {
		return "------"
				+ "\n\u2022 Revisar los apuntes de clase"
				+ "\n\u2022 Tener en cuenta los temas que se evaluaran"
				+ "\n\u2022 Memorizar las formulas y temas importantes"
				+ "\n\u2022 Sacar una excelente nota";
	}

}
