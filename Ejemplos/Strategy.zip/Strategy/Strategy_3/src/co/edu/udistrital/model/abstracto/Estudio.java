package co.edu.udistrital.model.abstracto;

public interface Estudio {
	public String estudiar();
}
