package co.edu.udistrital.model;

import co.edu.udistrital.model.abstracto.Estudio;

public class Practico implements Estudio{

	@Override
	public String estudiar() {
		return "------"
				+ "\n\u2022 Revisar los apuntes de clase"
				+ "\n\u2022 Tener en cuenta los temas que se evaluaran"
				+ "\n\u2022 Aprender las tecnicas enseñadas en clase"
				+ "\n\u2022 Manejar el lenguaje de programacion utilizado en clase"
				+ "\n\u2022 Sacar una excelente nota";
	}


}
