/**
 * 
 */
/**
 * 
 */
module Strategy_3 {
}