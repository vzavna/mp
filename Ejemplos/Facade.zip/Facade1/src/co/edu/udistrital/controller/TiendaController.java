package co.edu.udistrital.controller;

import co.edu.udistrital.model.entities.Cliente;
import co.edu.udistrital.model.entities.Producto;
import co.edu.udistrital.model.facade.TiendaFacade;
import co.edu.udistrital.view.TiendaView;
import java.util.List;

public class TiendaController {
    private TiendaFacade facade;
    private TiendaView view;
    private Cliente clienteActual;
    
    public TiendaController() {
        this.facade = new TiendaFacade();
        this.view = new TiendaView();
    }
    
    public void run() {
        clienteActual = view.leerDatosCliente();
        boolean salir = false;
        
        while (!salir) {
            view.mostrarMenuPrincipal();
            int opcion = view.leerOpcionMenu();
            
            switch (opcion) {
                case 1:
                    buscarProducto();
                    break;
                case 2:
                    listarProductosDisponibles();
                    break;
                case 3:
                    realizarCompra();
                    break;
                case 4:
                    verHistorialCompras();
                    break;
                case 5:
                	salir = true;
                    view.mostrarDespedida();
                    break;
                default:
                    view.mostrarResultadoOperacion(false, "Opcion no válida");
            }
        }
    }
    
    private void buscarProducto() {
        String criterio = view.leerCriterioBusqueda();
        Producto producto = facade.buscarProducto(criterio);
        view.mostrarProducto(producto);
    }
    
    private void listarProductosDisponibles() {
        List<Producto> productos = facade.listarProductosDisponibles();
        view.mostrarProductosDisponibles(productos);
    }
    
    private void realizarCompra() {
        String criterio = view.leerCriterioBusqueda();
        Producto producto = facade.buscarProducto(criterio);
        
        if(producto == null) {
            view.mostrarMensaje("\nProducto no encontrado");
            return;
        }
        
        view.mostrarDetallesProducto(producto);
        
        boolean confirmacion = view.confirmarSeleccion("¿Desea comprar este producto? (SI/NO)");
        
        if(confirmacion) {
            int cantidad = view.leerCantidad(producto.getStock());
            boolean exito = facade.realizarCompra(clienteActual, producto.getCodigo(), cantidad);
            view.mostrarResultadoOperacion(exito, "Compra");
        } else {
            view.mostrarMensaje("\nCompra cancelada");
        }
    }
    
    private void verHistorialCompras() {
        List<Producto> compras = facade.verHistorialCompras(clienteActual);
        view.mostrarHistorialCompras(compras);
    }
}