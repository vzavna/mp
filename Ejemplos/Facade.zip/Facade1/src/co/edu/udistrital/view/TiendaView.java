package co.edu.udistrital.view;

import co.edu.udistrital.model.entities.Cliente;
import co.edu.udistrital.model.entities.Producto;
import java.util.List;

public class TiendaView {
    private VistaConsola vista;
    
    public TiendaView() {
        this.vista = new VistaConsola();
    }
    
    public void mostrarMenuPrincipal() {
        vista.mostrarInformacion("\n--- SISTEMA DE GESTION DE TIENDA ---");
        vista.mostrarInformacion("1. Buscar producto");
        vista.mostrarInformacion("2. Listar productos disponibles");
        vista.mostrarInformacion("3. Realizar compra");
        vista.mostrarInformacion("4. Ver historial de compras");
        vista.mostrarInformacion("5. Salir");
    }
    
    public int leerOpcionMenu() {
        return vista.leerDatoEntero("Seleccione una opcion: ");
    }
    
    public Cliente leerDatosCliente() {
        vista.mostrarInformacion("\nIngrese sus datos:");
        String id = vista.leerString("ID de cliente: ");
        String nombre = vista.leerString("Nombre: ");
        return new Cliente(id, nombre);
    }
    
    public String leerCriterioBusqueda() {
        return vista.leerString("\nIngrese nombre o codigo del producto: ");
    }
    
    public void mostrarDetallesProducto(Producto producto) {
        vista.mostrarInformacion("\n=== PRODUCTO ENCONTRADO ===");
        vista.mostrarInformacion("Codigo: " + producto.getCodigo());
        vista.mostrarInformacion("Nombre: " + producto.getNombre());
        vista.mostrarInformacion("Precio: $" + producto.getPrecio());
        vista.mostrarInformacion("Stock disponible: " + producto.getStock());
    }

    public boolean confirmarSeleccion(String mensaje) {
        return vista.leerBoolean(mensaje);
    }

    public int leerCantidad(int stockDisponible) {
        while(true) {
            int cantidad = vista.leerDatoEntero("Ingrese cantidad (maximo " + stockDisponible + "): ");
            if(cantidad > 0 && cantidad <= stockDisponible) {
                return cantidad;
            }
            vista.mostrarInformacion("Cantidad invalida! Debe ser entre 1 y " + stockDisponible);
        }
    }

    public void mostrarMensaje(String mensaje) {
        vista.mostrarInformacion(mensaje);
    }
    
    public void mostrarProducto(Producto producto) {
        if (producto != null) {
            vista.mostrarInformacion("\nProducto encontrado: " + producto);
        } else {
            vista.mostrarInformacion("\nProducto no encontrado");
        }
    }
    
    public void mostrarProductosDisponibles(List<Producto> productos) {
        vista.mostrarInformacion("\nProductos disponibles:");
        if (productos.isEmpty()) {
            vista.mostrarInformacion("No hay productos disponibles en este momento");
        } else {
            for (Producto producto : productos) {
                vista.mostrarInformacion("- " + producto);
            }
        }
    }
    
    public void mostrarResultadoOperacion(boolean exito, String operacion) {
        if (exito) {
            vista.mostrarInformacion("\n" + operacion + " realizada con exito");
        } else {
            vista.mostrarInformacion("\nNo se pudo completar la operacion: " + operacion);
        }
    }
    
    public void mostrarPromocion(String mensaje) {
        vista.mostrarInformacion("\nPromocion: " + mensaje);
    }
    
    public void mostrarHistorialCompras(List<Producto> compras) {
        vista.mostrarInformacion("\nHistorial de compras:");
        if (compras.isEmpty()) {
            vista.mostrarInformacion("No hay compras registradas");
        } else {
            for (Producto producto : compras) {
                vista.mostrarInformacion("- " + producto);
            }
        }
    }
    
    public void mostrarDespedida() {
        vista.mostrarInformacion("\nGracias por usar el sistema de la tienda. Vuelva pronto!");
    }
}