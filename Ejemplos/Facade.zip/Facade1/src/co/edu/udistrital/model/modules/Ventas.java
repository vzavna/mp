package co.edu.udistrital.model.modules;

import java.util.List;

import co.edu.udistrital.model.entities.Cliente;
import co.edu.udistrital.model.entities.Producto;

public class Ventas {
    public boolean procesarVenta(Cliente cliente, Producto producto, int cantidad) {
        if (producto.getStock() >= cantidad) {
            producto.setStock(producto.getStock() - cantidad);
            cliente.agregarCompra(producto);
            return true;
        }
        return false;
    }
    
    public List<Producto> obtenerHistorialCompras(Cliente cliente) {
        return cliente.getHistorialCompras();
    }
}