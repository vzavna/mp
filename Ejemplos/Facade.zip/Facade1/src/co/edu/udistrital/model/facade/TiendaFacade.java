package co.edu.udistrital.model.facade;

import java.util.List;

import co.edu.udistrital.model.entities.Cliente;
import co.edu.udistrital.model.entities.Producto;
import co.edu.udistrital.model.modules.CatalogoProductos;
import co.edu.udistrital.model.modules.Ventas;

public class TiendaFacade {
    private CatalogoProductos catalogo;
    private Ventas ventas;
    
    public TiendaFacade() {
        this.catalogo = new CatalogoProductos();
        this.ventas = new Ventas();
    }
    
    public Producto buscarProducto(String criterio) {
        return catalogo.buscarProducto(criterio);
    }
    
    public List<Producto> listarProductosDisponibles() {
        return catalogo.listarProductosDisponibles();
    }
    
    public boolean realizarCompra(Cliente cliente, String codigoProducto, int cantidad) {
        Producto producto = catalogo.buscarProducto(codigoProducto);
        if (producto != null && producto.getStock() >= cantidad) {
            boolean exito = ventas.procesarVenta(cliente, producto, cantidad);
            if (exito) {
            	System.out.println("Gracias por comprar " + cantidad + " unidades de " + producto.getNombre());
                return true;
            }
        }
        return false;
    }
    
    public List<Producto> verHistorialCompras(Cliente cliente) {
        return ventas.obtenerHistorialCompras(cliente);
    }
}