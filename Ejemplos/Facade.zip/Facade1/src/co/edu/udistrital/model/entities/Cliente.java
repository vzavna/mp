package co.edu.udistrital.model.entities;

import java.util.ArrayList;
import java.util.List;

public class Cliente {
    private String id;
    private String nombre;
    private List<Producto> historialCompras;
    
    public Cliente(String id, String nombre) {
        this.id = id;
        this.nombre = nombre;
        this.historialCompras = new ArrayList<>();
    }
    
    public String getId() {
        return id;
    }
    
    public String getNombre() {
        return nombre;
    }
    
    public List<Producto> getHistorialCompras() {
        return historialCompras;
    }
    
    public void agregarCompra(Producto producto) {
        historialCompras.add(producto);
    }
    
    @Override
    public String toString() {
        return nombre + " (ID: " + id + ") - Compras realizadas: " + historialCompras.size();
    }
}