package co.edu.udistrital.model.modules;

import co.edu.udistrital.model.entities.Producto;
import java.util.ArrayList;
import java.util.List;

public class CatalogoProductos {
    private List<Producto> productos;
    
    public CatalogoProductos() {
        this.productos = new ArrayList<>();

        productos.add(new Producto("P001", "Laptop", 1200.00, 10));
        productos.add(new Producto("P002", "Smartphone", 800.00, 15));
        productos.add(new Producto("P003", "Tablet", 400.00, 8));
    }
    
    public Producto buscarProducto(String criterio) {
        for (Producto producto : productos) {
            if (producto.getNombre().contains(criterio) || 
                producto.getCodigo().equals(criterio)) {
                return producto;
            }
        }
        return null;
    }
    
    public List<Producto> listarProductosDisponibles() {
        List<Producto> disponibles = new ArrayList<>();
        for (Producto producto : productos) {
            if (producto.getStock() > 0) {
                disponibles.add(producto);
            }
        }
        return disponibles;
    }
    
    public boolean actualizarStock(Producto producto, int cantidad) {
        if (productos.contains(producto)){
            producto.setStock(producto.getStock() - cantidad);
            return true;
        }
        return false;
    }
}