package co.edu.udistrital.view;

import java.util.Scanner;

public class VistaConsola {
	
	private Scanner sc;
	
	public VistaConsola() {
		sc = new Scanner(System.in);
	}
	
	public void mostrarInformacion(String mensaje) {
		System.out.println(mensaje);
	}
	
	public int leerDatoEntero(String mensaje) {
		int dato = 0;
		System.out.print(mensaje);
		dato = sc.nextInt();
		return dato;
	}
	
	public String leerString(String mensaje) {
	    System.out.print(mensaje);
	    String input = "";
	    try {
	        input = sc.nextLine();
	    } catch (Exception e) {
	        System.out.println("Error en la entrada: " + e.getMessage());
	        sc.nextLine();
	    }
	    return input;
	}
	
	public boolean leerBoolean(String mensaje) {
	    while(true) {
	        System.out.print(mensaje);
	        String input = sc.nextLine().trim().toUpperCase();
	        if(input.equals("SI") || input.equals("S")) return true;
	        if(input.equals("NO") || input.equals("N")) return false;
	        System.out.println("Por favor ingrese SI o NO");
	    }
	}
	
	public double leerDouble(String mensaje) {
	    while (true) {
	        System.out.print(mensaje);
	        try {
	            return Double.parseDouble(sc.nextLine().trim());
	        } catch (NumberFormatException e) {
	            System.out.println("Error: Debe ingresar un número válido. Ejemplo: 12.5");
	        }
	    }
	}

}
