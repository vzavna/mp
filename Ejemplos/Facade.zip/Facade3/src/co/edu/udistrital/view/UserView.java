package co.edu.udistrital.view;

import java.util.Scanner;
import co.edu.udistrital.controller.UserController;

public class UserView {
    private UserController controller;
    private Scanner scanner;
    
    public UserView() {
        this.controller = new UserController();
        this.scanner = new Scanner(System.in);
    }
    
    public void startApplication() {
        System.out.println("=== Sistema de Gestión de Usuarios ===");
        
        while (true) {
            displayMenu();
            int option = readOption();
            processOption(option);
        }
    }
    
    private void displayMenu() {
        System.out.println("\n--- Menú Principal ---");
        System.out.println("1. Registrar nuevo usuario");
        System.out.println("2. Buscar usuario");
        System.out.println("3. Listar todos los usuarios");
        System.out.println("4. Listar usuarios activos");
        System.out.println("5. Desactivar usuario");
        System.out.println("6. Mostrar estadísticas");
        System.out.println("0. Salir");
        System.out.print("Seleccione una opción: ");
    }
    
    private int readOption() {
        try {
            return Integer.parseInt(scanner.nextLine());
        } catch (NumberFormatException e) {
            return -1;
        }
    }
    
    private void processOption(int option) {
        switch (option) {
            case 1:
                registerUser();
                break;
            case 2:
                searchUser();
                break;
            case 3:
                listAllUsers();
                break;
            case 4:
                listActiveUsers();
                break;
            case 5:
                deactivateUser();
                break;
            case 6:
                showStats();
                break;
            case 0:
                System.out.println("Saliendo del sistema...");
                System.exit(0);
                break;
            default:
                System.out.println("Opción no válida");
        }
    }
    
    private void registerUser() {
        System.out.println("\n--- Registrar Usuario ---");
        System.out.print("Nombre de usuario: ");
        String username = scanner.nextLine();
        
        System.out.print("Email: ");
        String email = scanner.nextLine();
        
        System.out.print("Rol (admin/user): ");
        String role = scanner.nextLine();
        
        String result = controller.registerUser(username, email, role);
        System.out.println(result);
    }
    
    private void searchUser() {
        System.out.println("\n--- Buscar Usuario ---");
        System.out.print("Nombre de usuario: ");
        String username = scanner.nextLine();
        
        String userInfo = controller.getUserInfo(username);
        System.out.println(userInfo);
    }
    
    private void listAllUsers() {
        System.out.println("\n--- Todos los Usuarios ---");
        System.out.println(controller.listAllUsers());
    }
    
    private void listActiveUsers() {
        System.out.println("\n--- Usuarios Activos ---");
        System.out.println(controller.listActiveUsers());
    }
    
    private void deactivateUser() {
        System.out.println("\n--- Desactivar Usuario ---");
        System.out.print("Nombre de usuario: ");
        String username = scanner.nextLine();
        
        String result = controller.deactivateUser(username);
        System.out.println(result);
    }
    
    private void showStats() {
        System.out.println("\n--- Estadísticas del Sistema ---");
        System.out.println(controller.getSystemStats());
    }
}