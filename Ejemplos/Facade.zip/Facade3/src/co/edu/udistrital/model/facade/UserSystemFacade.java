package co.edu.udistrital.model.facade;

import java.util.List;

import co.edu.udistrital.model.entities.User;
import co.edu.udistrital.model.modules.UserService;

public class UserSystemFacade {
    private UserService userService;
    
    public UserSystemFacade() {
        this.userService = new UserService();
        userService.addUser(new User("admin", "admin@system.com", "admin"));
        userService.addUser(new User("juan", "juan@example.com", "user"));
    }
    
    public String registerUser(String username, String email, String role) {
        if (userService.addUser(new User(username, email, role))) {
            return "Usuario registrado exitosamente";
        }
        return "Error: El usuario ya existe";
    }
    
    public String getUserInfo(String username) {
        User user = userService.getUser(username);
        return user != null ? user.toString() : "Usuario no encontrado";
    }
    
    public String listAllUsers() {
        return formatUserList(userService.getAllUsers());
    }
    
    public String listActiveUsers() {
        return formatUserList(userService.getActiveUsers());
    }
    
    public String deactivateUser(String username) {
        return userService.deactivateUser(username) 
            ? "Usuario desactivado" 
            : "Usuario no encontrado";
    }
    
    public String getSystemStats() {
        return String.format(
            "Total usuarios: %d | Activos: %d | Admins: %d",
            userService.getUserCount(),
            userService.getActiveUserCount(),
            userService.getAdminCount()
        );
    }
    
    private String formatUserList(List<User> users) {
        if (users.isEmpty()) return "No hay usuarios registrados";
        
        StringBuilder sb = new StringBuilder();
        for (User user : users) {
            sb.append(user.toString()).append("\n");
        }
        return sb.toString();
    }
}