package co.edu.udistrital.model.modules;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;
import co.edu.udistrital.model.entities.User;

public class UserService {
    private List<User> users = new ArrayList<>();
    
    public boolean addUser(User user) {
        if (getUser(user.getUsername()) != null) {
            return false;
        }
        users.add(user);
        return true;
    }
    
    public User getUser(String username) {
        return users.stream()
            .filter(u -> u.getUsername().equals(username))
            .findFirst()
            .orElse(null);
    }
    
    public List<User> getAllUsers() {
        return new ArrayList<>(users);
    }
    
    public List<User> getActiveUsers() {
        return users.stream()
            .filter(User::isActive)
            .collect(Collectors.toList());
    }
    
    public boolean deactivateUser(String username) {
        User user = getUser(username);
        if (user != null) {
            user.setActive(false);
            return true;
        }
        return false;
    }
    
    public int getUserCount() {
        return users.size();
    }
    
    public int getActiveUserCount() {
        return (int) users.stream()
            .filter(User::isActive)
            .count();
    }
    
    public int getAdminCount() {
        return (int) users.stream()
            .filter(u -> "admin".equalsIgnoreCase(u.getRole()))
            .count();
    }
}