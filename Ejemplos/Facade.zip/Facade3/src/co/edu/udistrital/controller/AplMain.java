package co.edu.udistrital.controller;

import co.edu.udistrital.view.UserView;

public class AplMain {
	public static void main(String[] args) {
        UserView view = new UserView();
        view.startApplication();
    }
}