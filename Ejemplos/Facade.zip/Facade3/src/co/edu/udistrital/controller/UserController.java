package co.edu.udistrital.controller;

import co.edu.udistrital.model.facade.UserSystemFacade;

public class UserController {
    private UserSystemFacade userFacade;
    
    public UserController() {
        this.userFacade = new UserSystemFacade();
    }
    
    public String registerUser(String username, String email, String role) {
        return userFacade.registerUser(username, email, role);
    }
    
    public String getUserInfo(String username) {
        return userFacade.getUserInfo(username);
    }
    
    public String listAllUsers() {
        return userFacade.listAllUsers();
    }
    
    public String listActiveUsers() {
        return userFacade.listActiveUsers();
    }
    
    public String deactivateUser(String username) {
        return userFacade.deactivateUser(username);
    }
    
    public String getSystemStats() {
        return userFacade.getSystemStats();
    }
}