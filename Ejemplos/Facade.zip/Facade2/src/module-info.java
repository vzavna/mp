/**
 * 
 */
/**
 * 
 */
module Facade2 {
}