package co.edu.udistrital.controller;

import co.edu.udistrital.model.entities.Dueño;
import co.edu.udistrital.model.entities.Mascota;
import co.edu.udistrital.model.entities.Consulta;
import co.edu.udistrital.model.facade.VeterinariaFacade;
import co.edu.udistrital.view.VeterinariaView;
import java.util.List;

public class VeterinariaController {
    private VeterinariaFacade facade;
    private VeterinariaView view;
    private Dueño dueñoActual;
    
    public VeterinariaController() {
        this.facade = new VeterinariaFacade();
        this.view = new VeterinariaView();
    }
    
    public void run() {
        dueñoActual = view.leerDatosDueño();
        boolean salir = false;
        
        while (!salir) {
            view.mostrarMenuPrincipal();
            int opcion = view.leerOpcionMenu();
            
            switch (opcion) {
                case 1:
                    registrarMascota();
                    break;
                case 2:
                    buscarMascota();
                    break;
                case 3:
                    programarConsulta();
                    break;
                case 4:
                    verHistorialConsultas();
                    break;
                case 5:
                    salir = true;
                    view.mostrarDespedida();
                    break;
                default:
                    view.mostrarMensaje("Opción no válida");
            }
        }
    }
    
    private void registrarMascota() {
        Mascota mascota = view.leerDatosMascota();
        boolean exito = facade.registrarMascota(dueñoActual, mascota);
        view.mostrarResultadoOperacion(exito, "Registro de mascota");
    }
    
    private void buscarMascota() {
        String nombre = view.leerNombreMascota();
        Mascota mascota = facade.buscarMascota(dueñoActual, nombre);
        view.mostrarMascota(mascota);
    }
    
    private void programarConsulta() {
        String nombreMascota = view.leerNombreMascota();
        Mascota mascota = facade.buscarMascota(dueñoActual, nombreMascota);
        
        if(mascota == null) {
            view.mostrarMensaje("Mascota no encontrada");
            return;
        }
        
        Consulta consulta = view.leerDatosConsulta();
        boolean exito = facade.programarConsulta(mascota, consulta);
        view.mostrarResultadoOperacion(exito, "Programación de consulta");
    }
    
    private void verHistorialConsultas() {
        String nombreMascota = view.leerNombreMascota();
        Mascota mascota = facade.buscarMascota(dueñoActual, nombreMascota);
        
        if(mascota != null) {
            List<Consulta> consultas = facade.obtenerHistorialConsultas(mascota);
            view.mostrarHistorialConsultas(consultas);
        } else {
            view.mostrarMensaje("Mascota no encontrada");
        }
    }
}