package co.edu.udistrital.model.modules;

import co.edu.udistrital.model.entities.Dueño;
import co.edu.udistrital.model.entities.Mascota;

public class RegistroMascotas {
    public boolean registrarMascota(Dueño dueño, Mascota mascota) {
        if (dueño != null && mascota != null) {
            dueño.agregarMascota(mascota);
            return true;
        }
        return false;
    }
    
    public Mascota buscarMascota(Dueño dueño, String nombre) {
        if (dueño == null || nombre == null) return null;
        
        for (Mascota mascota : dueño.getMascotas()) {
            if (mascota.getNombre().equalsIgnoreCase(nombre)) {
                return mascota;
            }
        }
        return null;
    }
}