package co.edu.udistrital.model.entities;

import java.time.LocalDate;

public class Consulta {
    private LocalDate fecha;
    private String motivo;
    private String diagnostico;
    private String tratamiento;
    
    public Consulta(LocalDate fecha, String motivo, String diagnostico, String tratamiento) {
        this.fecha = fecha;
        this.motivo = motivo;
        this.diagnostico = diagnostico;
        this.tratamiento = tratamiento;
    }
    
    public LocalDate getFecha() { return fecha; }
    public String getMotivo() { return motivo; }
    public String getDiagnostico() { return diagnostico; }
    public String getTratamiento() { return tratamiento; }
    
    @Override
    public String toString() {
        return "Consulta [Fecha: " + fecha + ", Motivo: " + motivo + 
               ", Diagnóstico: " + diagnostico + ", Tratamiento: " + tratamiento + "]";
    }
}