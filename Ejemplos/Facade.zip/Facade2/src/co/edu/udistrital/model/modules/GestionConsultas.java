package co.edu.udistrital.model.modules;

import co.edu.udistrital.model.entities.Mascota;
import co.edu.udistrital.model.entities.Consulta;
import java.util.List;

public class GestionConsultas {
    public boolean programarConsulta(Mascota mascota, Consulta consulta) {
        if (mascota != null && consulta != null) {
            mascota.agregarConsulta(consulta);
            return true;
        }
        return false;
    }
    
    public List<Consulta> obtenerHistorialConsultas(Mascota mascota) {
        return mascota != null ? mascota.getHistorialConsultas() : null;
    }
}