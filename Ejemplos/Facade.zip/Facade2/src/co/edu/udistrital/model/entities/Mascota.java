package co.edu.udistrital.model.entities;

import java.util.ArrayList;
import java.util.List;

public class Mascota {
    private String nombre;
    private String especie;
    private String raza;
    private int edad;
    private List<Consulta> historialConsultas;
    
    public Mascota(String nombre, String especie, String raza, int edad) {
        this.nombre = nombre;
        this.especie = especie;
        this.raza = raza;
        this.edad = edad;
        this.historialConsultas = new ArrayList<>();
    }
    
    public String getNombre() { return nombre; }
    public String getEspecie() { return especie; }
    public String getRaza() { return raza; }
    public int getEdad() { return edad; }
    public List<Consulta> getHistorialConsultas() { return historialConsultas; }
    
    public void agregarConsulta(Consulta consulta) {
        historialConsultas.add(consulta);
    }
    
    @Override
    public String toString() {
        return nombre + " (" + especie + ", " + raza + ") - " + edad + " años";
    }
}