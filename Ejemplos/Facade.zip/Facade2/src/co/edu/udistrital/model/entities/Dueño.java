package co.edu.udistrital.model.entities;

import java.util.ArrayList;
import java.util.List;

public class Dueño {
    private String identificacion;
    private String nombre;
    private String telefono;
    private List<Mascota> mascotas;
    
    public Dueño(String identificacion, String nombre, String telefono) {
        this.identificacion = identificacion;
        this.nombre = nombre;
        this.telefono = telefono;
        this.mascotas = new ArrayList<>();
    }
    
    public String getIdentificacion() { return identificacion; }
    public String getNombre() { return nombre; }
    public String getTelefono() { return telefono; }
    public List<Mascota> getMascotas() { return mascotas; }
    
    public void agregarMascota(Mascota mascota) {
        mascotas.add(mascota);
    }
    
    @Override
    public String toString() {
        return nombre + " (ID: " + identificacion + ") - Tel: " + telefono;
    }
}