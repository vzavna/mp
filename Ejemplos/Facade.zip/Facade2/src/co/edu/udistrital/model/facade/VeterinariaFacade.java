package co.edu.udistrital.model.facade;

import co.edu.udistrital.model.entities.Dueño;
import co.edu.udistrital.model.entities.Mascota;
import co.edu.udistrital.model.entities.Consulta;
import co.edu.udistrital.model.modules.RegistroMascotas;
import co.edu.udistrital.model.modules.GestionConsultas;
import java.util.List;

public class VeterinariaFacade {
    private RegistroMascotas registroMascotas;
    private GestionConsultas gestionConsultas;
    
    public VeterinariaFacade() {
        this.registroMascotas = new RegistroMascotas();
        this.gestionConsultas = new GestionConsultas();
    }
    
    public boolean registrarMascota(Dueño dueño, Mascota mascota) {
        return registroMascotas.registrarMascota(dueño, mascota);
    }
    
    public Mascota buscarMascota(Dueño dueño, String nombre) {
        return registroMascotas.buscarMascota(dueño, nombre);
    }
    
    public boolean programarConsulta(Mascota mascota, Consulta consulta) {
        return gestionConsultas.programarConsulta(mascota, consulta);
    }
    
    public List<Consulta> obtenerHistorialConsultas(Mascota mascota) {
        return gestionConsultas.obtenerHistorialConsultas(mascota);
    }
}