package co.edu.udistrital.view;

import co.edu.udistrital.model.entities.Dueño;
import co.edu.udistrital.model.entities.Mascota;
import co.edu.udistrital.model.entities.Consulta;
import java.time.LocalDate;
import java.util.List;

public class VeterinariaView {
    private VistaConsola vista;
    
    public VeterinariaView() {
        this.vista = new VistaConsola();
    }
    
    public void mostrarMenuPrincipal() {
        vista.mostrarInformacion("\n--- CLÍNICA VETERINARIA ---");
        vista.mostrarInformacion("1. Registrar mascota");
        vista.mostrarInformacion("2. Buscar mascota");
        vista.mostrarInformacion("3. Programar consulta");
        vista.mostrarInformacion("4. Ver historial de consultas");
        vista.mostrarInformacion("5. Salir");
    }
    
    public int leerOpcionMenu() {
        return vista.leerDatoEntero("Seleccione una opción: ");
    }
    
    public Dueño leerDatosDueño() {
        vista.mostrarInformacion("\nREGISTRO DE DUEÑO");
        String id = vista.leerString("Identificación: ");
        String nombre = vista.leerString("Nombre completo: ");
        String telefono = vista.leerString("Teléfono: ");
        return new Dueño(id, nombre, telefono);
    }
    
    public Mascota leerDatosMascota() {
        vista.mostrarInformacion("\nREGISTRO DE MASCOTA");
        String nombre = vista.leerString("Nombre de la mascota: ");
        String especie = vista.leerString("Especie: ");
        String raza = vista.leerString("Raza: ");
        int edad = vista.leerDatoEntero("Edad: ");
        return new Mascota(nombre, especie, raza, edad);
    }
    
    public String leerNombreMascota() {
        return vista.leerString("\nNombre de la mascota: ");
    }
    
    public Consulta leerDatosConsulta() {
        vista.mostrarInformacion("\nPROGRAMAR CONSULTA");
        vista.mostrarInformacion("Fecha (AAAA-MM-DD): ");
        LocalDate fecha = LocalDate.parse(vista.leerString(""));
        String motivo = vista.leerString("Motivo de la consulta: ");
        String diagnostico = vista.leerString("Diagnóstico: ");
        String tratamiento = vista.leerString("Tratamiento: ");
        return new Consulta(fecha, motivo, diagnostico, tratamiento);
    }
    
    public void mostrarMascota(Mascota mascota) {
        if (mascota != null) {
            vista.mostrarInformacion("\nMASCOTA ENCONTRADA:");
            vista.mostrarInformacion(mascota.toString());
        } else {
            vista.mostrarInformacion("\nMascota no encontrada");
        }
    }
    
    public void mostrarHistorialConsultas(List<Consulta> consultas) {
        if (consultas == null || consultas.isEmpty()) {
            vista.mostrarInformacion("\nNo hay consultas registradas para esta mascota");
        } else {
            vista.mostrarInformacion("\nHISTORIAL DE CONSULTAS:");
            for (Consulta consulta : consultas) {
                vista.mostrarInformacion(consulta.toString());
            }
        }
    }
    
    public void mostrarResultadoOperacion(boolean exito, String operacion) {
        if (exito) {
            vista.mostrarInformacion("\n" + operacion + " realizada con éxito");
        } else {
            vista.mostrarInformacion("\nError al realizar " + operacion);
        }
    }
    
    public void mostrarMensaje(String mensaje) {
        vista.mostrarInformacion(mensaje);
    }
    
    public void mostrarDespedida() {
        vista.mostrarInformacion("\nGracias por usar el sistema de la clínica veterinaria");
    }
}