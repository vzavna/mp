package co.edu.udistrital.view;

import java.util.Scanner;

public class VistaConsola {
    private Scanner sc;
    
    public VistaConsola() {
        sc = new Scanner(System.in);
    }
    
    public void mostrarInformacion(String mensaje) {
        System.out.println(mensaje);
    }
    
    public int leerDatoEntero(String mensaje) {
        System.out.print(mensaje);
        while(!sc.hasNextInt()) {
            sc.next();
            System.out.print("Por favor ingrese un número válido: ");
        }
        int numero = sc.nextInt();
        sc.nextLine();
        return numero;
    }
    
    public String leerString(String mensaje) {
        System.out.print(mensaje);
        return sc.nextLine();
    }
    
    public boolean leerBoolean(String mensaje) {
        while(true) {
            System.out.print(mensaje);
            String input = sc.nextLine().trim().toUpperCase();
            if(input.equals("SI")) return true;
            if(input.equals("NO")) return false;
            System.out.println("Por favor ingrese SI o NO");
        }
    }
}