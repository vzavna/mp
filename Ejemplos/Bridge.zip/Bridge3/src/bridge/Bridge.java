package bridge;


import abstraccion.AdvancedPrinterController;
import abstraccion.BasicPrinterController;
import abstraccion.PrinterController;
import implementador.IPrinter;
import implementador.InkPrinter;
import implementador.LaserPrinter;


public class Bridge {
	public static void main(String[] args) {
        IPrinter inkPrinter = new InkPrinter();
        PrinterController basicPrinterController = new BasicPrinterController(inkPrinter);

        IPrinter laserPrinter = new LaserPrinter();
        PrinterController advancedPrinterController = new AdvancedPrinterController(laserPrinter);
    }
}
