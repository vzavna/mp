package implementador;

public class InkPrinter implements IPrinter {
    @Override
    public void print(String document) {
        System.out.println("Printing with ink: " + document);
    }
    
    @Override
    public void scan() {
        System.out.println("Scanning with ink printer");
    }
    
    @Override
    public void configure(String settings) {
        System.out.println("Configuring ink printer: " + settings);
    }
}