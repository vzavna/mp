package implementador;

public class LaserPrinter implements IPrinter {
    @Override
    public void print(String document) {
        System.out.println("Printing with laser: " + document);
    }
    
    @Override
    public void scan() {
        System.out.println("Scanning with laser printer");
    }
    
    @Override
    public void configure(String settings) {
        System.out.println("Configuring laser printer: " + settings);
    }
}