package implementador;

public interface IPrinter {
    void print(String document);
    void scan();
    void configure(String settings);
}