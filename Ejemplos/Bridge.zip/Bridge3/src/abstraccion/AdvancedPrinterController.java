package abstraccion;

import implementador.IPrinter;

public class AdvancedPrinterController extends PrinterController {
    public AdvancedPrinterController(IPrinter printer) {
        super(printer);
    }
    
    @Override
    public void printDocument(String doc) {
        printer.configure("high quality");
        printer.print(doc);
    }
    
    @Override
    public void scanDocument() {
        printer.configure("scan mode");
        printer.scan();
    }
    
    @Override
    public void configurePrinter() {
        printer.configure("custom settings");
    }
}