package abstraccion;

import implementador.IPrinter;

public class BasicPrinterController extends PrinterController {
    public BasicPrinterController(IPrinter printer) {
        super(printer);
    }
    
    @Override
    public void printDocument(String doc) {
        printer.print(doc);
    }
    
    @Override
    public void scanDocument() {
        printer.scan();
    }
    
    @Override
    public void configurePrinter() {
        printer.configure("default settings");
    }
}