package abstraccion;

import implementador.IPrinter;

public abstract class PrinterController {
    protected IPrinter printer;
    
    public PrinterController(IPrinter printer) {
        this.printer = printer;
    }
    
    public abstract void printDocument(String doc);
    public abstract void scanDocument();
    public abstract void configurePrinter();
}