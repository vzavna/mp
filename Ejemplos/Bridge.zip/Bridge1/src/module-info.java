/**
 * 
 */
/**
 * 
 */
module Bridge1 {
}