package implementador;

public class SmartLight implements IDevice {
    @Override
    public void powerOn() { System.out.println("Smart Light turned on"); }
    @Override
    public void powerOff() { System.out.println("Smart Light turned off"); }
    @Override
    public void setBrightness(int level) { System.out.println("Setting light brightness to " + level); }
    @Override
    public void setMode(String mode) { System.out.println("Setting light mode to " + mode); }
}