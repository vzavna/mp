package implementador;

public class Thermostat implements IDevice {
    @Override
    public void powerOn() { System.out.println("Thermostat powered on"); }
    @Override
    public void powerOff() { System.out.println("Thermostat powered off"); }
    @Override
    public void setBrightness(int level) { /* Not applicable */ }
    @Override
    public void setMode(String mode) { System.out.println("Setting thermostat to " + mode + " mode"); }
}