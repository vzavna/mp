package implementador;

public interface IDevice {
    void powerOn();
    void powerOff();
    void setBrightness(int level);
    void setMode(String mode);
}