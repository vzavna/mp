package bridge;

import abstraccion.Controller;
import abstraccion.BasicController;
import abstraccion.AdvancedController;
import implementador.IDevice;
import implementador.SmartLight;
import implementador.Thermostat;

public class Bridge {
	public static void main(String[] args) {
        IDevice smartLight = new SmartLight();
        Controller basicController = new BasicController(smartLight);

        IDevice thermostat = new Thermostat();
        Controller advancedController = new AdvancedController(thermostat);
    }
}
