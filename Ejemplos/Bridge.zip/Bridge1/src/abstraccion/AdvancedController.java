package abstraccion;

import implementador.IDevice;

public class AdvancedController extends Controller {
    private int currentBrightness = 50;
    
    public AdvancedController(IDevice device) {
        super(device);
    }
    
    @Override
    public void powerButton() {
        device.powerOff();
    }
    
    @Override
    public void upButton() {
        currentBrightness += 5;
        device.setBrightness(currentBrightness);
    }
    
    @Override
    public void downButton() {
        currentBrightness -= 5;
        device.setBrightness(currentBrightness);
    }
    
    @Override
    public void modeButton() {
        device.setMode("advanced");
    }
}