package abstraccion;

import implementador.IDevice;

public abstract class Controller {
    protected IDevice device;
    
    public Controller(IDevice device) {
        this.device = device;
    }
    
    public abstract void powerButton();
    public abstract void upButton();
    public abstract void downButton();
    public abstract void modeButton();
}