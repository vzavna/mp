package abstraccion;

import implementador.IDevice;

public class BasicController extends Controller {
    public BasicController(IDevice device) {
        super(device);
    }
    
    @Override
    public void powerButton() {
        device.powerOn();
    }
    
    @Override
    public void upButton() {
        device.setBrightness(10); // Increment by fixed amount
    }
    
    @Override
    public void downButton() {
        device.setBrightness(-10); // Decrement by fixed amount
    }
    
    @Override
    public void modeButton() {
        device.setMode("default");
    }
}