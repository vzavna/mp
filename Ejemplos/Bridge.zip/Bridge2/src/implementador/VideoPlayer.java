package implementador;

public class VideoPlayer implements IMediaPlayer {
    @Override
    public void play() { System.out.println("Playing video"); }
    @Override
    public void pause() { System.out.println("Video paused"); }
    @Override
    public void stop() { System.out.println("Video stopped"); }
    @Override
    public void setVolume(int level) { System.out.println("Video volume set to " + level); }
    @Override
    public void forward(int seconds) { System.out.println("Video fast forwarded " + seconds + " seconds"); }
    @Override
    public void rewind(int seconds) { System.out.println("Video rewound " + seconds + " seconds"); }
}