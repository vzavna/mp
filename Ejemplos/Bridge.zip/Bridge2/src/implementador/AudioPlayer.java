package implementador;

public class AudioPlayer implements IMediaPlayer {
    @Override
    public void play() { System.out.println("Playing audio"); }
    @Override
    public void pause() { System.out.println("Audio paused"); }
    @Override
    public void stop() { System.out.println("Audio stopped"); }
    @Override
    public void setVolume(int level) { System.out.println("Audio volume set to " + level); }
    @Override
    public void forward(int seconds) { System.out.println("Audio forwarded " + seconds + " seconds"); }
    @Override
    public void rewind(int seconds) { System.out.println("Audio rewound " + seconds + " seconds"); }
}
