package implementador;

public interface IMediaPlayer {
    void play();
    void pause();
    void stop();
    void setVolume(int level);
    void forward(int seconds);
    void rewind(int seconds);
}