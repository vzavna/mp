package bridge;

import abstraccion.MediaController;
import abstraccion.BasicMediaController;
import abstraccion.AdvancedMediaController;
import implementador.IMediaPlayer;
import implementador.AudioPlayer;
import implementador.VideoPlayer;

public class Bridge {
	public static void main(String[] args) {
        IMediaPlayer audioPlayer = new AudioPlayer();
        MediaController basicMediaController = new BasicMediaController(audioPlayer);

        IMediaPlayer videoPlayer = new VideoPlayer();
        MediaController advancedMediaController = new AdvancedMediaController(videoPlayer);
    }
}
