package abstraccion;

import implementador.IMediaPlayer;

public abstract class MediaController {
    protected IMediaPlayer player;
    
    public MediaController(IMediaPlayer player) {
        this.player = player;
    }
    
    public abstract void playPause();
    public abstract void stop();
    public abstract void volumeUp();
    public abstract void volumeDown();
    public abstract void skipForward();
    public abstract void skipBackward();
}