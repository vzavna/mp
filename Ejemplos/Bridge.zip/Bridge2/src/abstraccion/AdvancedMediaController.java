package abstraccion;

import implementador.IMediaPlayer;

public class AdvancedMediaController extends MediaController {
    private boolean isPlaying = false;
    
    public AdvancedMediaController(IMediaPlayer player) {
        super(player);
    }
    
    @Override
    public void playPause() {
        if(isPlaying) {
            player.pause();
            isPlaying = false;
        } else {
            player.play();
            isPlaying = true;
        }
    }
    
    @Override
    public void stop() {
        player.stop();
        isPlaying = false;
    }
    
    @Override
    public void volumeUp() {
        player.setVolume(5);
    }
    
    @Override
    public void volumeDown() {
        player.setVolume(-5);
    }
    
    @Override
    public void skipForward() {
        player.forward(10);
    }
    
    @Override
    public void skipBackward() {
        player.rewind(10);
    }
}