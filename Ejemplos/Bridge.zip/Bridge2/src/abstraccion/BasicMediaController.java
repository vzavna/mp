package abstraccion;

import implementador.IMediaPlayer;

public class BasicMediaController extends MediaController {
    public BasicMediaController(IMediaPlayer player) {
        super(player);
    }
    
    @Override
    public void playPause() {
        player.play();
    }
    
    @Override
    public void stop() {
        player.stop();
    }
    
    @Override
    public void volumeUp() {
        player.setVolume(10);
    }
    
    @Override
    public void volumeDown() {
        player.setVolume(-10);
    }
    
    @Override
    public void skipForward() {
        player.forward(30);
    }
    
    @Override
    public void skipBackward() {
        player.rewind(30);
    }
}