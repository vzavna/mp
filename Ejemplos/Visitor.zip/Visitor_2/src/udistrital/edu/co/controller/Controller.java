package udistrital.edu.co.controller;

import udistrital.edu.co.view.VistaConsola;
import udistrital.edu.co.model.*;
import udistrital.edu.co.model.visitor.*;

public class Controller {
    private VistaConsola vista;

    public Controller() {
        vista = new VistaConsola();
    }

    public void run() {
        Videojuego juego1 = new RPG("Elden Ring");
        Videojuego juego2 = new Deportivo("FIFA");

        VisitorDuracion duracion = new VisitorDuracion();
        VisitorRecomendacion recomendacion = new VisitorRecomendacion();

        vista.mostrarInformacion(juego1.aceptar(duracion));
        vista.mostrarInformacion(juego2.aceptar(duracion));

        vista.mostrarInformacion(juego1.aceptar(recomendacion));
        vista.mostrarInformacion(juego2.aceptar(recomendacion));
    }
}