package udistrital.edu.co.model;

import udistrital.edu.co.model.visitor.Visitor;

public class Deportivo implements Videojuego {
    private String nombre;

    public Deportivo(String nombre) {
        this.nombre = nombre;
    }

    public String aceptar(Visitor visitor) {
        return visitor.visitarDeportivo(this);
    }

    public String getNombre() {
        return nombre;
    }
}