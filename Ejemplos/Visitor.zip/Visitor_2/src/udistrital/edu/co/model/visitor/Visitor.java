package udistrital.edu.co.model.visitor;

import udistrital.edu.co.model.Deportivo;
import udistrital.edu.co.model.RPG;

public interface Visitor {
    String visitarRPG(RPG rpg);
    String visitarDeportivo(Deportivo d);
}