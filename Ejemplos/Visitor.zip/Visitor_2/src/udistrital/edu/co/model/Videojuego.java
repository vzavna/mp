package udistrital.edu.co.model;

import udistrital.edu.co.model.visitor.Visitor;

public interface Videojuego {
    String aceptar(Visitor visitor);
    String getNombre();
}