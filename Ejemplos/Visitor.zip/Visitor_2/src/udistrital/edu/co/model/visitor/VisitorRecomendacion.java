package udistrital.edu.co.model.visitor;

import udistrital.edu.co.model.Deportivo;
import udistrital.edu.co.model.RPG;

public class VisitorRecomendacion implements Visitor {
    public String visitarRPG(RPG rpg) {
        return "Recomendado para jugadores que aman la exploración.";
    }

    public String visitarDeportivo(Deportivo d) {
        return "Ideal para fanáticos del fútbol.";
    }
}