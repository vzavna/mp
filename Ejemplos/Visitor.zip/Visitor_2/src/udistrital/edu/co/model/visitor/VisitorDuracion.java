package udistrital.edu.co.model.visitor;

import udistrital.edu.co.model.Deportivo;
import udistrital.edu.co.model.RPG;

public class VisitorDuracion implements Visitor {
    public String visitarRPG(RPG rpg) {
        return "Duración de " + rpg.getNombre() + ": 80 horas.";
    }

    public String visitarDeportivo(Deportivo d) {
        return "Duración de " + d.getNombre() + ": infinita, es competitivo.";
    }
}