package udistrital.edu.co.model;

import udistrital.edu.co.model.visitor.Visitor;

public class RPG implements Videojuego {
    private String nombre;

    public RPG(String nombre) {
        this.nombre = nombre;
    }

    public String aceptar(Visitor visitor) {
        return visitor.visitarRPG(this);
    }

    public String getNombre() {
        return nombre;
    }
}