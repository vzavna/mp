package udistrital.edu.co.controller;

import udistrital.edu.co.view.VistaConsola;
import udistrital.edu.co.model.*;
import udistrital.edu.co.model.visitor.*;


public class Controller {
    private VistaConsola vista;

    public Controller() {
        vista = new VistaConsola();
    }

    public void run() {
        Mascota perro = new Perro("Rex", 5);
        Mascota gato = new Gato("Michi", 3);

        Visitor visitaVeterinaria = new VisitorVeterinaria();
        Visitor visitaVacunacion = new VisitorVacunacion();

        vista.mostrarInformacion(perro.aceptar(visitaVeterinaria));
        vista.mostrarInformacion(gato.aceptar(visitaVeterinaria));

        vista.mostrarInformacion(perro.aceptar(visitaVacunacion));
        vista.mostrarInformacion(gato.aceptar(visitaVacunacion));
    }
}