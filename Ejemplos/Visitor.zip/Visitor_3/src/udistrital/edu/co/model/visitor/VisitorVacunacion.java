package udistrital.edu.co.model.visitor;

import udistrital.edu.co.model.Gato;
import udistrital.edu.co.model.Perro;

public class VisitorVacunacion implements Visitor {

    @Override
    public String visitarPerro(Perro perro) {
        return "Aplicando vacuna al perro: " + perro.getNombre();
    }

    @Override
    public String visitarGato(Gato gato) {
        return "Aplicando vacuna al gato: " + gato.getNombre();
    }
}