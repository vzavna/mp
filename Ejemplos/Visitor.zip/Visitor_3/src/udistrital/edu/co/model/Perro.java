package udistrital.edu.co.model;

import udistrital.edu.co.model.visitor.Visitor;

public class Perro implements Mascota {
    private String nombre;
    private int edad;

    public Perro(String nombre, int edad) {
        this.nombre = nombre;
        this.edad = edad;
    }

    public String getNombre() {
        return nombre;
    }

    public int getEdad() {
        return edad;
    }

    @Override
    public String aceptar(Visitor visitor) {
        return visitor.visitarPerro(this);
    }
}