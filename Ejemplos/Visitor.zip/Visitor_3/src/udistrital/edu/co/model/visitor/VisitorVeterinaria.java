package udistrital.edu.co.model.visitor;

import udistrital.edu.co.model.Gato;
import udistrital.edu.co.model.Perro;

public class VisitorVeterinaria implements Visitor {

    @Override
    public String visitarPerro(Perro perro) {
        return "Revisando a perro: " + perro.getNombre() + ", Edad: " + perro.getEdad();
    }

    @Override
    public String visitarGato(Gato gato) {
        return "Revisando a gato: " + gato.getNombre() + ", Edad: " + gato.getEdad();
    }
}