package udistrital.edu.co.model.visitor;

import udistrital.edu.co.model.Gato;
import udistrital.edu.co.model.Perro;

public interface Visitor {
    String visitarPerro(Perro perro);
    String visitarGato(Gato gato);
}