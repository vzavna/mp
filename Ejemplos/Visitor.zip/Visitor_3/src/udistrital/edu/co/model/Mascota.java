package udistrital.edu.co.model;

import udistrital.edu.co.model.visitor.Visitor;

public interface Mascota {
    String aceptar(Visitor visitor);
}