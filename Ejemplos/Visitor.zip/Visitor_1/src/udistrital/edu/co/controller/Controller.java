package udistrital.edu.co.controller;

import udistrital.edu.co.view.VistaConsola;
import udistrital.edu.co.model.visitor.*;
import udistrital.edu.co.model.*;

public class Controller {
    private VistaConsola vista;

    public Controller() {
        vista = new VistaConsola();
    }

    public void run() {
        Instrumento piano = new Piano("Yamaha");
        Instrumento tambor = new Tambor("Roland");

        VisitorAfinacion afinador = new VisitorAfinacion();
        VisitorLimpieza limpieza = new VisitorLimpieza();

        vista.mostrarInformacion(piano.aceptar(afinador));
        vista.mostrarInformacion(tambor.aceptar(afinador));

        vista.mostrarInformacion(piano.aceptar(limpieza));
        vista.mostrarInformacion(tambor.aceptar(limpieza));
    }
}
