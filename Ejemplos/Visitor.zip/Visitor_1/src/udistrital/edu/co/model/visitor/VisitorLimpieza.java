package udistrital.edu.co.model.visitor;

import udistrital.edu.co.model.Piano;
import udistrital.edu.co.model.Tambor;

public class VisitorLimpieza implements Visitor {
    public String visitarPiano(Piano p) {
        return "Limpiando teclas del piano: " + p.getNombre();
    }

    public String visitarTambor(Tambor t) {
        return "Limpiando parche del tambor: " + t.getNombre();
    }
}