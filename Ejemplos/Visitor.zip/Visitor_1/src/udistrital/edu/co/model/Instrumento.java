package udistrital.edu.co.model;

import udistrital.edu.co.model.visitor.Visitor;

public interface Instrumento {
    String aceptar(Visitor visitor);
    String getNombre();
}