package udistrital.edu.co.model.visitor;

import udistrital.edu.co.model.Piano;
import udistrital.edu.co.model.Tambor;

public interface Visitor {
    String visitarPiano(Piano p);
    String visitarTambor(Tambor t);
}