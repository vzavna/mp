package udistrital.edu.co.model.visitor;

import udistrital.edu.co.model.Piano;
import udistrital.edu.co.model.Tambor;

public class VisitorAfinacion implements Visitor {
    public String visitarPiano(Piano p) {
        return "Afinando el piano: " + p.getNombre();
    }

    public String visitarTambor(Tambor t) {
        return "Ajustando tensión del tambor: " + t.getNombre();
    }
}