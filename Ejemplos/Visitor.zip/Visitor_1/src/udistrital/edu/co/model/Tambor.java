package udistrital.edu.co.model;

import udistrital.edu.co.model.visitor.Visitor;

public class Tambor implements Instrumento {
    private String nombre;

    public Tambor(String nombre) {
        this.nombre = nombre;
    }

    public String aceptar(Visitor visitor) {
        return visitor.visitarTambor(this);
    }

    public String getNombre() {
        return nombre;
    }
}