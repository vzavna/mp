package udistrital.edu.co.model;

import udistrital.edu.co.model.visitor.Visitor;

public class Piano implements Instrumento {
    private String nombre;

    public Piano(String nombre) {
        this.nombre = nombre;
    }

    public String aceptar(Visitor visitor) {
        return visitor.visitarPiano(this);
    }

    public String getNombre() {
        return nombre;
    }
}