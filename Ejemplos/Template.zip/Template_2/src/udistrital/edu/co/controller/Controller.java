package udistrital.edu.co.controller;

import udistrital.edu.co.model.Entrenamiento;
import udistrital.edu.co.model.EntrenamientoCardio;
import udistrital.edu.co.model.EntrenamientoFuerza;
import udistrital.edu.co.model.EntrenamientoYoga;
import udistrital.edu.co.view.VistaConsola;

public class Controller {
    private VistaConsola vista;

    public Controller() {
        vista = new VistaConsola();
    }

    public void run() {
        vista.mostrarInformacion("=== Rutina de Entrenamiento ===");
        vista.mostrarInformacion("1. Fuerza\n2. Cardio\n3. Yoga");

        String opcion = vista.leerCadenaDeTexto("Elija una opción: ");
        Entrenamiento ent = null;

        switch (opcion) {
            case "1":
                ent = new EntrenamientoFuerza();
                break;
            case "2":
                ent = new EntrenamientoCardio();
                break;
            case "3":
                ent = new EntrenamientoYoga();
                break;
            default:
                vista.mostrarInformacion("Opción inválida");
                return;
        }

        vista.mostrarInformacion("\nIniciando entrenamiento...\n");
        vista.mostrarInformacion(ent.realizarEntrenamiento());
    }
}