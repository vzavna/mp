package udistrital.edu.co.model;

public class EntrenamientoCardio extends Entrenamiento {

    @Override
    protected String calentar() {
        return "Calentamiento con trote suave...\n";
    }

    @Override
    protected String ejercicioPrincipal() {
        return "Ejercicio principal: correr 5km...\n";
    }

    @Override
    protected String estiramiento() {
        return "Estiramiento de pantorrillas...\n";
    }

    @Override
    protected String descanso() {
        return "Respiración profunda y recuperación...\n";
    }
}
