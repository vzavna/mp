package udistrital.edu.co.model;

public class EntrenamientoFuerza extends Entrenamiento {

    @Override
    protected String calentar() {
        return "Calentamiento con pesas ligeras...\n";
    }

    @Override
    protected String ejercicioPrincipal() {
        return "Ejercicio principal: sentadillas y press de banca...\n";
    }

    @Override
    protected String estiramiento() {
        return "Estiramiento de piernas y brazos...\n";
    }

    @Override
    protected String descanso() {
        return "Descansando después del entrenamiento...\n";
    }
}