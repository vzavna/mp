package udistrital.edu.co.model;

public abstract class Entrenamiento {

    public final String realizarEntrenamiento() {
        return calentar() + ejercicioPrincipal() + estiramiento() + descanso();
    }

    protected abstract String calentar();
    protected abstract String ejercicioPrincipal();
    protected abstract String estiramiento();
    protected abstract String descanso();
}