package udistrital.edu.co.model;

public class EntrenamientoYoga extends Entrenamiento {

    @Override
    protected String calentar() {
        return "Respiración consciente para iniciar...\n";
    }

    @Override
    protected String ejercicioPrincipal() {
        return "Ejercicio principal: secuencia de asanas...\n";
    }

    @Override
    protected String estiramiento() {
        return "Estiramiento suave de espalda y cuello...\n";
    }

    @Override
    protected String descanso() {
        return "Meditación final (Savasana)...\n";
    }
}