package udistrital.edu.co.model;

public class PastelFresa extends Pastel {

    @Override
    protected String mezclarIngredientes() {
        return "Mezclando puré de fresas y harina...\n";
    }

    @Override
    protected String hornear() {
        return "Horneando pastel de fresa...\n";
    }

    @Override
    protected String decorar() {
        return "Decorando con crema rosada y fresas...\n";
    }

    @Override
    protected String servir() {
        return "Sirviendo pastel de fresa.\n";
    }
}