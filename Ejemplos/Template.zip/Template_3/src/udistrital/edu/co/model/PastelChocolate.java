package udistrital.edu.co.model;

public class PastelChocolate extends Pastel {

    @Override
    protected String mezclarIngredientes() {
        return "Mezclando cacao, harina y huevos...\n";
    }

    @Override
    protected String hornear() {
        return "Horneando el pastel de chocolate...\n";
    }

    @Override
    protected String decorar() {
        return "Decorando con chispas de chocolate...\n";
    }

    @Override
    protected String servir() {
        return "Sirviendo pastel de chocolate.\n";
    }
}
