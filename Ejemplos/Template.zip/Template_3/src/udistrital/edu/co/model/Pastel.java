package udistrital.edu.co.model;

public abstract class Pastel {

    public final String preparar() {
        return mezclarIngredientes() + hornear() + decorar() + servir();
    }

    protected abstract String mezclarIngredientes();
    protected abstract String hornear();
    protected abstract String decorar();
    protected abstract String servir();
}