package udistrital.edu.co.model;

public class PastelVainilla extends Pastel {

    @Override
    protected String mezclarIngredientes() {
        return "Mezclando esencia de vainilla, harina y leche...\n";
    }

    @Override
    protected String hornear() {
        return "Horneando pastel de vainilla...\n";
    }

    @Override
    protected String decorar() {
        return "Decorando con glaseado blanco...\n";
    }

    @Override
    protected String servir() {
        return "Sirviendo pastel de vainilla.\n";
    }
}