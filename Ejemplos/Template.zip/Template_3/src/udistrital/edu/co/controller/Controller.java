package udistrital.edu.co.controller;

import udistrital.edu.co.model.Pastel;
import udistrital.edu.co.model.PastelChocolate;
import udistrital.edu.co.model.PastelFresa;
import udistrital.edu.co.model.PastelVainilla;
import udistrital.edu.co.view.VistaConsola;

public class Controller {
    private VistaConsola vista;

    public Controller() {
        vista = new VistaConsola();
    }

    public void run() {
        vista.mostrarInformacion("=== Preparador de Pasteles ===");
        vista.mostrarInformacion("1. Chocolate\n2. Vainilla\n3. Fresa");

        String opcion = vista.leerCadenaDeTexto("Seleccione el pastel: ");
        Pastel pastel = null;

        switch (opcion) {
            case "1":
                pastel = new PastelChocolate();
                break;
            case "2":
                pastel = new PastelVainilla();
                break;
            case "3":
                pastel = new PastelFresa();
                break;
            default:
                vista.mostrarInformacion("Opción inválida");
                return;
        }

        vista.mostrarInformacion("\nPreparando pastel...\n");
        vista.mostrarInformacion(pastel.preparar());
    }
}