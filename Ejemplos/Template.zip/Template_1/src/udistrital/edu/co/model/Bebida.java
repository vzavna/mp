package udistrital.edu.co.model;

public abstract class Bebida {

    public final String preparar() {
        return hervirAgua() + agregarIngrediente() + mezclar() + servir();
    }

    protected abstract String hervirAgua();
    protected abstract String agregarIngrediente();
    protected abstract String mezclar();
    protected abstract String servir();
}