package udistrital.edu.co.model;

public class Cafe extends Bebida {

    @Override
    protected String hervirAgua() {
        return "Hirviendo agua para el café...\n";
    }

    @Override
    protected String agregarIngrediente() {
        return "Agregando café molido...\n";
    }

    @Override
    protected String mezclar() {
        return "Mezclando el café...\n";
    }

    @Override
    protected String servir() {
        return "Sirviendo el café caliente en la taza.\n";
    }
}