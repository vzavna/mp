package udistrital.edu.co.model;

public class Chocolate extends Bebida {

    @Override
    protected String hervirAgua() {
        return "Hirviendo leche para el chocolate...\n";
    }

    @Override
    protected String agregarIngrediente() {
        return "Agregando chocolate en polvo...\n";
    }

    @Override
    protected String mezclar() {
        return "Mezclando el chocolate...\n";
    }

    @Override
    protected String servir() {
        return "Sirviendo el chocolate caliente.\n";
    }
}