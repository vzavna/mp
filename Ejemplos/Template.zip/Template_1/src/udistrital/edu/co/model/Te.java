package udistrital.edu.co.model;

public class Te extends Bebida {

    @Override
    protected String hervirAgua() {
        return "Hirviendo agua para el té...\n";
    }

    @Override
    protected String agregarIngrediente() {
        return "Agregando bolsita de té...\n";
    }

    @Override
    protected String mezclar() {
        return "Mezclando con una cucharita...\n";
    }

    @Override
    protected String servir() {
        return "Sirviendo el té caliente en la taza.\n";
    }
}