package udistrital.edu.co.controller;

import udistrital.edu.co.model.Bebida;
import udistrital.edu.co.model.Cafe;
import udistrital.edu.co.model.Chocolate;
import udistrital.edu.co.model.Te;
import udistrital.edu.co.view.VistaConsola;

public class Controller {
    private VistaConsola vista;

    public Controller() {
        vista = new VistaConsola();
    }

    public void run() {
        vista.mostrarInformacion("=== Preparador de Bebidas ===");
        vista.mostrarInformacion("1. Té\n2. Café\n3. Chocolate");

        String opcion = vista.leerCadenaDeTexto("Elija una opción: ");
        Bebida bebida = null;

        switch (opcion) {
            case "1":
                bebida = new Te();
                break;
            case "2":
                bebida = new Cafe();
                break;
            case "3":
                bebida = new Chocolate();
                break;
            default:
                vista.mostrarInformacion("Opción inválida");
                return;
        }

        vista.mostrarInformacion("\nPreparando bebida...\n");
        vista.mostrarInformacion(bebida.preparar());
    }
}