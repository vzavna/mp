package udistrital.edu.co.model;

public class ReproducirMusica implements Comando {
    private Reproductor reproductor;

    public ReproducirMusica(Reproductor reproductor) {
        this.reproductor = reproductor;
    }

    @Override
    public String ejecutar() {
        return reproductor.reproducir();
    }
}