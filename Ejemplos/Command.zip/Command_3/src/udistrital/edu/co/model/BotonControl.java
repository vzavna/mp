package udistrital.edu.co.model;

public class BotonControl {
    private Comando comando;

    public void setComando(Comando comando) {
        this.comando = comando;
    }

    public String presionar() {
        return comando.ejecutar();
    }
}