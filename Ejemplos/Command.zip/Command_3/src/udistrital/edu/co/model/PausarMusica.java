package udistrital.edu.co.model;

public class PausarMusica implements Comando {
    private Reproductor reproductor;

    public PausarMusica(Reproductor reproductor) {
        this.reproductor = reproductor;
    }

    @Override
    public String ejecutar() {
        return reproductor.pausar();
    }
}