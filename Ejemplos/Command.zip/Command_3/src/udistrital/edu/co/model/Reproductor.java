package udistrital.edu.co.model;

public class Reproductor {
    public String reproducir() {
        return "Reproduciendo música.";
    }

    public String pausar() {
        return "Música en pausa.";
    }
}