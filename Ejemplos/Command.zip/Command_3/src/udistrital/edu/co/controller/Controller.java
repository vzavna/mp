package udistrital.edu.co.controller;

import udistrital.edu.co.model.BotonControl;
import udistrital.edu.co.model.PausarMusica;
import udistrital.edu.co.model.ReproducirMusica;
import udistrital.edu.co.model.Reproductor;
import udistrital.edu.co.view.VistaConsola;

public class Controller {
    private VistaConsola vista;

    public Controller() {
        vista = new VistaConsola();
    }

    public void run() {
        Reproductor reproductor = new Reproductor();
        BotonControl boton = new BotonControl();

        vista.mostrarInformacion("1. Reproducir\n2. Pausar");
        String opcion = vista.leerCadenaDeTexto("Seleccione una opción: ");

        switch (opcion) {
            case "1":
                boton.setComando(new ReproducirMusica(reproductor));
                break;
            case "2":
                boton.setComando(new PausarMusica(reproductor));
                break;
            default:
                vista.mostrarInformacion("Opción inválida.");
                return;
        }

        vista.mostrarInformacion(boton.presionar());
    }
}
