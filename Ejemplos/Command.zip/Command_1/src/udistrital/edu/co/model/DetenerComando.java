package udistrital.edu.co.model;

public class DetenerComando implements Comando {
    private Robot robot;

    public DetenerComando(Robot robot) {
        this.robot = robot;
    }

    @Override
    public String ejecutar() {
        return robot.detenerse();
    }
}