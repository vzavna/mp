package udistrital.edu.co.model;

public class Robot {
    public String avanzar() {
        return "El robot avanza.";
    }

    public String detenerse() {
        return "El robot se detiene.";
    }
}