package udistrital.edu.co.controller;

import udistrital.edu.co.model.AvanzarComando;
import udistrital.edu.co.model.ControlRemoto;
import udistrital.edu.co.model.DetenerComando;
import udistrital.edu.co.model.Robot;
import udistrital.edu.co.view.VistaConsola;

public class Controller {
    private VistaConsola vista;

    public Controller() {
        vista = new VistaConsola();
    }

    public void run() {
        Robot robot = new Robot();
        ControlRemoto control = new ControlRemoto();

        vista.mostrarInformacion("1. Avanzar\n2. Detenerse");
        String opcion = vista.leerCadenaDeTexto("Seleccione una opción: ");

        switch (opcion) {
            case "1":
                control.setComando(new AvanzarComando(robot));
                break;
            case "2":
                control.setComando(new DetenerComando(robot));
                break;
            default:
                vista.mostrarInformacion("Opción inválida.");
                return;
        }

        vista.mostrarInformacion(control.presionar());
    }
}
