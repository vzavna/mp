package udistrital.edu.co.model;

public class EncenderTV implements Comando {
    private Televisor tv;

    public EncenderTV(Televisor tv) {
        this.tv = tv;
    }

    @Override
    public String ejecutar() {
        return tv.encender();
    }
}