package udistrital.edu.co.model;

public interface Comando {
	 String ejecutar();
}
