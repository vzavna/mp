package udistrital.edu.co.model;

public class Televisor {
    public String encender() {
        return "TV encendida.";
    }

    public String apagar() {
        return "TV apagada.";
    }
}