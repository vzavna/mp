package udistrital.edu.co.model;

public class ApagarTV implements Comando {
    private Televisor tv;

    public ApagarTV(Televisor tv) {
        this.tv = tv;
    }

    @Override
    public String ejecutar() {
        return tv.apagar();
    }
}