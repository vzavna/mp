package udistrital.edu.co.controller;

import udistrital.edu.co.model.ApagarTV;
import udistrital.edu.co.model.ControlRemoto;
import udistrital.edu.co.model.EncenderTV;
import udistrital.edu.co.model.Televisor;
import udistrital.edu.co.view.VistaConsola;

public class Controller {
    private VistaConsola vista;

    public Controller() {
        vista = new VistaConsola();
    }

    public void run() {
        Televisor tv = new Televisor();
        ControlRemoto control = new ControlRemoto();

        vista.mostrarInformacion("1. Encender\n2. Apagar");
        String opcion = vista.leerCadenaDeTexto("Seleccione una opción: ");

        switch (opcion) {
            case "1":
                control.setComando(new EncenderTV(tv));
                break;
            case "2":
                control.setComando(new ApagarTV(tv));
                break;
            default:
                vista.mostrarInformacion("Opción inválida.");
                return;
        }

        vista.mostrarInformacion(control.presionar());
    }
}