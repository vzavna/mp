package co.edu.udistrital.controller;

import co.edu.udistrital.model.Libro;
import co.edu.udistrital.view.VistaConsola;

public class Controller {

    private VistaConsola vista;

    public Controller() {
        vista = new VistaConsola();
    }

    public void run() {
        Libro l1 = new Libro("Cien años de soledad");
        vista.mostrarInformacion("Título libro 1: " + l1.getTitulo());

        Libro l2 = new Libro("El principito");
        l2 = l1;

        vista.mostrarInformacion("Título libro 2 (después de asignar l1): " + l2.getTitulo());

        l1.setTitulo("Don Quijote");
        vista.mostrarInformacion("Título libro 1 modificado: " + l1.getTitulo());
        vista.mostrarInformacion("Título libro 2 tras cambio en libro 1: " + l2.getTitulo());
    }
}
