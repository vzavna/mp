package co.edu.udistrital.controller;

import co.edu.udistrital.model.Carro;
import co.edu.udistrital.view.VistaConsola;

public class Controller {

    private VistaConsola vista;

    public Controller() {
        vista = new VistaConsola();
    }

    public void run() {
        Carro c1 = new Carro("ABC123");
        vista.mostrarInformacion("Placa carro 1: " + c1.getPlaca());

        Carro c2 = new Carro("XYZ987");
        c2 = c1;

        vista.mostrarInformacion("Placa carro 2 (después de asignar c1): " + c2.getPlaca());

        c1.setPlaca("LMN456");
        vista.mostrarInformacion("Placa carro 1 modificada: " + c1.getPlaca());
        vista.mostrarInformacion("Placa carro 2 tras cambio en carro 1: " + c2.getPlaca());
    }
}
