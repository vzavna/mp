package co.edu.udistrital.model;

public class Carro {
    private String placa;

    public Carro(String placa) {
        this.placa = placa;
    }

    public void setPlaca(String placa) {
        this.placa = placa;
    }

    public String getPlaca() {
        return placa;
    }
}
