package co.edu.udistrital.controller;

import co.edu.udistrital.model.Persona;
import co.edu.udistrital.view.VistaConsola;

public class Controller {

    private VistaConsola vista;

    public Controller() {
        vista = new VistaConsola();
    }

    public void run() {
        Persona p1 = new Persona("Juan");
        vista.mostrarInformacion("Nombre persona 1: " + p1.getNombre());

        Persona p2 = new Persona("Maria");
        p2 = p1;

        vista.mostrarInformacion("Nombre persona 2 (después de asignar p1): " + p2.getNombre());

        p1.setNombre("Pedro");
        vista.mostrarInformacion("Nombre persona 1 modificado: " + p1.getNombre());
        vista.mostrarInformacion("Nombre persona 2 tras cambio en persona 1: " + p2.getNombre());
    }
}
