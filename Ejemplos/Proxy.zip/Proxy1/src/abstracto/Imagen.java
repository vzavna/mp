package abstracto;

public interface Imagen {
    void mostrar();
}
