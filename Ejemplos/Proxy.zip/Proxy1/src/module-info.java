/**
 * 
 */
/**
 * 
 */
module Proxy1 {
	requires java.desktop;
}