package practicaProxy;

public class AplMain {
    public static void main(String[] args) {
        VisorImagenes visor = new VisorImagenes();
        visor.setVisible(true);
    }
}