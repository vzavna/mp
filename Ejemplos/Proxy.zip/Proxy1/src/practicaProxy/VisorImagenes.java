package practicaProxy;


import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JPanel;

import realProxy.ImagenProxy;

public class VisorImagenes extends JFrame implements ActionListener {
    
	private static final long serialVersionUID = 1L;
	private JButton btnMostrarImagen1;
    private JButton btnMostrarImagen2;
    private ImagenProxy proxy1;
    private ImagenProxy proxy2;

    public VisorImagenes() {
        this.setTitle("Visor de Imágenes con Proxy");
        this.setSize(400, 200);
        this.setDefaultCloseOperation(EXIT_ON_CLOSE);
        
        proxy1 = new ImagenProxy("imagen1.jpg");
        proxy2 = new ImagenProxy("imagen2.jpg");
        
        JPanel panel = new JPanel();
        btnMostrarImagen1 = new JButton("Mostrar Imagen 1");
        btnMostrarImagen2 = new JButton("Mostrar Imagen 2");
        
        btnMostrarImagen1.addActionListener(this);
        btnMostrarImagen2.addActionListener(this);
        
        panel.add(btnMostrarImagen1);
        panel.add(btnMostrarImagen2);
        this.add(panel);
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        if (e.getSource() == btnMostrarImagen1) {
            proxy1.mostrar();
        } else if (e.getSource() == btnMostrarImagen2) {
            proxy2.mostrar();
        }
    }
}