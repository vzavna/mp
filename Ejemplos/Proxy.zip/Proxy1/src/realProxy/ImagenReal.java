package realProxy;

import abstracto.Imagen;
import javax.swing.ImageIcon;
import javax.swing.JOptionPane;

public class ImagenReal implements Imagen {
    private String nombreArchivo;

    public ImagenReal(String nombreArchivo) {
        this.nombreArchivo = nombreArchivo;
        cargarDesdeDisco();
    }

    private void cargarDesdeDisco() {
        System.out.println("Cargando imagen: " + nombreArchivo);
    }

    @Override
    public void mostrar() {
        ImageIcon icon = new ImageIcon("images/" + nombreArchivo);
        JOptionPane.showMessageDialog(null, icon, "Imagen Real", JOptionPane.PLAIN_MESSAGE);
    }
}