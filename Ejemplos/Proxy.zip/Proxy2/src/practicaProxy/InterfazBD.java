package practicaProxy;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;

import realProxy.BaseDatosProxy;

public class InterfazBD extends JFrame implements ActionListener {
    
	private static final long serialVersionUID = 1L;
	private JTextField txtUsuario;
    private JTextField txtContrasena;
    private JTextField txtConsulta;
    private JButton btnEjecutar;
    private JLabel lblResultado;
    private BaseDatosProxy proxy;

    public InterfazBD() {
        this.setTitle("Acceso a Base de Datos");
        this.setSize(500, 300);
        this.setDefaultCloseOperation(EXIT_ON_CLOSE);
        
        JPanel panel = new JPanel();
        panel.setLayout(null);
        
        txtUsuario = new JTextField();
        txtUsuario.setBounds(150, 20, 200, 25);
        panel.add(new JLabel("Usuario:")).setBounds(20, 20, 100, 25);
        panel.add(txtUsuario);
        
        txtContrasena = new JTextField();
        txtContrasena.setBounds(150, 50, 200, 25);
        panel.add(new JLabel("Contraseña:")).setBounds(20, 50, 100, 25);
        panel.add(txtContrasena);
        
        txtConsulta = new JTextField();
        txtConsulta.setBounds(150, 80, 200, 25);
        panel.add(new JLabel("Consulta:")).setBounds(20, 80, 100, 25);
        panel.add(txtConsulta);
        
        btnEjecutar = new JButton("Ejecutar Consulta");
        btnEjecutar.setBounds(150, 120, 200, 30);
        btnEjecutar.addActionListener(this);
        panel.add(btnEjecutar);
        
        lblResultado = new JLabel();
        lblResultado.setBounds(20, 160, 450, 50);
        panel.add(lblResultado);
        
        this.add(panel);
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        if (e.getSource() == btnEjecutar) {
            proxy = new BaseDatosProxy(txtUsuario.getText(), txtContrasena.getText());
            String resultado = proxy.consulta(txtConsulta.getText());
            lblResultado.setText(resultado);
        }
    }
}