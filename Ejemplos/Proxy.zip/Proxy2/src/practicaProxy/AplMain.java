package practicaProxy;

public class AplMain {
    public static void main(String[] args) {
        InterfazBD interfaz = new InterfazBD();
        interfaz.setVisible(true);
    }
}