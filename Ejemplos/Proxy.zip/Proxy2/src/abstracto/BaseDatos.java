package abstracto;

public interface BaseDatos {
    String consulta(String query);
}