/**
 * 
 */
/**
 * 
 */
module Proxy2 {
	requires java.desktop;
}