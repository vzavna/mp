package realProxy;

import abstracto.BaseDatos;
import javax.swing.JOptionPane;

public class BaseDatosProxy implements BaseDatos {
    private BaseDatosReal baseDatosReal;
    private String usuario;
    private String contrasena;
    
    public BaseDatosProxy(String usuario, String contrasena) {
        this.usuario = usuario;
        this.contrasena = contrasena;
    }
    
    private boolean verificarAcceso() {
        return "admin".equals(usuario) && "1234".equals(contrasena);
    }
    
    @Override
    public String consulta(String query) {
        if (verificarAcceso()) {
            if (baseDatosReal == null) {
                baseDatosReal = new BaseDatosReal();
            }
            return baseDatosReal.consulta(query);
        } else {
            JOptionPane.showMessageDialog(null, "Acceso denegado");
            return "Acceso denegado";
        }
    }
}