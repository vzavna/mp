package realProxy;

import abstracto.BaseDatos;

public class BaseDatosReal implements BaseDatos {
    public BaseDatosReal() {
        conectar();
    }
    
    private void conectar() {
        System.out.println("Conectando a la base de datos...");
    }
    
    @Override
    public String consulta(String query) {
        System.out.println("Ejecutando consulta: " + query);
        return "Resultados para: " + query;
    }
}