package realProxy;

import abstracto.Video;
import javax.swing.JOptionPane;

public class VideoProxy implements Video {
    private VideoReal videoReal;
    private String nombreArchivo;
    
    public VideoProxy(String nombreArchivo) {
        this.nombreArchivo = nombreArchivo;
    }
    
    @Override
    public void reproducir() {
        if (videoReal == null) {
            JOptionPane.showMessageDialog(null, "Descargando video: " + nombreArchivo + "...");
            videoReal = new VideoReal(nombreArchivo);
        }
        videoReal.reproducir();
    }
}