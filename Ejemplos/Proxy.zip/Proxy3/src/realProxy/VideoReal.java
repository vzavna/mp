package realProxy;

import abstracto.Video;
import javax.swing.JOptionPane;

public class VideoReal implements Video {
    private String nombreArchivo;
    
    public VideoReal(String nombreArchivo) {
        this.nombreArchivo = nombreArchivo;
        cargarVideo();
    }
    
    private void cargarVideo() {
        System.out.println("Cargando video: " + nombreArchivo);
    }
    
    @Override
    public void reproducir() {
        JOptionPane.showMessageDialog(null, "Reproduciendo video: " + nombreArchivo);
    }
}