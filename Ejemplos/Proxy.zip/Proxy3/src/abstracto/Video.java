package abstracto;

public interface Video {
    void reproducir();
}