package practicaProxy;


import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JPanel;

import realProxy.VideoProxy;

public class ReproductorVideo extends JFrame implements ActionListener {
    
	private static final long serialVersionUID = 1L;
	private JButton btnReproducir1;
    private JButton btnReproducir2;
    private VideoProxy proxy1;
    private VideoProxy proxy2;
    
    public ReproductorVideo() {
        this.setTitle("Reproductor de Videos con Proxy");
        this.setSize(400, 200);
        this.setDefaultCloseOperation(EXIT_ON_CLOSE);
        
        proxy1 = new VideoProxy("video1.mp4");
        proxy2 = new VideoProxy("video2.mp4");
        
        JPanel panel = new JPanel();
        btnReproducir1 = new JButton("Reproducir Video 1");
        btnReproducir2 = new JButton("Reproducir Video 2");
        
        btnReproducir1.addActionListener(this);
        btnReproducir2.addActionListener(this);
        
        panel.add(btnReproducir1);
        panel.add(btnReproducir2);
        this.add(panel);
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        if (e.getSource() == btnReproducir1) {
            proxy1.reproducir();
        } else if (e.getSource() == btnReproducir2) {
            proxy2.reproducir();
        }
    }
}