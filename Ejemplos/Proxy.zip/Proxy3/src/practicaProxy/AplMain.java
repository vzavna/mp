package practicaProxy;

public class AplMain {
    public static void main(String[] args) {
        ReproductorVideo reproductor = new ReproductorVideo();
        reproductor.setVisible(true);
    }
}