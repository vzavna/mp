package udistrital.edu.co.model;

public interface CentroEnviosInterfaz {
    void agregar(ClienteInterfaz obs);
    void eliminar(ClienteInterfaz obs);
    String notificar();
}