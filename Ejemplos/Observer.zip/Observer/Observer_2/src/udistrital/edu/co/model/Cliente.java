package udistrital.edu.co.model;

public class Cliente implements ClienteInterfaz {
    private String nombre;
    private CentroEnvios centro;

    public Cliente(String nombre, CentroEnvios centro) {
        this.nombre = nombre;
        this.centro = centro;
    }

    @Override
    public String actualizar() {
        return "Cliente " + nombre + " fue notificado: " + centro.getEstadoPaquete();
    }
}