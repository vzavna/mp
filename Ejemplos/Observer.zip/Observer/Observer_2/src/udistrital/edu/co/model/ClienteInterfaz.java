package udistrital.edu.co.model;

public interface ClienteInterfaz {
    String actualizar();
}