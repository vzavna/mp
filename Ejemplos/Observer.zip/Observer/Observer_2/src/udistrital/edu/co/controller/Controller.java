package udistrital.edu.co.controller;

import udistrital.edu.co.model.CentroEnvios;
import udistrital.edu.co.model.Cliente;
import udistrital.edu.co.view.VistaConsola;

public class Controller {
    private VistaConsola vista;

    public Controller() {
        vista = new VistaConsola();
    }

    public void run() {
        vista.mostrarInformacion("=== Sistema de seguimiento de paquetes ===");

        CentroEnvios centro = new CentroEnvios();

        String nombre = vista.leerCadenaDeTexto("Ingrese el nombre del cliente: ");
        Cliente cliente = new Cliente(nombre, centro);
        centro.agregar(cliente);

        String estado = vista.leerCadenaDeTexto("Ingrese el estado actual del paquete: ");
        centro.setEstadoPaquete(estado);

        vista.mostrarInformacion("Enviando notificación...");
        vista.mostrarInformacion(centro.notificar());
    }
}