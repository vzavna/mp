package udistrital.edu.co.model;

import java.util.ArrayList;

public class CentroEnvios implements CentroEnviosInterfaz {
    private String estadoPaquete;
    private ArrayList<ClienteInterfaz> lista;

    public CentroEnvios() {
        lista = new ArrayList<>();
    }

    @Override
    public void agregar(ClienteInterfaz obs) {
        lista.add(obs);
    }

    @Override
    public void eliminar(ClienteInterfaz obs) {
        lista.remove(obs);
    }

    @Override
    public String notificar() {
        StringBuilder sb = new StringBuilder();
        for (ClienteInterfaz c : lista) {
            sb.append(c.actualizar()).append("\n");
        }
        return sb.toString();
    }

    public String getEstadoPaquete() {
        return estadoPaquete;
    }

    public void setEstadoPaquete(String estadoPaquete) {
        this.estadoPaquete = estadoPaquete;
    }
}