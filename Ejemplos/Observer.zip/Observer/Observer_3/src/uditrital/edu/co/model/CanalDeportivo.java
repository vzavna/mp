package uditrital.edu.co.model;

import java.util.ArrayList;

public class CanalDeportivo implements CanalDeportivoInterfaz {
    private String ultimoEvento;
    private ArrayList<FanaticoInterfaz> lista;

    public CanalDeportivo() {
        lista = new ArrayList<>();
    }

    @Override
    public void agregar(FanaticoInterfaz obs) {
        lista.add(obs);
    }

    @Override
    public void eliminar(FanaticoInterfaz obs) {
        lista.remove(obs);
    }

    @Override
    public String notificar() {
        StringBuilder sb = new StringBuilder();
        for (FanaticoInterfaz f : lista) {
            sb.append(f.actualizar()).append("\n");
        }
        return sb.toString();
    }

    public String getUltimoEvento() {
        return ultimoEvento;
    }

    public void setUltimoEvento(String ultimoEvento) {
        this.ultimoEvento = ultimoEvento;
    }
}