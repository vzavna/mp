package uditrital.edu.co.model;

public class Fanatico implements FanaticoInterfaz {
    private String nombre;
    private CanalDeportivo canal;

    public Fanatico(String nombre, CanalDeportivo canal) {
        this.nombre = nombre;
        this.canal = canal;
    }

    @Override
    public String actualizar() {
        return "Fanático " + nombre + " fue notificado: " + canal.getUltimoEvento();
    }
}