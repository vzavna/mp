package uditrital.edu.co.model;

public interface FanaticoInterfaz {
    String actualizar();
}