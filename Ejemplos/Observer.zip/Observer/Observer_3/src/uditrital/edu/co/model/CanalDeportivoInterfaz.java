package uditrital.edu.co.model;

public interface CanalDeportivoInterfaz {
    void agregar(FanaticoInterfaz obs);
    void eliminar(FanaticoInterfaz obs);
    String notificar();
}