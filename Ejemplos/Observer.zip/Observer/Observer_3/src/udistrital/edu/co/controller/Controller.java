package udistrital.edu.co.controller;

import udistrital.edu.co.view.VistaConsola;
import uditrital.edu.co.model.CanalDeportivo;
import uditrital.edu.co.model.Fanatico;

public class Controller {
    private VistaConsola vista;

    public Controller() {
        vista = new VistaConsola();
    }

    public void run() {
        vista.mostrarInformacion("=== Notificaciones deportivas ===");

        CanalDeportivo canal = new CanalDeportivo();

        String nombre = vista.leerCadenaDeTexto("Nombre del fanático: ");
        Fanatico f = new Fanatico(nombre, canal);
        canal.agregar(f);

        String evento = vista.leerCadenaDeTexto("Nuevo evento deportivo (ej. Gol, Finaliza partido): ");
        canal.setUltimoEvento(evento);

        vista.mostrarInformacion("Enviando notificaciones...");
        vista.mostrarInformacion(canal.notificar());
    }
}