package udistrital.edu.co.model;
import java.util.ArrayList;

public class CentroAlertas implements CentroAlertasInterfaz {
    private String ultimaPosicion;
    private ArrayList<EstudianteInterfaz> lista;

    public CentroAlertas() {
        this.lista = new ArrayList<>();
    }

    @Override
    public void agregar(EstudianteInterfaz obs) {
        lista.add(obs);
    }

    @Override
    public void eliminar(EstudianteInterfaz obs) {
        lista.remove(obs);
    }

    @Override
    public String notificar() {
        StringBuilder sb = new StringBuilder();
        for (EstudianteInterfaz o : lista) {
            sb.append(o.actualizar()).append("\n");
        }
        return sb.toString();
    }

    public String getUltimaPosicion() {
        return ultimaPosicion;
    }

    public void setUltimaPosicion(String ultimaPosicion) {
        this.ultimaPosicion = ultimaPosicion;
    }
}