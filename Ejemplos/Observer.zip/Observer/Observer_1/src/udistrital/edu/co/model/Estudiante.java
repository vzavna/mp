package udistrital.edu.co.model;

public class Estudiante implements EstudianteInterfaz{
    private String nombre;
    private CentroAlertas centroAlertas;

    public Estudiante(String nombre, CentroAlertas centroAlertas) {
        this.nombre = nombre;
        this.centroAlertas = centroAlertas;
    }

    @Override
    public String actualizar() {
        return "Estudiante " + nombre + " recibió alerta: " + centroAlertas.getUltimaPosicion();
    }

    // Getters & Setters
    public String getNombre() {
        return nombre;
    }

    public CentroAlertas getCentroAlertas() {
        return centroAlertas;
    }

    public void setCentroAlertas(CentroAlertas centroAlertas) {
        this.centroAlertas = centroAlertas;
    }
}