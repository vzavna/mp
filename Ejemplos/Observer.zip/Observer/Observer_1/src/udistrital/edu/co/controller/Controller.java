package udistrital.edu.co.controller;

import udistrital.edu.co.model.Estudiante;
import udistrital.edu.co.model.CentroAlertas;
import udistrital.edu.co.view.VistaConsola;

public class Controller {
    private VistaConsola vista;

    public Controller() {
        vista = new VistaConsola();
    }

    public void run() {
        vista.mostrarInformacion("=== Sistema de Alerta Escolar ===");

        CentroAlertas ubicacion = new CentroAlertas();

        String nombreEstudiante = vista.leerCadenaDeTexto("Nombre del estudiante: ");
        Estudiante obs = new Estudiante(nombreEstudiante, ubicacion);
        ubicacion.agregar(obs);

        String mensajeAlerta = vista.leerCadenaDeTexto("Mensaje de alerta (ej. Simulacro de evacuación): ");
        ubicacion.setUltimaPosicion(mensajeAlerta);

        vista.mostrarInformacion("Enviando notificación...");
        vista.mostrarInformacion(ubicacion.notificar());
    }
}