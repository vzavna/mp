package udistrital.edu.co.model;

;
public interface CentroAlertasInterfaz {
    void agregar(EstudianteInterfaz obs);
    void eliminar(EstudianteInterfaz obs);
    String notificar();
}