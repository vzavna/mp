package udistrital.edu.co.model;

public interface EstudianteInterfaz {
    String actualizar();
}