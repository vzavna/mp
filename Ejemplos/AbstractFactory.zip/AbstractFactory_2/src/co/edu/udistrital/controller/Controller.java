package co.edu.udistrital.controller;

//import java.util.Scanner;

import co.edu.udistrital.model.abstracto.Comida;
import co.edu.udistrital.model.abstracto.Juguete;
import co.edu.udistrital.model.abstracto.MascotaFactory;
import co.edu.udistrital.model.concetroCreador.GatoCreador;
import co.edu.udistrital.model.concetroCreador.PerroCreador;
import co.edu.udistrital.view.VistaConsola;

public class Controller {
    private VistaConsola vista;
    //private Scanner scanner;

    public Controller() {
        this.vista = new VistaConsola();
        //this.scanner = new Scanner(System.in);
    }
		
	public void run() {
		
		
		vista.mostrarDato("que mascota tiene? (perro/gato)");
		String mascota = vista.leerDato().toLowerCase();
		
		MascotaFactory fabrica = null;
		
		switch(mascota) {
		case "perro":
			fabrica = new PerroCreador();
			break;
		case "gato":
			fabrica = new GatoCreador();
			break;
		default:
			break;
		}
		
		Juguete juguete = fabrica.crearJuguete(mascota, mascota);
		Comida comida = fabrica.crearComida(mascota, mascota);
		
		vista.mostrarDato("El kit para su mascota es: \n" + comida.getMarca() + " de " + comida.getSabor() + "\n" + juguete.getTipo() +" " + juguete.getColor() +"\n" );
	}
	
	
}
