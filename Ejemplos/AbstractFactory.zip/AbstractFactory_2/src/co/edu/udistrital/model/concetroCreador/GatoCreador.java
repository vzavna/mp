package co.edu.udistrital.model.concetroCreador;
import co.edu.udistrital.model.ComidaGato;
import co.edu.udistrital.model.JugueteGato;
import co.edu.udistrital.model.abstracto.Comida;
import co.edu.udistrital.model.abstracto.Juguete;
import co.edu.udistrital.model.abstracto.MascotaFactory;

public class GatoCreador implements MascotaFactory{

	

	@Override
	public Juguete crearJuguete(String color, String tipo) {
		return new JugueteGato(color, tipo);
	}

	

	@Override
	public Comida crearComida(String sabor, String marca) {
		return new ComidaGato(sabor, marca);
	}
	
}
