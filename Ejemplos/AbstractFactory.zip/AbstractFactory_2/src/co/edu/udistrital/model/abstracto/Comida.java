package co.edu.udistrital.model.abstracto;

public abstract class Comida {

	protected String sabor;
	protected String marca;
	
	public Comida(String sabor, String marca) {
		this.marca = marca;
		this.sabor = sabor;
	}

	public String getSabor() {
		return sabor;
	}

	public void setSabor(String sabor) {
		this.sabor = sabor;
	}

	public String getMarca() {
		return marca;
	}

	public void setMarca(String marca) {
		this.marca = marca;
	}
	
	
}
