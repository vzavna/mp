package co.edu.udistrital.model;

import co.edu.udistrital.model.abstracto.Comida;

public class ComidaGato extends Comida {
	
	public ComidaGato(String sabor, String marca) {
		super(sabor, marca);
	}
	
	public String getSabor() {
		return "salmon";
	}


	public String getMarca() {
		return "monello";
	}

}
