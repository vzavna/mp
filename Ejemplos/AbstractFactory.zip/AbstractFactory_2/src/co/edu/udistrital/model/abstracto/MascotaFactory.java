package co.edu.udistrital.model.abstracto;

public interface MascotaFactory {

	Juguete crearJuguete(String color, String tipo);
	
	Comida crearComida(String sabor, String marca);
	

}
