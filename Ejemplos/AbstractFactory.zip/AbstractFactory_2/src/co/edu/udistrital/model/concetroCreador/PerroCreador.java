package co.edu.udistrital.model.concetroCreador;

import co.edu.udistrital.model.ComidaPerro;
import co.edu.udistrital.model.JuguetePerro;
import co.edu.udistrital.model.abstracto.Comida;
import co.edu.udistrital.model.abstracto.Juguete;
import co.edu.udistrital.model.abstracto.MascotaFactory;

public class PerroCreador implements MascotaFactory {

	@Override
	public Juguete crearJuguete(String color, String tipo) {
		return new JuguetePerro(color, tipo);
	}

	@Override
	public Comida crearComida(String sabor, String marca) {
		return new ComidaPerro(sabor, marca);
	}

	

}
