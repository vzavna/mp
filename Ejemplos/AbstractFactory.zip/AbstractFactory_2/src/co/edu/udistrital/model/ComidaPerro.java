package co.edu.udistrital.model;

import co.edu.udistrital.model.abstracto.Comida;

public class ComidaPerro extends Comida{

	public ComidaPerro(String sabor, String marca) {
		super(sabor, marca);
	}

	public String getSabor() {
		return "filete";
	}


	public String getMarca() {
		return "nutranugget";
	}
}
