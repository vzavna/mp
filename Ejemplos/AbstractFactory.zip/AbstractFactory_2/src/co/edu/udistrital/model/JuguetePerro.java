package co.edu.udistrital.model;

import co.edu.udistrital.model.abstracto.Juguete;

public class JuguetePerro extends Juguete {

	public JuguetePerro(String color, String tipo) {
		super(color, tipo);
	}
	
	public String getColor() {
		return "azul";
	}

	public String getTipo() {
		return "pelota";
	}

}
