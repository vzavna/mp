package co.edu.udistrital.model.abstracto;

public abstract class Juguete {
    protected String color;
    protected String tipo;
    
    protected Juguete(String color, String tipo) {
        this.color = color;
        this.tipo = tipo;
    }

    public String getColor() {
        return color;
    }

    public void setColor(String color) {
        this.color = color;
    }

    public String getTipo() {
        return tipo;
    }

    public void setTipo(String tipo) {
        this.tipo = tipo;
    }
    
}