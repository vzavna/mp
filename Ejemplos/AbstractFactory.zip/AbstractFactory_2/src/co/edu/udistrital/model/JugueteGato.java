package co.edu.udistrital.model;

import co.edu.udistrital.model.abstracto.Juguete;

public class JugueteGato extends Juguete {

	public JugueteGato(String color, String tipo) {
		super(color, tipo);
		
	}

	public String getColor() {
		return "rosa";
	}

	public String getTipo() {
		return "rascador";
	}
	
}
