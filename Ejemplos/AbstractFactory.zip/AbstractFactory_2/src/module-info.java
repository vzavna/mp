/**
 * 
 */
/**
 * 
 */
module absfactory_2 {
}