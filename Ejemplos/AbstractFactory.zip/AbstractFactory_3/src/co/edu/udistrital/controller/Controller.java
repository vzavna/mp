package co.edu.udistrital.controller;

import co.edu.udistrital.model.abstracto.Bebida;
import co.edu.udistrital.model.abstracto.Comida;
import co.edu.udistrital.model.abstracto.DesayunoFactory;
import co.edu.udistrital.model.concetroCreador.EjecutivoCreador;
import co.edu.udistrital.model.concetroCreador.InfantilCreador;
import co.edu.udistrital.view.VistaConsola;

public class Controller {

	private VistaConsola vista;
	
	
	public Controller() {
		this.vista = new VistaConsola();
	}


	public void run() {
		
		vista.mostrarDato("que tipo de desayuno desea? (ejecutivo/infantil)");
		String eleccion = vista.leerDato().toLowerCase();
		
		DesayunoFactory fabrica = null;
		
		switch(eleccion) {
		case "ejecutivo":
			fabrica = new EjecutivoCreador();
			break;
			
		
			
		case "infantil":
			fabrica = new InfantilCreador();
			break;
		
		default:
			break;
		}
		
		Comida comida = fabrica.crearComida(eleccion);
		Bebida bebida = fabrica.crearBebida(eleccion, eleccion);
		
		vista.mostrarDato("Su desayuno incluye: \n" + comida.getTipo());
		vista.mostrarDato(bebida.getMarca()+ " de " + bebida.getSabor());
	}
}
