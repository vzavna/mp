package co.edu.udistrital.model.concetroCreador;

import co.edu.udistrital.model.abstracto.Bebida;
import co.edu.udistrital.model.BebidaEjecutivo;
import co.edu.udistrital.model.ComidaEjecutivo;
import co.edu.udistrital.model.abstracto.Comida;
import co.edu.udistrital.model.abstracto.DesayunoFactory;

public class EjecutivoCreador implements DesayunoFactory {

	

	@Override
	public Bebida crearBebida(String sabor, String marca) {
		return new BebidaEjecutivo(sabor, marca);
	}

	

	@Override
	public Comida crearComida(String tipo) {
		return new ComidaEjecutivo(tipo);
	}

}
