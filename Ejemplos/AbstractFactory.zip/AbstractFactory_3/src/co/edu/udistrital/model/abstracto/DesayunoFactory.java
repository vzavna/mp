package co.edu.udistrital.model.abstracto;

public interface DesayunoFactory {

	Bebida crearBebida(String sabor, String marca);
	
	
	Comida crearComida(String tipo);
}
