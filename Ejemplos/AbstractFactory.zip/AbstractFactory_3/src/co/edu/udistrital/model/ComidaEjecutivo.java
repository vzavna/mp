package co.edu.udistrital.model;

import co.edu.udistrital.model.abstracto.Comida;

public class ComidaEjecutivo extends Comida {

	public ComidaEjecutivo(String tipo) {
		super(tipo);
	}

	public String getTipo() {
		return "huevos revueltos";
	}
}
