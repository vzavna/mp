package co.edu.udistrital.model.abstracto;

public abstract class Bebida {

	protected String sabor;
	protected String marca;
	
	public Bebida(String sabor, String marca) {
		super();
		this.sabor = sabor;
		this.marca = marca;
	}
	
	public String getSabor() {
		return sabor;
	}
	public void setSabor(String sabor) {
		this.sabor = sabor;
	}
	public String getMarca() {
		return marca;
	}
	public void setMarca(String marca) {
		this.marca = marca;
	}
	
	
}
