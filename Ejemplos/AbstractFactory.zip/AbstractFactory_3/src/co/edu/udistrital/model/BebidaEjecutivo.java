package co.edu.udistrital.model;

import co.edu.udistrital.model.abstracto.Bebida;

public class BebidaEjecutivo extends Bebida {

	public BebidaEjecutivo(String sabor, String marca) {
		super(sabor, marca);
	}

	public String getSabor() {
		return "mango";
	}
	
	public String getMarca() {
		return "jugo natural";
	}
}


