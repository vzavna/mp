package co.edu.udistrital.model;

import co.edu.udistrital.model.abstracto.Bebida;

public class BebidaInfantil extends Bebida {

	public BebidaInfantil(String sabor, String marca) {
		super(sabor, marca);
	}

	public String getSabor() {
		return "mora";
	}
	
	public String getMarca() {
		return "jugo hit";
	}
}
