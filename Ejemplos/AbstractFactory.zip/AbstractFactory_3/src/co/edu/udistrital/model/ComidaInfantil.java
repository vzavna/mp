package co.edu.udistrital.model;

import co.edu.udistrital.model.abstracto.Comida;

public class ComidaInfantil extends Comida {

	public ComidaInfantil(String tipo) {
		super(tipo);
	}

	public String getTipo() {
		return "cereal";
	}
}
