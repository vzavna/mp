package co.edu.udistrital.model.concetroCreador;

import co.edu.udistrital.model.BebidaInfantil;
import co.edu.udistrital.model.ComidaInfantil;
import co.edu.udistrital.model.abstracto.Bebida;
import co.edu.udistrital.model.abstracto.Comida;
import co.edu.udistrital.model.abstracto.DesayunoFactory;

public class InfantilCreador implements DesayunoFactory{

	@Override
	public Bebida crearBebida(String sabor, String marca) {
		return new BebidaInfantil(sabor, marca);
	}

	

	@Override
	public Comida crearComida(String tipo) {
		return new ComidaInfantil(tipo);
	}

	
}
