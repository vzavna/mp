package co.edu.udistrital.model.abstracto;

public abstract class Comida {

	protected String tipo;
	
	public Comida(String tipo) {
		this.tipo = tipo;
	}
	
	public String getTipo() {
		return tipo;
	}

	public void setTipo(String tipo) {
		this.tipo = tipo;
	}

	
	
	
}
