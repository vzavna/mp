/**
 * 
 */
/**
 * 
 */
module absfactory_3 {
}