package co.edu.udistrital.view;

import java.util.Scanner;

public class VistaConsola {

	Scanner scanner;
	
	public VistaConsola() {
		this.scanner = new Scanner(System.in);
	}
	
	public void mostrarDato(String mensaje) {
		System.out.println(mensaje);
	}
	
	public String leerDato() {
		return scanner.nextLine();
	}
}
