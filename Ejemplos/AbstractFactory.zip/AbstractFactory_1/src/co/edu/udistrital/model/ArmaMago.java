package co.edu.udistrital.model;

import co.edu.udistrital.model.abstracto.Arma;

public class ArmaMago extends Arma {

	public ArmaMago(String tipo, int daño) {
		super(tipo, daño);
	}
	
	public String getTipo() {
		return "El mago usa hechizo de ataque";
	}
	
	public int getDaño() {
		return 30;
	}
}
