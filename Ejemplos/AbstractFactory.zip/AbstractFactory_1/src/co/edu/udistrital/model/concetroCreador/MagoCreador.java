package co.edu.udistrital.model.concetroCreador;
import co.edu.udistrital.model.ArmaMago;
import co.edu.udistrital.model.EscudoMago;
import co.edu.udistrital.model.abstracto.Arma;
import co.edu.udistrital.model.abstracto.EquipamientoFactory;
import co.edu.udistrital.model.abstracto.Escudo;

public class MagoCreador implements EquipamientoFactory {

	public Arma crearArma(String tipo, int daño) {
		return new ArmaMago(tipo, daño);
	}
	
	public Escudo crearEscudo(String tipo, int resistencia) {
		return new EscudoMago(tipo, resistencia);
	}

}
