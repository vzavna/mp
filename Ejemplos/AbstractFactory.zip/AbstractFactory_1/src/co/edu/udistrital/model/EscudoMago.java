package co.edu.udistrital.model;

import co.edu.udistrital.model.abstracto.Escudo;

public class EscudoMago extends Escudo {
	
	public EscudoMago(String tipo, int resistencia) {
		super(tipo, resistencia);
	}

	public String getTipo() {
		return "el mago usa hechizo de proteccion";
	}
	
	public int getResistencia() {
		return 15;
	}
}
