package co.edu.udistrital.model;

import co.edu.udistrital.model.abstracto.Arma;

public class ArmaGuerrero extends Arma {

	public ArmaGuerrero(String tipo, int daño) {
		super(tipo, daño);
	}
	
	public String getTipo() {
		return "El guerrero usa una espada";
	}
	
	@Override
	public int getDaño() {
		return 15;
	}
}
