package co.edu.udistrital.model.abstracto;

public abstract class Escudo {

	protected String tipo;
	protected int resistencia;
	
	public Escudo(String tipo, int resistencia) {
		this.tipo = tipo;
		this.resistencia = resistencia;
	}

	public String getTipo() {
		return tipo;
	}

	public void setTipo(String tipo) {
		this.tipo = tipo;
	}

	public int getResistencia() {
		return resistencia;
	}

	public void setResistencia(int resistencia) {
		this.resistencia = resistencia;
	}
	
	
}
