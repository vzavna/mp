package co.edu.udistrital.model.abstracto;

public interface EquipamientoFactory {

	Arma crearArma(String tipo, int daño);
	
	Escudo crearEscudo(String tipo, int resistencia);
}
