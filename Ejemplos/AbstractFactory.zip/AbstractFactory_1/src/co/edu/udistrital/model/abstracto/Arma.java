package co.edu.udistrital.model.abstracto;

public abstract class Arma {

	protected String tipo;
	protected int daño;
	
	public Arma(String tipo, int daño) {
		this.tipo = tipo;
		this.daño = daño;
	}
	
	public String getTipo() {
		return tipo;
	}
	public void setTipo(String tipo) {
		this.tipo = tipo;
	}
	public int getDaño() {
		return daño;
	}
	public void setDaño(int daño) {
		this.daño = daño;
	}
	
	
}
