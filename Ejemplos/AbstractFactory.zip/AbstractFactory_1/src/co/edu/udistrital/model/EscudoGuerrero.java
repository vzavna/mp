package co.edu.udistrital.model;

import co.edu.udistrital.model.abstracto.Escudo;

public class EscudoGuerrero extends Escudo {

	public EscudoGuerrero(String tipo, int resistencia) {
		super(tipo, resistencia);
	}
	
	public String getTipo() {
		return "El guerrero usa escudo pesado";
	}
	
	public int getResistencia() {
		return 30;
	}
}
