package co.edu.udistrital.model.concetroCreador;

import co.edu.udistrital.model.abstracto.Arma;
import co.edu.udistrital.model.abstracto.EquipamientoFactory;
import co.edu.udistrital.model.abstracto.Escudo;
import co.edu.udistrital.model.ArmaGuerrero;
import co.edu.udistrital.model.EscudoGuerrero;

public class GuerreroCreador implements EquipamientoFactory {

	public Arma crearArma(String tipo, int daño) {
		return new ArmaGuerrero(tipo, daño);
	}
	
	public Escudo crearEscudo(String tipo, int resistencia) {
		return new EscudoGuerrero(tipo, resistencia);
	}
}
