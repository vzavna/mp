package co.edu.udistrital.controller;
import co.edu.udistrital.model.concetroCreador.GuerreroCreador;
import co.edu.udistrital.model.concetroCreador.MagoCreador;
import co.edu.udistrital.view.VistaConsola;
import co.edu.udistrital.model.abstracto.Arma;
import co.edu.udistrital.model.abstracto.Escudo;
import co.edu.udistrital.model.abstracto.EquipamientoFactory;
import java.util.Scanner;

public class Controller {
    private VistaConsola vista;
    private Scanner scanner;

    public Controller() {
        this.vista = new VistaConsola();
        this.scanner = new Scanner(System.in);
    }

    public void run() {
        vista.mostrarDato("¿Qué personaje desea usar? (mago/guerrero)");
        String eleccion = scanner.nextLine().trim().toLowerCase();

        EquipamientoFactory factory = null;

        switch(eleccion) {
            case "mago":
                factory = new MagoCreador();
                break;
            case "guerrero":
                factory = new GuerreroCreador();
                break;
            default:
                vista.mostrarDato("Opción no válida. Usando mago por defecto.");
                factory = new MagoCreador();
        }

        
        Arma arma = factory.crearArma(eleccion, 0);
        Escudo escudo = factory.crearEscudo(eleccion, 0);

        vista.mostrarDato("Personaje creado:");
        vista.mostrarDato("- Arma: " + arma.getTipo() + " (Daño: " + arma.getDaño() + ")");
        vista.mostrarDato("- Escudo: " + escudo.getTipo() + " (Proteccion: " + escudo.getResistencia() + ")");
    }
}