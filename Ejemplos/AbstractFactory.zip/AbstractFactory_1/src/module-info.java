/**
 * 
 */
/**
 * 
 */
module absfactory_1 {
}