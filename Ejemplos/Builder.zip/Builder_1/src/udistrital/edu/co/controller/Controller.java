package udistrital.edu.co.controller;

import udistrital.edu.co.model.SubwayBuilder;
import udistrital.edu.co.view.VistaConsola;

public class Controller {
    private VistaConsola vista;

    public Controller() {
        vista = new VistaConsola();
    }

    public void run() {
        vista.mostrarInformacion("=== Bienvenido a Subway ===");

        int id = vista.leerDatoEntero("Ingrese el ID del Subway: ");
        String pan = vista.leerCadenaDeTexto("Tipo de pan: ");
        String proteina = vista.leerCadenaDeTexto("Proteína: ");
        String vegetales = vista.leerCadenaDeTexto("Vegetales: ");

        SubwayBuilder builder = new SubwayBuilder(id)
                .pan(pan)
                .proteina(proteina)
                .vegetales(vegetales);

        vista.mostrarInformacion("Subway creado:");
        vista.mostrarInformacion(builder.toString());
    }
}
