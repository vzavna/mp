package udistrital.edu.co.view;

import java.util.Scanner;

public class VistaConsola {
    private Scanner sc;

    public VistaConsola() {
        sc = new Scanner(System.in);
    }

    public void mostrarInformacion(String mensaje) {
        System.out.println(mensaje);
    }

    public int leerDatoEntero(String mensaje) {
        System.out.print(mensaje);
        return Integer.parseInt(sc.nextLine());
    }

    public String leerCadenaDeTexto(String mensaje) {
        System.out.print(mensaje);
        return sc.nextLine();
    }
}
