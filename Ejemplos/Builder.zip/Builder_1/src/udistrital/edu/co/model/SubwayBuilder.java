package udistrital.edu.co.model;

public class SubwayBuilder {
    private Subway subway;

    public SubwayBuilder(int id) {
        subway = new Subway(id);
    }

    public SubwayBuilder pan(String pan) {
        subway.setPan(pan);
        return this;
    }

    public SubwayBuilder proteina(String proteina) {
        subway.setProteina(proteina);
        return this;
    }

    public SubwayBuilder vegetales(String vegetales) {
        subway.setVegetales(vegetales);
        return this;
    }

    @Override
    public String toString() {
        return subway.toString();
    }
}
