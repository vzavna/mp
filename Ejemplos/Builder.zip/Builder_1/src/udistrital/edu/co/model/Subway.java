package udistrital.edu.co.model;

public class Subway {
    private String pan;
    private String proteina;
    private String vegetales;
    private int id;

    public Subway(int id) {
        this.id = id;
    }

    public String getPan() {
        return pan;
    }

    public void setPan(String pan) {
        this.pan = pan;
    }

    public String getProteina() {
        return proteina;
    }

    public void setProteina(String proteina) {
        this.proteina = proteina;
    }

    public String getVegetales() {
        return vegetales;
    }

    public void setVegetales(String vegetales) {
        this.vegetales = vegetales;
    }

    public int getId() {
        return id;
    }

    @Override
    public String toString() {
        return "Subway #" + id + " {" +
                "pan='" + pan + '\'' +
                ", proteina='" + proteina + '\'' +
                ", vegetales='" + vegetales + '\'' +
                '}';
    }
}
