package udistrital.edu.co.controller;

import udistrital.edu.co.model.PaletaBuilder;
import udistrital.edu.co.view.VistaConsola;

public class Controller {
    private VistaConsola vista;

    public Controller() {
        vista = new VistaConsola();
    }

    public void run() {
        vista.mostrarInformacion("=== Bienvenido al creador de paletas ===");

        int id = vista.leerDatoEntero("ID de la paleta: ");
        String base = vista.leerCadenaDeTexto("Base (ej: vainilla): ");
        String topping = vista.leerCadenaDeTexto("Topping (ej: chocolate): ");

        PaletaBuilder builder = new PaletaBuilder(id)
                .base(base)
                .topping(topping);

        vista.mostrarInformacion("Paleta creada:");
        vista.mostrarInformacion(builder.toString());
    }
}
