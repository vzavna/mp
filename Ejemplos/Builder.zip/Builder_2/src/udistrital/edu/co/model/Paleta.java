package udistrital.edu.co.model;

public class Paleta {
    private String base;
    private String topping;
    private int id;

    public Paleta(int id) {
        this.id = id;
    }

    public String getBase() {
        return base;
    }

    public void setBase(String base) {
        this.base = base;
    }

    public String getTopping() {
        return topping;
    }

    public void setTopping(String topping) {
        this.topping = topping;
    }

    public int getId() {
        return id;
    }

    @Override
    public String toString() {
        return "Paleta #" + id + " { base='" + base + "', topping='" + topping + "' }";
    }
}
