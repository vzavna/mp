package udistrital.edu.co.model;

public class PaletaBuilder {
    private Paleta paleta;

    public PaletaBuilder(int id) {
        paleta = new Paleta(id);
    }

    public PaletaBuilder base(String base) {
        paleta.setBase(base);
        return this;
    }

    public PaletaBuilder topping(String topping) {
        paleta.setTopping(topping);
        return this;
    }

    @Override
    public String toString() {
        return paleta.toString();
    }
}
