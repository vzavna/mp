package udistrital.edu.co.controller;

import udistrital.edu.co.model.VelaBuilder;
import udistrital.edu.co.view.VistaConsola;

public class Controller {
    private VistaConsola vista;

    public Controller() {
        vista = new VistaConsola();
    }

    public void run() {
        vista.mostrarInformacion("=== Crear tu propia vela aromática ===");

        int id = vista.leerDatoEntero("ID de la vela: ");
        String aroma = vista.leerCadenaDeTexto("¿Qué aroma quieres? ");

        VelaBuilder builder = new VelaBuilder(id)
                .aroma(aroma);

        vista.mostrarInformacion("Vela creada:");
        vista.mostrarInformacion(builder.toString());
    }
}
