package udistrital.edu.co.model;

public class VelaBuilder {
    private Vela vela;

    public VelaBuilder(int id) {
        vela = new Vela(id);
    }

    public VelaBuilder aroma(String aroma) {
        vela.setAroma(aroma);
        return this;
    }

    @Override
    public String toString() {
        return vela.toString();
    }
}
