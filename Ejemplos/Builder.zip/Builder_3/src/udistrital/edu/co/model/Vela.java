package udistrital.edu.co.model;

public class Vela {
    private String aroma;
    private int id;

    public Vela(int id) {
        this.id = id;
    }

    public String getAroma() {
        return aroma;
    }

    public void setAroma(String aroma) {
        this.aroma = aroma;
    }

    public int getId() {
        return id;
    }

    @Override
    public String toString() {
        return "Vela #" + id + " { aroma='" + aroma + "' }";
    }
}
