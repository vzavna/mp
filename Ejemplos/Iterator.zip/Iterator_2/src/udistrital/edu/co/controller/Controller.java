package udistrital.edu.co.controller;

import udistrital.edu.co.model.Fruta;
import udistrital.edu.co.model.Fruteria;
import udistrital.edu.co.model.IteratorInterfaz;
import udistrital.edu.co.view.VistaConsola;

public class Controller {
    private VistaConsola vista;

    public Controller() {
        vista = new VistaConsola();
    }

    public void run() {
        Fruteria fruteria = new Fruteria(2);
        fruteria.agregarFruta(new Fruta("Manzana"));
        fruteria.agregarFruta(new Fruta("Banano"));

        IteratorInterfaz it = fruteria.crearIterator();

        vista.mostrarInformacion("Frutas disponibles:");
        while (it.haySiguiente()) {
            Fruta f = it.siguiente();
            vista.mostrarInformacion("- " + f.getNombre());
        }
    }
}