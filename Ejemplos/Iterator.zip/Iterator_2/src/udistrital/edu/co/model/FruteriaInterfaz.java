package udistrital.edu.co.model;

public interface FruteriaInterfaz {
    IteratorInterfaz crearIterator();
}