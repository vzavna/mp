package udistrital.edu.co.model;

public class Iterator implements IteratorInterfaz {
    private Fruta[] frutas;
    private int posicion;

    public Iterator(Fruta[] frutas) {
        this.frutas = frutas;
        this.posicion = 0;
    }

    public boolean haySiguiente() {
        return posicion < frutas.length && frutas[posicion] != null;
    }

    public Fruta siguiente() {
        return frutas[posicion++];
    }
}