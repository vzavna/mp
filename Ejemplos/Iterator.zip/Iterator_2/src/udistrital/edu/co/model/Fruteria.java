package udistrital.edu.co.model;

public class Fruteria implements FruteriaInterfaz {
    private Fruta[] frutas;
    private int indice;

    public Fruteria(int tam) {
        frutas = new Fruta[tam];
        indice = 0;
    }

    public void agregarFruta(Fruta fruta) {
        if (indice < frutas.length) {
            frutas[indice++] = fruta;
        }
    }

    @Override
    public IteratorInterfaz crearIterator() {
        return new Iterator(frutas);
    }
}