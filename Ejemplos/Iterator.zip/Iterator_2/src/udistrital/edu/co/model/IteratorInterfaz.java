package udistrital.edu.co.model;

public interface IteratorInterfaz {
    Fruta siguiente();
    boolean haySiguiente();
}