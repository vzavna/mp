package udistrital.edu.co.model;

public class Disco {
    private String titulo;

    public Disco(String titulo) {
        this.titulo = titulo;
    }

    public String getTitulo() {
        return titulo;
    }

    public void setTitulo(String titulo) {
        this.titulo = titulo;
    }
}