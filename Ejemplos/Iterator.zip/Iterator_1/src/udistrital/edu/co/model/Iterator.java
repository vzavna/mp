package udistrital.edu.co.model;

public class Iterator implements IteratorInterfaz {
    private Disco[] discos;
    private int posicion;

    public Iterator(Disco[] discos) {
        this.discos = discos;
        this.posicion = 0;
    }

    public boolean haySiguiente() {
        return posicion < discos.length && discos[posicion] != null;
    }

    public Disco siguiente() {
        return discos[posicion++];
    }
}