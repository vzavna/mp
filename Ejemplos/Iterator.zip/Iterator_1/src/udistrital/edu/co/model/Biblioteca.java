package udistrital.edu.co.model;

public class Biblioteca implements BibliotecaInterfaz {
    private Disco[] discos;
    private int indice;

    public Biblioteca(int tam) {
        discos = new Disco[tam];
        indice = 0;
    }

    public void agregarDisco(Disco disco) {
        if (indice < discos.length) {
            discos[indice++] = disco;
        }
    }

    @Override
    public IteratorInterfaz crearIterator() {
        return new Iterator(discos);
    }
}