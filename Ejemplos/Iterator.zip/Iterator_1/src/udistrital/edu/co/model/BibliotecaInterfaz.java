package udistrital.edu.co.model;

public interface BibliotecaInterfaz {
    IteratorInterfaz crearIterator();
}