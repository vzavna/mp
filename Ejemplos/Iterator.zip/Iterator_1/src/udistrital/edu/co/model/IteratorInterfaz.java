package udistrital.edu.co.model;

public interface IteratorInterfaz {
    Disco siguiente();
    boolean haySiguiente();
}