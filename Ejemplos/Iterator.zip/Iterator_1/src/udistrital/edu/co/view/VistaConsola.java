package udistrital.edu.co.view;

import java.util.Scanner;

public class VistaConsola {
    Scanner scanner;

    public VistaConsola() {
        scanner = new Scanner(System.in);
    }

    public void mostrarInformacion(String mensaje) {
        System.out.println(mensaje);
    }

    public String leerCadenaDeTexto(String mensaje) {
        System.out.print(mensaje);
        return scanner.nextLine();
    }
}