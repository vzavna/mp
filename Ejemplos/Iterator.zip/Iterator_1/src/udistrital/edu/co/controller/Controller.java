package udistrital.edu.co.controller;

import udistrital.edu.co.model.Biblioteca;
import udistrital.edu.co.model.Disco;
import udistrital.edu.co.model.IteratorInterfaz;
import udistrital.edu.co.view.VistaConsola;

public class Controller {
    private VistaConsola vista;

    public Controller() {
        vista = new VistaConsola();
    }

    public void run() {
        Biblioteca biblioteca = new Biblioteca(3);
        biblioteca.agregarDisco(new Disco("Álbum A"));
        biblioteca.agregarDisco(new Disco("Álbum B"));
        biblioteca.agregarDisco(new Disco("Álbum C"));

        IteratorInterfaz it = biblioteca.crearIterator();

        vista.mostrarInformacion("Mostrando discos:");
        while (it.haySiguiente()) {
            Disco d = it.siguiente();
            vista.mostrarInformacion("- " + d.getTitulo());
        }
    }
}
