package udistrital.edu.co.model;

public interface IteratorInterfaz {
    Juego siguiente();
    boolean haySiguiente();
}