package udistrital.edu.co.model;

public class BibliotecaJuegos implements BibliotecaInterfaz {
    private Juego[] juegos;
    private int indice;

    public BibliotecaJuegos(int tam) {
        juegos = new Juego[tam];
        indice = 0;
    }

    public void agregarJuego(Juego juego) {
        if (indice < juegos.length) {
            juegos[indice++] = juego;
        }
    }

    @Override
    public IteratorInterfaz crearIterator() {
        return new Iterator(juegos);
    }
}