package udistrital.edu.co.model;

public class Iterator implements IteratorInterfaz {
    private Juego[] juegos;
    private int posicion;

    public Iterator(Juego[] juegos) {
        this.juegos = juegos;
        this.posicion = 0;
    }

    public boolean haySiguiente() {
        return posicion < juegos.length && juegos[posicion] != null;
    }

    public Juego siguiente() {
        return juegos[posicion++];
    }
}
