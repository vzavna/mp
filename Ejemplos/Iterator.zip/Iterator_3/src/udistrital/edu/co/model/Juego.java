package udistrital.edu.co.model;

public class Juego {
    private String nombre;

    public Juego(String nombre) {
        this.nombre = nombre;
    }

    public String getNombre() {
        return nombre;
    }
}
