package udistrital.edu.co.controller;

import udistrital.edu.co.model.BibliotecaJuegos;
import udistrital.edu.co.model.IteratorInterfaz;
import udistrital.edu.co.model.Juego;
import udistrital.edu.co.view.VistaConsola;

public class Controller {
    private VistaConsola vista;

    public Controller() {
        vista = new VistaConsola();
    }

    public void run() {
        BibliotecaJuegos biblioteca = new BibliotecaJuegos(2);
        biblioteca.agregarJuego(new Juego("Ajedrez"));
        biblioteca.agregarJuego(new Juego("Tetris"));

        IteratorInterfaz it = biblioteca.crearIterator();

        vista.mostrarInformacion("Lista de juegos:");
        while (it.haySiguiente()) {
            Juego j = it.siguiente();
            vista.mostrarInformacion("- " + j.getNombre());
        }
    }
}