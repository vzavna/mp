package co.edu.udistrital.controller;
import co.edu.udistrital.model.abstracto.*;
import co.edu.udistrital.model.concretoCreador.*;
import co.edu.udistrital.modell.Carro;
import co.edu.udistrital.modell.Moto;
import co.edu.udistrital.view.VistaConsola;


public class Controller {

	private VistaConsola vista;
	
	public Controller() {
    	vista = new VistaConsola();
	}
	
	public void run() {
	    
	        vista.mostrarInformacion("Ingrese los datos del vehículo");
	        vista.mostrarInformacion("Tipo (carro/moto): ");
	        String tipo = vista.leerDato().toLowerCase();
	        vista.mostrarInformacion("Marca: ");
	        String marca = vista.leerDato();
	        vista.mostrarInformacion("Modelo: ");
	        String modelo = vista.leerDato();

	        VehiculoFactory fabrica = new VehiculoCreador();
	        Vehiculo vehiculo = fabrica.crearVehiculo(tipo, marca, modelo);
	        
	        vista.mostrarInformacion(vehiculo.acelerar());
	        vista.mostrarInformacion(vehiculo.frenar());
	        
	        if(vehiculo instanceof Carro) {
	        	Carro carro = (Carro) vehiculo; //Convierte la variable vehiculo (de tipo Vehiculo) a tipo Carro para q llame el exclusivo de carro
	        	vista.mostrarInformacion(carro.encenderRadio());
	        	}else {
	        		if(vehiculo instanceof Moto) { //aqui hace lo mismo con la moto pa q llame el exclusivo de moto
	        			Moto moto = (Moto) vehiculo;
	        			vista.mostrarInformacion(moto.filtrarVehiculos());
	        		}
	        	}
	}
}