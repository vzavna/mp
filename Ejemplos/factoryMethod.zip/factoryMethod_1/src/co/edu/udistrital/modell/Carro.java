package co.edu.udistrital.modell;

import co.edu.udistrital.model.abstracto.*;

public class Carro extends Vehiculo {
	private String radioEncendida;
	
	
	public Carro(String tipo, String marca, String modelo) {
		super(tipo, marca, modelo);
		
	}

	
	public String acelerar() {
		return "El carro " +getMarca()+ " " + getModelo()+ " está acelerando";
	}
	
	public String frenar() {
		return "El carro " +getMarca()+ " " + getModelo()+ " está frenando";	
	}
	
	public String encenderRadio() {
		return "Radio del " + getMarca() + " encendida";
	}
	
	

	
}
