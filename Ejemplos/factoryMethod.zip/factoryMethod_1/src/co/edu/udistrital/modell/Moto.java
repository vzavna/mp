package co.edu.udistrital.modell;
import co.edu.udistrital.model.abstracto.*;


public class Moto extends Vehiculo {
	private String filtrarVehiculos;
	
	
	public Moto(String tipo, String marca, String modelo) {
		super(tipo, marca, modelo);
		
	}

	
	public String acelerar() {
		return "La moto " +getMarca()+ " " + getModelo()+ " está acelerando";
	}
	
	public String frenar() {
		return "La moto " +getMarca()+ " " + getModelo()+ " está frenando";	
	}
	
	public String filtrarVehiculos() {
		return "la moto " + getMarca() + " está filtrando entre carros";
	}
	
	
	
}
