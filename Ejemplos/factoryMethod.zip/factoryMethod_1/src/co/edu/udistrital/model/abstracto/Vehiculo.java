package co.edu.udistrital.model.abstracto;

public abstract class Vehiculo {
	protected String tipo;
	protected String marca;
	protected String modelo;
	
	public Vehiculo(String tipo, String marca, String modelo) {
		this.tipo = tipo;
		this.marca = marca;
		this.modelo = modelo;
	}
	
	public abstract String acelerar();
	public abstract String frenar();
	
	 public String getTipo() {
		 return tipo; 
		 }
	 
	 public String getMarca() {
		 return marca; 
		 }
	 
	 public String getModelo() {
		 return modelo; 
		 }
	
}
