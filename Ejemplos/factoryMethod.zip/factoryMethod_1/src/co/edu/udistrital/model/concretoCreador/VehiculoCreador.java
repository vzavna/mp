package co.edu.udistrital.model.concretoCreador;
import co.edu.udistrital.model.abstracto.*;
import co.edu.udistrital.modell.Carro;
import co.edu.udistrital.modell.Moto;

public class VehiculoCreador implements VehiculoFactory{

	public Vehiculo crearVehiculo(String tipo, String marca, String modelo) {
		
		tipo = tipo.toLowerCase();
		
		if(tipo.equals("carro")){
			return new Carro(tipo, marca, modelo);
		}else{
			if(tipo.equals("moto")){
			return new Moto(tipo, marca, modelo);
		}else {
			return null;
		}
	}
}
}
