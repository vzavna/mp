package co.edu.udistrital.model.abstracto;

public interface LibroFactory {

	Libro crearLibro(String nombre, String autor, String genero);
}
