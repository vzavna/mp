package co.edu.udistrital.model;

import co.edu.udistrital.model.abstracto.Libro;

public class Novela extends Libro {

	
	public Novela(String nombre, String autor, String genero) {
		super(nombre, autor, genero);
	}

	public String describir() {
		return "El libro está en la sección de: " + getGenero()+"s";
	}
	
	
	
	
}
