package co.edu.udistrital.model.concretoCreador;
import co.edu.udistrital.model.abstracto.*;
import co.edu.udistrital.model.Novela;
import co.edu.udistrital.model.Autobiografia;

public class LibroCreador implements LibroFactory {

	public Libro crearLibro(String nombre, String autor, String genero) {
		
		genero = genero.toLowerCase();
		
		if(genero.equals("novela")) {
			return new Novela(nombre, autor, genero);
		}else {
			if(genero.equals("autobiografia")) {
				return new Autobiografia(nombre, autor, genero);
			}
		}
		return null;
	}

}
