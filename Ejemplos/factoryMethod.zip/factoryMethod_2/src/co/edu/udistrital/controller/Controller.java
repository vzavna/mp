package co.edu.udistrital.controller;

import co.edu.udistrital.model.abstracto.Libro;
import co.edu.udistrital.model.abstracto.LibroFactory;
import co.edu.udistrital.model.concretoCreador.LibroCreador;
import co.edu.udistrital.view.VistaConsola;

public class Controller {

	private VistaConsola vista;
	
	public Controller() {
		vista = new VistaConsola();
	}
	
	public void run() {
		vista.mostrarInformacion("Nombre: ");
		String nombre = vista.leerDato();
		vista.mostrarInformacion("Autor: ");
		String autor = vista.leerDato();
		vista.mostrarInformacion("Genero: ");
		String genero = vista.leerDato().toLowerCase();
		
		LibroFactory fabrica = new LibroCreador();
		Libro libro = fabrica.crearLibro(nombre, autor, genero);
		
		vista.mostrarInformacion(libro.describir());
	}
}
