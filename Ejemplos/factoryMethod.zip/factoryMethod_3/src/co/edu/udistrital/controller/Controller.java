package co.edu.udistrital.controller;

import co.edu.udistrital.view.VistaConsola;
import co.edu.udistrital.model.abstracto.Animal;
import co.edu.udistrital.model.abstracto.AnimalFactory;
import co.edu.udistrital.model.concretoCreador.AnimalCreador;

public class Controller {

	private VistaConsola vista;
	
	public Controller() {
		this.vista = new VistaConsola();
	}
	
	public void run(){
		
		vista.mostrarInformacion("¿Que animal es? \nLoro\nGato\nPerro");
		String tipo = vista.leerDato().toLowerCase();
		
		
		AnimalFactory fabrica = new AnimalCreador();
		Animal animal = fabrica.crearAnimal(tipo, null);
		
		vista.mostrarInformacion(animal.emitirSonido());
		
	}
	
}
