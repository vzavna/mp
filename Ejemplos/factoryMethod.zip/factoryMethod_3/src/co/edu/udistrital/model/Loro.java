package co.edu.udistrital.model;

import co.edu.udistrital.model.abstracto.Animal;

public class Loro extends Animal {

	public Loro(String tipo, String sonido){
		super(tipo, sonido);
	}
	
	public String emitirSonido() {
		return "pio pio";
	}
}
	
