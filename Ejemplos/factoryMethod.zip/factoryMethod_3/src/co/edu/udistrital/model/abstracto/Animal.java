package co.edu.udistrital.model.abstracto;

public abstract class Animal {

	protected String sonido;
	protected String tipo;
	
	public Animal(String sonido, String tipo) {
		this.sonido = sonido;
		this.tipo = tipo;
	}
	
	public abstract String emitirSonido();

	public String getSonido() {
		return sonido;
	}

	public void setSonido(String sonido) {
		this.sonido = sonido;
	}

	public String getTipo() {
		return tipo;
	}

	public void setTipo(String tipo) {
		this.tipo = tipo;
	}
	
	
}
