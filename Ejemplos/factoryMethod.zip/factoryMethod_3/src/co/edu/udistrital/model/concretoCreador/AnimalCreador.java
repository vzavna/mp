package co.edu.udistrital.model.concretoCreador;
import co.edu.udistrital.model.Gato;
import co.edu.udistrital.model.Perro;
import co.edu.udistrital.model.Loro;
import co.edu.udistrital.model.abstracto.Animal;
import co.edu.udistrital.model.abstracto.AnimalFactory;

public class AnimalCreador implements AnimalFactory {

	public Animal crearAnimal(String tipo, String sonido) {
		
		tipo = tipo.toLowerCase();
		
		if(tipo.equals("gato")) {
			return new Gato(tipo, sonido);
		}else {
			if(tipo.equals("perro")) {
				return new Perro(tipo, sonido);
			}else {
				if(tipo.equals("loro")) {
					return new Loro(tipo, sonido);
				}
			}
		}return null;

	}
		
}
