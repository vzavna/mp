package co.edu.udistrital.model;

import co.edu.udistrital.model.abstracto.Animal;

public class Gato extends Animal {

		public Gato(String tipo, String sonido) {
		super(tipo, sonido);
	}
		
		public String emitirSonido() {
			return "miau";
		}
}
