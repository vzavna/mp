package co.edu.udistrital.model.abstracto;

public interface AnimalFactory {

	Animal crearAnimal(String sonido, String tipo);
}
