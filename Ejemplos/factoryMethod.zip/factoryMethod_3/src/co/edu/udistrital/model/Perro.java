package co.edu.udistrital.model;

import co.edu.udistrital.model.abstracto.Animal;

public class Perro extends Animal {

	public Perro(String tipo, String sonido){
		super(tipo, sonido);
	}
	
	public String emitirSonido() {
		return "guau guau";
	}
}
