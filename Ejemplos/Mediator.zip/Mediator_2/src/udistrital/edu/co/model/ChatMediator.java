package udistrital.edu.co.model;

public interface ChatMediator {
    String enviarMensaje(String mensaje, Estudiante emisor);
    void registrarEstudiante(Estudiante estudiante);
}