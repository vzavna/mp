package udistrital.edu.co.model;

import java.util.ArrayList;

public class ChatConcreto implements ChatMediator {
    private ArrayList<Estudiante> estudiantes = new ArrayList<>();

    @Override
    public void registrarEstudiante(Estudiante estudiante) {
        estudiantes.add(estudiante);
    }

    @Override
    public String enviarMensaje(String mensaje, Estudiante emisor) {
        StringBuilder sb = new StringBuilder();
        for (Estudiante e : estudiantes) {
            if (!e.equals(emisor)) {
                sb.append(e.recibir(mensaje)).append("\n");
            }
        }
        return sb.toString();
    }
}