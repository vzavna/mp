package udistrital.edu.co.model;

public class EstudianteConcreto extends Estudiante {

    public EstudianteConcreto(ChatMediator mediador, String nombre) {
        super(mediador, nombre);
    }

    @Override
    public String enviar(String mensaje) {
        return mediador.enviarMensaje(mensaje, this);
    }

    @Override
    public String recibir(String mensaje) {
        return nombre + " recibió: " + mensaje;
    }
}
