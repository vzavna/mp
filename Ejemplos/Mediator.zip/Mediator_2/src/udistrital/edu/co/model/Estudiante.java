package udistrital.edu.co.model;

public abstract class Estudiante {
    protected ChatMediator mediador;
    protected String nombre;

    public Estudiante(ChatMediator mediador, String nombre) {
        this.mediador = mediador;
        this.nombre = nombre;
    }

    public abstract String enviar(String mensaje);
    public abstract String recibir(String mensaje);
    public String getNombre() {
        return nombre;
    }
}