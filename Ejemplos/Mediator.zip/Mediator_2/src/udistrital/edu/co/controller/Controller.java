package udistrital.edu.co.controller;

import udistrital.edu.co.view.VistaConsola;
import udistrital.edu.co.model.*;

public class Controller {
    private VistaConsola vista;

    public Controller() {
        vista = new VistaConsola();
    }

    public void run() {
        ChatMediator chat = new ChatConcreto();

        Estudiante e1 = new EstudianteConcreto(chat, "Ana");
        Estudiante e2 = new EstudianteConcreto(chat, "Luis");

        chat.registrarEstudiante(e1);
        chat.registrarEstudiante(e2);

        String mensaje = vista.leerCadenaDeTexto("Ana escribe un mensaje: ");
        String respuesta = e1.enviar(mensaje);
        vista.mostrarInformacion(respuesta);
    }
}