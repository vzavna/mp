package udistrital.edu.co.controller;

import udistrital.edu.co.view.VistaConsola;
import udistrital.edu.co.model.*;


public class Controller {
    private VistaConsola vista;

    public Controller() {
        vista = new VistaConsola();
    }

    public void run() {
        CentralMediator central = new CentralConcreta();

        Sensor temperatura = new SensorConcreto(central, "Sensor de Temperatura");
        Sensor humo = new SensorConcreto(central, "Sensor de Humo");

        central.registrarSensor(temperatura);
        central.registrarSensor(humo);

        String alerta = vista.leerCadenaDeTexto("Alerta desde Sensor de Temperatura: ");
        String respuesta = temperatura.enviarAlerta(alerta);
        vista.mostrarInformacion(respuesta);
    }
}