package udistrital.edu.co.model;

public abstract class Sensor {
    protected CentralMediator mediador;
    protected String tipo;

    public Sensor(CentralMediator mediador, String tipo) {
        this.mediador = mediador;
        this.tipo = tipo;
    }

    public abstract String enviarAlerta(String alerta);
    public abstract String recibirAlerta(String alerta);
}