package udistrital.edu.co.model;

public class SensorConcreto extends Sensor {

    public SensorConcreto(CentralMediator mediador, String tipo) {
        super(mediador, tipo);
    }

    @Override
    public String enviarAlerta(String alerta) {
        return mediador.enviarAlerta(alerta, this);
    }

    @Override
    public String recibirAlerta(String alerta) {
        return tipo + " recibe alerta: " + alerta;
    }
}