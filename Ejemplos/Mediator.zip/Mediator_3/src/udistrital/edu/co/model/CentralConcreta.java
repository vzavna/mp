package udistrital.edu.co.model;

import java.util.ArrayList;

public class CentralConcreta implements CentralMediator {
    private ArrayList<Sensor> sensores = new ArrayList<>();

    @Override
    public void registrarSensor(Sensor sensor) {
        sensores.add(sensor);
    }

    @Override
    public String enviarAlerta(String alerta, Sensor emisor) {
        StringBuilder sb = new StringBuilder();
        for (Sensor s : sensores) {
            if (!s.equals(emisor)) {
                sb.append(s.recibirAlerta(alerta)).append("\n");
            }
        }
        return sb.toString();
    }
}