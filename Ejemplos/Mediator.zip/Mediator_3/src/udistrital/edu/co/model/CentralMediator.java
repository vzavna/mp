package udistrital.edu.co.model;

public interface CentralMediator {
    String enviarAlerta(String alerta, Sensor emisor);
    void registrarSensor(Sensor sensor);
}