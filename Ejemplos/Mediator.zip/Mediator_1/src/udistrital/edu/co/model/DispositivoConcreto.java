package udistrital.edu.co.model;

public class DispositivoConcreto extends Dispositivo {

    public DispositivoConcreto(RedMediator red, String nombre) {
        super(red, nombre);
    }

    @Override
    public String enviar(String mensaje) {
        return nombre + " envía: " + mensaje + "\n" + red.enviarMensaje(mensaje, this);
    }

    @Override
    public String recibir(String mensaje) {
        return nombre + " recibió: " + mensaje;
    }
}