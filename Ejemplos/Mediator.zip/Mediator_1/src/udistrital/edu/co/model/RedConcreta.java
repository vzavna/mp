package udistrital.edu.co.model;

import java.util.ArrayList;

public class RedConcreta implements RedMediator {
    private ArrayList<Dispositivo> dispositivos = new ArrayList<>();

    @Override
    public String enviarMensaje(String mensaje, Dispositivo remitente) {
        StringBuilder salida = new StringBuilder();
        for (Dispositivo d : dispositivos) {
            if (!d.equals(remitente)) {
                salida.append(d.recibir(mensaje)).append("\n");
            }
        }
        return salida.toString();
    }

    @Override
    public void registrarDispositivo(Dispositivo dispositivo) {
        dispositivos.add(dispositivo);
    }
}