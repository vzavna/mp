package udistrital.edu.co.model;

public interface RedMediator {
    String enviarMensaje(String mensaje, Dispositivo remitente);
    void registrarDispositivo(Dispositivo dispositivo);
}