package udistrital.edu.co.model;

public abstract class Dispositivo {
    protected RedMediator red;
    protected String nombre;

    public Dispositivo(RedMediator red, String nombre) {
        this.red = red;
        this.nombre = nombre;
    }

    public abstract String enviar(String mensaje);
    public abstract String recibir(String mensaje);

    public String getNombre() {
        return nombre;
    }
}