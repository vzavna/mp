package udistrital.edu.co.controller;

import udistrital.edu.co.model.DispositivoConcreto;
import udistrital.edu.co.view.VistaConsola;
import udistrital.edu.co.model.RedMediator;
import udistrital.edu.co.model.RedConcreta;


public class Controller {
    private VistaConsola vista;

    public Controller() {
        vista = new VistaConsola();
    }

    public void run() {
        RedMediator red = new RedConcreta();

        DispositivoConcreto d1 = new DispositivoConcreto(red, "Tablet");
        DispositivoConcreto d2 = new DispositivoConcreto(red, "Smartwatch");
        DispositivoConcreto d3 = new DispositivoConcreto(red, "Laptop");

        red.registrarDispositivo(d1);
        red.registrarDispositivo(d2);
        red.registrarDispositivo(d3);

        String mensaje = vista.leerCadenaDeTexto("Ingrese un mensaje desde la Tablet: ");
        vista.mostrarInformacion(d1.enviar(mensaje));
    }
}