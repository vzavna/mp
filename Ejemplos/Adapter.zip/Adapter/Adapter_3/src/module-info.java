/**
 * 
 */
/**
 * 
 */
module Adapter_3 {
}