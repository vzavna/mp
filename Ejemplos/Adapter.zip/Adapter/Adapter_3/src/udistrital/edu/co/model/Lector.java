package udistrital.edu.co.model;

public interface Lector {
    String leer();
}