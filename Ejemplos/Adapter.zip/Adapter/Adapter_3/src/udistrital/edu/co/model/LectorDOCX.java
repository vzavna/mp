package udistrital.edu.co.model;

public class LectorDOCX implements Lector {
    @Override
    public String leer() {
        return "Leyendo archivo DOCX...";
    }
}