package udistrital.edu.co.model;

public class LectorImagen {
    public String abrirImagen() {
        return "Visualizando imagen JPEG...";
    }
}