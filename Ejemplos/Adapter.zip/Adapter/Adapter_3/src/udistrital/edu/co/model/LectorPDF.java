package udistrital.edu.co.model;

public class LectorPDF implements Lector {
    @Override
    public String leer() {
        return "Leyendo archivo PDF...";
    }
}