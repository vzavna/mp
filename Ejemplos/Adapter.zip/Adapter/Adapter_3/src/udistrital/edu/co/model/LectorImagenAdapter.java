package udistrital.edu.co.model;

public class LectorImagenAdapter implements Lector {
    private LectorImagen imagen;

    public LectorImagenAdapter(LectorImagen imagen) {
        this.imagen = imagen;
    }

    public String leer() {
        return imagen.abrirImagen();
    }
}