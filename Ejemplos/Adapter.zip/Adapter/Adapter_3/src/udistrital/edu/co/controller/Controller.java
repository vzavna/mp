package udistrital.edu.co.controller;

import udistrital.edu.co.model.*;
import udistrital.edu.co.view.*;

public class Controller {
    private Vista vista;

    public Controller() {
        vista = new Vista();
    }

    public void run() {
        Lector pdf = new LectorPDF();
        Lector docx = new LectorDOCX();
        Lector imagen = new LectorImagenAdapter(new LectorImagen());

        vista.mostrar(pdf.leer());
        vista.mostrar(docx.leer());
        vista.mostrar(imagen.leer());
    }
}