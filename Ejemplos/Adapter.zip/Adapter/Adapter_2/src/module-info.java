/**
 * 
 */
/**
 * 
 */
module Adapter_2 {
}