package udistrital.edu.co.model;

public class CargadorUSB implements Cargador {
    @Override
    public String cargar() {
        return "Cargando con cargador USB.";
    }
}