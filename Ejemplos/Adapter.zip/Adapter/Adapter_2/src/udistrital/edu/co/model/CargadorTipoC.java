package udistrital.edu.co.model;

public class CargadorTipoC implements Cargador {
    @Override
    public String cargar() {
        return "Cargando con cargador Tipo-C.";
    }
}