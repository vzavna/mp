package udistrital.edu.co.model;

public class CargadorInalambricoAdapter implements Cargador {
    private CargadorInalambrico adaptado;

    public CargadorInalambricoAdapter(CargadorInalambrico adaptado) {
        this.adaptado = adaptado;
    }

    @Override
    public String cargar() {
        return adaptado.iniciarCarga();
    }
}