package udistrital.edu.co.model;

public class CargadorInalambrico {
    public String iniciarCarga() {
        return "Cargando con cargador inalámbrico.";
    }
}