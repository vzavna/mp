package udistrital.edu.co.view;

public class Vista {
    public void mostrar(String mensaje) {
        System.out.println(mensaje);
    }
}