package udistrital.edu.co.controller;

import udistrital.edu.co.model.*;
import udistrital.edu.co.view.*;

public class Controller {
    private Vista vista;

    public Controller() {
        vista = new Vista();
    }

    public void run() {
        Cargador usb = new CargadorUSB();
        Cargador tipoC = new CargadorTipoC();
        Cargador inalambrico = new CargadorInalambricoAdapter(new CargadorInalambrico());

        vista.mostrar(usb.cargar());
        vista.mostrar(tipoC.cargar());
        vista.mostrar(inalambrico.cargar());
    }
}