package udistrital.edu.co.model;

public interface Cargador {
    String cargar();
}