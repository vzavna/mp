/**
 * 
 */
/**
 * 
 */
module Adapter_1 {
}