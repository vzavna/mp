package udistrital.edu.co.model;

public class LamparaNormal implements ILampara {
    private int intensidad;

    public LamparaNormal(int intensidad) {
        this.intensidad = intensidad;
    }

    @Override
    public String encender() {
        return "Encendiendo lámpara normal con intensidad " + intensidad + ".";
    }

    public int getIntensidad() {
        return intensidad;
    }

    public void setIntensidad(int intensidad) {
        this.intensidad = intensidad;
    }
}