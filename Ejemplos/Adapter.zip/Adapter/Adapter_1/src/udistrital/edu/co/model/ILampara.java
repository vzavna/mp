package udistrital.edu.co.model;

public interface ILampara {
    String encender();
}