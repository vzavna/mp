package udistrital.edu.co.model;

public class LamparaRecargable implements ILampara {
    private int intensidad;

    public LamparaRecargable(int intensidad) {
        this.intensidad = intensidad;
    }

    @Override
    public String encender() {
        return "Encendiendo lámpara recargable con intensidad " + intensidad + ".";
    }

    public int getIntensidad() {
        return intensidad;
    }

    public void setIntensidad(int intensidad) {
        this.intensidad = intensidad;
    }
}