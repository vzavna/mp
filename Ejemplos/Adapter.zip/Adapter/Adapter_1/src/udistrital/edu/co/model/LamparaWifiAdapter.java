package udistrital.edu.co.model;

public class LamparaWifiAdapter implements ILampara {
    private LamparaWifi lamparaAdaptada;

    public LamparaWifiAdapter(LamparaWifi lamparaWifi) {
        this.lamparaAdaptada = lamparaWifi;
    }

    @Override
    public String encender() {
        return lamparaAdaptada.encender();
    }

    public LamparaWifi getLamparaAdaptada() {
        return lamparaAdaptada;
    }

    public void setLamparaAdaptada(LamparaWifi lamparaAdaptada) {
        this.lamparaAdaptada = lamparaAdaptada;
    }
}