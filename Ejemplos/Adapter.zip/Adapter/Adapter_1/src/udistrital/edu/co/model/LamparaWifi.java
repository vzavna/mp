package udistrital.edu.co.model;

public class LamparaWifi {
    private int intensidad;
    private String red;

    public LamparaWifi(int intensidad, String red) {
        this.intensidad = intensidad;
        this.red = red;
    }

    public String encender() {
        return "Encendiendo lámpara WiFi conectada a " + red +
               " con intensidad " + intensidad + ".";
    }

    public int getIntensidad() {
        return intensidad;
    }

    public void setIntensidad(int intensidad) {
        this.intensidad = intensidad;
    }

    public String getRed() {
        return red;
    }

    public void setRed(String red) {
        this.red = red;
    }
}