package udistrital.edu.co.controller;

import udistrital.edu.co.view.Vista;
import udistrital.edu.co.model.*;

public class Controller {
    private Vista vista;

    public Controller() {
        vista = new Vista();
    }

    public void run() {
        vista.mostrarInformacion("=== Sistema de Lámparas ===");

        int intensidad = vista.leerEntero("Ingrese la intensidad de la lámpara: ");
        String red = vista.leerCadenaDeTexto("Ingrese el nombre de la red WiFi: ");

        ILampara normal = new LamparaNormal(intensidad);
        ILampara recargable = new LamparaRecargable(intensidad);
        LamparaWifi lamparaWifi = new LamparaWifi(intensidad, red);
        ILampara wifiAdaptada = new LamparaWifiAdapter(lamparaWifi);

        vista.mostrarInformacion(normal.encender());
        vista.mostrarInformacion(recargable.encender());
        vista.mostrarInformacion(wifiAdaptada.encender());
    }
}