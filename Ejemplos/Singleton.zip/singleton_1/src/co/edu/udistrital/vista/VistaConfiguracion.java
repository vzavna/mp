package co.edu.udistrital.vista;

public class VistaConfiguracion {
	    public void mostrarConfiguracion(String tema, String idioma, boolean modoOscuro) {
	        System.out.println("\n=== Configuración Actual ===");
	        System.out.println("Tema: " + tema);
	        System.out.println("Idioma: " + idioma);
	        System.out.println("Modo Oscuro: " + (modoOscuro ? "Activado" : "Desactivado"));
	    }

	    public void mostrarMensaje(String mensaje) {
	        System.out.println("\n> " + mensaje);
	    }
	
}