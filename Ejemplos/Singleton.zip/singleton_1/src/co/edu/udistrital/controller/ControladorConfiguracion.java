package co.edu.udistrital.controller;

import co.edu.udistrital.model.ConfiguracionApp;
import co.edu.udistrital.vista.VistaConfiguracion;

public class ControladorConfiguracion {
    private ConfiguracionApp modelo;
    private VistaConfiguracion vista;

    public ControladorConfiguracion() {
        this.modelo = ConfiguracionApp.getInstance();
        this.vista = new VistaConfiguracion();
    }

    public void run() {
        vista.mostrarConfiguracion(
            modelo.getTema(),
            modelo.getIdioma(),
            modelo.isModoOscuro()
        );

        vista.mostrarMensaje("Cambiando configuración...");
        modelo.setTema("Oscuro");
        modelo.setIdioma("EN");
        modelo.setModoOscuro(true);

        vista.mostrarConfiguracion(
            modelo.getTema(),
            modelo.getIdioma(),
            modelo.isModoOscuro()
        );

        vista.mostrarMensaje("Obteniendo nueva instancia...");
        ConfiguracionApp nuevaInstancia = ConfiguracionApp.getInstance();
        vista.mostrarConfiguracion(
            nuevaInstancia.getTema(),
            nuevaInstancia.getIdioma(),
            nuevaInstancia.isModoOscuro()
        );
    }
}