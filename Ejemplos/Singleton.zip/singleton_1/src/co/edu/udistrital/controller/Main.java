package co.edu.udistrital.controller;

public class Main {
    public static void main(String[] args) {
        ControladorConfiguracion controlador = new ControladorConfiguracion();
        controlador.run();
    }
}
