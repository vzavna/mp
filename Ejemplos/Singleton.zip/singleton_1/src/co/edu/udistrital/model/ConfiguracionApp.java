package co.edu.udistrital.model;

public class ConfiguracionApp {
	    private static ConfiguracionApp instancia;
	    private String tema;
	    private String idioma;
	    private boolean modoOscuro;

	    private ConfiguracionApp() {
	        this.tema = "Claro";
	        this.idioma = "ES";
	        this.modoOscuro = false;
	    }

	    public static ConfiguracionApp getInstance() {
	        if (instancia == null) {
	            instancia = new ConfiguracionApp();
	        }
	        return instancia;
	    }


		public String getTema() { return tema; }
	    public void setTema(String tema) { this.tema = tema; }
	    
	    public String getIdioma() { return idioma; }
	    public void setIdioma(String idioma) { this.idioma = idioma; }
	    
	    public boolean isModoOscuro() { return modoOscuro; }
	    public void setModoOscuro(boolean modoOscuro) { this.modoOscuro = modoOscuro; }
	
}