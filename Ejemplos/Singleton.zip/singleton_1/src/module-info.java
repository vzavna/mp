/**
 * 
 */
/**
 * 
 */
module singleton_1 {
}