/**
 * 
 */
/**
 * 
 */
module singleton_2 {
}