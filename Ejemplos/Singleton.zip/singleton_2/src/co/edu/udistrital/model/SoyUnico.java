package co.edu.udistrital.model;

public class SoyUnico {
    private String nombre;
    private static SoyUnico instancia;
    
    private SoyUnico(String nombre) {
        this.nombre = nombre;
    }
    
    public static SoyUnico getInstancia(String nombre) {
        if (instancia == null) {
            instancia = new SoyUnico(nombre);
        }
        return instancia;
    }
    
    public String getNombre() {
        return nombre;
    }
    
    public void setNombre(String nombre) {
        this.nombre = nombre;
    }
}

