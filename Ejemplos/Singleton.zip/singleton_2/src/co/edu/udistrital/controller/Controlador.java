package co.edu.udistrital.controller;

import co.edu.udistrital.model.SoyUnico;
import co.edu.udistrital.vista.VistaConsola;

public class Controlador {
    private VistaConsola vista;
    private SoyUnico modelo;
    
    public Controlador() {
        vista = new VistaConsola();
    }
    
    public void run() {
        vista.mostrarMensaje("Creando primera instancia...");
        modelo = SoyUnico.getInstancia("Ricardo Moya");
        vista.mostrarMensaje("Primera instancia creada: " + modelo.getNombre());
        
        vista.mostrarMensaje("\nIntentando crear segunda instancia...");
        SoyUnico segundaInstancia = SoyUnico.getInstancia("Ramón Invarato");
        vista.mostrarMensaje("Segunda instancia (debería ser la misma): " + segundaInstancia.getNombre());
        
        vista.mostrarMensaje("\nCambiando nombre en la segunda referencia...");
        segundaInstancia.setNombre("Nombre Modificado");
        
        vista.mostrarMensaje("\nComprobando ambas referencias:");
        vista.mostrarMensaje("Primera referencia: " + modelo.getNombre());
        vista.mostrarMensaje("Segunda referencia: " + segundaInstancia.getNombre());
        
        vista.mostrarMensaje("\nPresione Enter para salir...");
        vista.leerEntrada();
    }
}
