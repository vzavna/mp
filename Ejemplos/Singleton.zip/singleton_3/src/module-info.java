/**
 * 
 */
/**
 * 
 */
module singleton_3 {
}