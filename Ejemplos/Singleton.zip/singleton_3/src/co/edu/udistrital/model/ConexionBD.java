package co.edu.udistrital.model;

public class ConexionBD {
    private static ConexionBD instancia;
    private boolean conectada;

    private ConexionBD() {
        conectada = false;
    }

    public static ConexionBD getInstancia() {
        if (instancia == null) {
            instancia = new ConexionBD();
        }
        return instancia;
    }

    public void conectar() {
        if (!conectada) {
            conectada = true;
            System.out.println("Conectando a la base de datos...");
        } else {
            System.out.println("Ya estás conectado a la base de datos.");
        }
    }

    public void desconectar() {
        if (conectada) {
            conectada = false;
            System.out.println("Desconectando de la base de datos...");
        } else {
            System.out.println("La conexión ya está cerrada.");
        }
    }

    public boolean estaConectada() {
        return conectada;
    }
}

