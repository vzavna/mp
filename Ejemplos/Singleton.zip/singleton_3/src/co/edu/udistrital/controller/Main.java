package co.edu.udistrital.controller;

public class Main {
    public static void main(String[] args) {
        Controlador controlador = new Controlador();
        controlador.run();
    }
}