package co.edu.udistrital.controller;

import co.edu.udistrital.model.ConexionBD;
import co.edu.udistrital.vista.VistaConsola;

public class Controlador {
    private VistaConsola vista;
    private ConexionBD conexion;

    public Controlador() {
        vista = new VistaConsola();
        conexion = ConexionBD.getInstancia();
    }

    public void run() {
        vista.mostrarMensaje("Probando conexión a base de datos...\n");

        vista.mostrarMensaje("Conectando por primera vez...");
        conexion.conectar();

        vista.mostrarMensaje("Intentando conectar otra vez (debería ser la misma instancia)...");
        ConexionBD otraConexion = ConexionBD.getInstancia();
        otraConexion.conectar();

        vista.mostrarMensaje("\nEstado de conexión:");
        vista.mostrarMensaje("¿Está conectada? " + conexion.estaConectada());

        vista.mostrarMensaje("\nDesconectando...");
        otraConexion.desconectar();

        vista.mostrarMensaje("¿Está conectada? " + conexion.estaConectada());

        vista.mostrarMensaje("\nPresione Enter para salir...");
        vista.leerEntrada();
    }
}