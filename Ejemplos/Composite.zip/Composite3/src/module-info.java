/**
 * 
 */
/**
 * 
 */
module Composite3 {
}