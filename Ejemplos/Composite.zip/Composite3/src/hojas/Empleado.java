package hojas;

import interfaces.ComponenteOrganizacion;

public class Empleado implements ComponenteOrganizacion {
    private String nombre;
    private String puesto;

    public Empleado(String nombre, String puesto) {
        this.nombre = nombre;
        this.puesto = puesto;
    }

    @Override
    public String getNombre() {
        return nombre;
    }

    @Override
    public int getNumeroEmpleados() {
        return 1;
    }

    @Override
    public void agregar(ComponenteOrganizacion componente) {}

    @Override
    public void remover(ComponenteOrganizacion componente) {}

    @Override
    public void mostrar(String indentacion) {
        System.out.println(indentacion + "Empleado: " + nombre + " - " + puesto);
    }
}
