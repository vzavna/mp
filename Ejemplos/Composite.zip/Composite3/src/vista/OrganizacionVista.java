package vista;

import interfaces.ComponenteOrganizacion;

public class OrganizacionVista {
    public void mostrarEstructura(ComponenteOrganizacion organizacion) {
        System.out.println("=== ESTRUCTURA ORGANIZACIONAL ===");
        organizacion.mostrar("");
        System.out.println("Total de empleados: " + organizacion.getNumeroEmpleados());
    }
}