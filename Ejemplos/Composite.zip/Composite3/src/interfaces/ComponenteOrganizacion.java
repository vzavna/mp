package interfaces;

public interface ComponenteOrganizacion {
    String getNombre();
    int getNumeroEmpleados();
    void agregar(ComponenteOrganizacion componente);
    void remover(ComponenteOrganizacion componente);
    void mostrar(String indentacion);
}