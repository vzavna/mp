package compuestos;

import java.util.ArrayList;
import interfaces.ComponenteOrganizacion;

public class Departamento implements ComponenteOrganizacion {
    private String nombre;
    private ArrayList<ComponenteOrganizacion> componentes = new ArrayList<>();

    public Departamento(String nombre) {
        this.nombre = nombre;
    }

    @Override
    public String getNombre() {
        return nombre;
    }

    @Override
    public int getNumeroEmpleados() {
        int total = 0;
        for (ComponenteOrganizacion componente : componentes) {
            total += componente.getNumeroEmpleados();
        }
        return total;
    }

    @Override
    public void agregar(ComponenteOrganizacion componente) {
        componentes.add(componente);
    }

    @Override
    public void remover(ComponenteOrganizacion componente) {
        componentes.remove(componente);
    }

    @Override
    public void mostrar(String indentacion) {
        System.out.println(indentacion + "Departamento: " + nombre + " (Empleados: " + getNumeroEmpleados() + ")");
        for (ComponenteOrganizacion componente : componentes) {
            componente.mostrar(indentacion + "  ");
        }
    }
}