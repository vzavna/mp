package controlador;

import compuestos.Departamento;
import hojas.Empleado;
import vista.OrganizacionVista;

public class EmpresaControlador {
 public static void main(String[] args) {
     Departamento empresa = new Departamento("Software Dev's Inc.");
     
     Departamento desarrollo = new Departamento("Desarrollo");
     desarrollo.agregar(new Empleado("Ana López", "Desarrolladora Senior"));
     desarrollo.agregar(new Empleado("Carlos Ruiz", "Desarrollador Junior"));
     
     Departamento ventas = new Departamento("Ventas");
     ventas.agregar(new Empleado("Marta Gómez", "Gerente de Ventas"));
     ventas.agregar(new Empleado("Pedro Sánchez", "Ejecutivo de Ventas"));
     
     Departamento rrhh = new Departamento("Recursos Humanos");
     rrhh.agregar(new Empleado("Laura Martínez", "Gerente de RH"));
     
     empresa.agregar(desarrollo);
     empresa.agregar(ventas);
     empresa.agregar(rrhh);
     
     OrganizacionVista vista = new OrganizacionVista();
     vista.mostrarEstructura(empresa);
 }
}