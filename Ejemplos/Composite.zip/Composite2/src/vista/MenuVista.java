package vista;

import interfaces.ComponenteMenu;

public class MenuVista {
    public void mostrarMenuCompleto(ComponenteMenu menu) {
        System.out.println("=== MENÚ DEL RESTAURANTE ===");
        menu.mostrar();
        System.out.println("Precio total del menú: $" + menu.getPrecio());
    }
}