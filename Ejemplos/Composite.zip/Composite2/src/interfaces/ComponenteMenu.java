package interfaces;

public interface ComponenteMenu {
    String getNombre();
    double getPrecio();
    void agregar(ComponenteMenu componente);
    void remover(ComponenteMenu componente);
    void mostrar();
}