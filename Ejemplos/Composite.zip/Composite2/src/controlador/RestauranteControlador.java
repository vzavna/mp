package controlador;

import compuestos.Menu;
import hojas.Plato;
import vista.MenuVista;

public class RestauranteControlador {
    public static void main(String[] args) {
        Menu menuPrincipal = new Menu("Menú Principal", "Nuestra selección de platos principales");
        
        Menu menuEntradas = new Menu("Entradas", "Deliciosos aperitivos");
        menuEntradas.agregar(new Plato("Ensalada César", "Ensalada con aderezo César", 25000));
        menuEntradas.agregar(new Plato("Bruschetta", "Pan tostado con tomate y albahaca", 27500));
        
        Menu menuPlatosFuertes = new Menu("Platos Fuertes", "Nuestras especialidades");
        menuPlatosFuertes.agregar(new Plato("Filete Mignon", "Filete de res 200g con guarnición", 47000));
        menuPlatosFuertes.agregar(new Plato("Salmón a la parrilla", "Salmón fresco con salsa de limón", 50000));
        
        menuPrincipal.agregar(menuEntradas);
        menuPrincipal.agregar(menuPlatosFuertes);
        
        MenuVista vista = new MenuVista();
        vista.mostrarMenuCompleto(menuPrincipal);
    }
}