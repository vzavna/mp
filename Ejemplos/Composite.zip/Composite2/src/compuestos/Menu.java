package compuestos;

import java.util.ArrayList;
import interfaces.ComponenteMenu;

public class Menu implements ComponenteMenu {
    private String nombre;
    private String descripcion;
    private ArrayList<ComponenteMenu> items = new ArrayList<>();

    public Menu(String nombre, String descripcion) {
        this.nombre = nombre;
        this.descripcion = descripcion;
    }

    @Override
    public String getNombre() {
        return nombre;
    }

    @Override
    public double getPrecio() {
        double total = 0;
        for (ComponenteMenu item : items) {
            total += item.getPrecio();
        }
        return total;
    }

    @Override
    public void agregar(ComponenteMenu componente) {
        items.add(componente);
    }

    @Override
    public void remover(ComponenteMenu componente) {
        items.remove(componente);
    }

    @Override
    public void mostrar() {
        System.out.println("\n" + nombre + ": " + descripcion);
        for (ComponenteMenu item : items) {
            item.mostrar();
        }
    }
}
