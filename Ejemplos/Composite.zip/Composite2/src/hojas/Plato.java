package hojas;

import interfaces.ComponenteMenu;

public class Plato implements ComponenteMenu {
    private String nombre;
    private String descripcion;
    private double precio;

    public Plato(String nombre, String descripcion, double precio) {
        this.nombre = nombre;
        this.descripcion = descripcion;
        this.precio = precio;
    }

    @Override
    public String getNombre() {
        return nombre;
    }

    @Override
    public double getPrecio() {
        return precio;
    }

    @Override
    public void agregar(ComponenteMenu componente) {}

    @Override
    public void remover(ComponenteMenu componente) {}

    @Override
    public void mostrar() {
        System.out.println("  " + nombre + " - " + descripcion + " - $" + precio);
    }
}