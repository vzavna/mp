/**
 * 
 */
/**
 * 
 */
module Composite2 {
}