package interfaces;

public interface ComponenteBiblioteca {
    String getNombre();
    int getNumeroPaginas();
    void agregar(ComponenteBiblioteca componente);
    void remover(ComponenteBiblioteca componente);
}