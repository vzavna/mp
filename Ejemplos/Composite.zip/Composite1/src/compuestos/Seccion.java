package compuestos;

import java.util.ArrayList;
import interfaces.ComponenteBiblioteca;

public class Seccion implements ComponenteBiblioteca {
    private String nombre;
    private ArrayList<ComponenteBiblioteca> componentes = new ArrayList<>();

    public Seccion(String nombre) {
        this.nombre = nombre;
    }

    @Override
    public String getNombre() {
        return nombre;
    }

    @Override
    public int getNumeroPaginas() {
        int total = 0;
        for (ComponenteBiblioteca componente : componentes) {
            total += componente.getNumeroPaginas();
        }
        return total;
    }

    @Override
    public void agregar(ComponenteBiblioteca componente) {
        componentes.add(componente);
    }

    @Override
    public void remover(ComponenteBiblioteca componente) {
        componentes.remove(componente);
    }
}