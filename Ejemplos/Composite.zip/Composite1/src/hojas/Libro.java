package hojas;

import interfaces.ComponenteBiblioteca;

public class Libro implements ComponenteBiblioteca {
    private String nombre;
    private int paginas;

    public Libro(String nombre, int paginas) {
        this.nombre = nombre;
        this.paginas = paginas;
    }

    @Override
    public String getNombre() {
        return nombre;
    }

    @Override
    public int getNumeroPaginas() {
        return paginas;
    }

    @Override
    public void agregar(ComponenteBiblioteca componente) {}

    @Override
    public void remover(ComponenteBiblioteca componente) {}
}
