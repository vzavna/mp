/**
 * 
 */
/**
 * 
 */
module Composite1 {
}