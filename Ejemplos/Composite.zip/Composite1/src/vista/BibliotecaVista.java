package vista;

public class BibliotecaVista {
    public void mostrarInformacion(String nombre, int paginas) {
        System.out.println("Elemento: " + nombre + ", Páginas: " + paginas);
    }
}