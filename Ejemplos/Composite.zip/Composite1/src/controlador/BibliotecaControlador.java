package controlador;

import compuestos.Seccion;
import hojas.Libro;
import vista.BibliotecaVista;

public class BibliotecaControlador {
    public static void main(String[] args) {
        Seccion seccionCiencia = new Seccion("Ciencia");
        Seccion seccionFiccion = new Seccion("Ficción");
        
        seccionCiencia.agregar(new Libro("Breves respuestas a grandes preguntas", 256));
        seccionCiencia.agregar(new Libro("El universo en una cáscara de nuez", 216));
        
        seccionFiccion.agregar(new Libro("1984", 328));
        seccionFiccion.agregar(new Libro("Fahrenheit 451", 256));
        
        Seccion biblioteca = new Seccion("Biblioteca El Tintal");
        biblioteca.agregar(seccionCiencia);
        biblioteca.agregar(seccionFiccion);
        
        BibliotecaVista vista = new BibliotecaVista();
        vista.mostrarInformacion(biblioteca.getNombre(), biblioteca.getNumeroPaginas());
    }
}