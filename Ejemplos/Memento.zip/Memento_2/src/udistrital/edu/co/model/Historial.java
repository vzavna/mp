package udistrital.edu.co.model;

import java.util.Stack;

public class Historial {
    private Stack<Memento> pila = new Stack<>();

    public void guardar(Memento m) {
        pila.push(m);
    }

    public Memento deshacer() {
        if (!pila.isEmpty()) {
            return pila.pop();
        }
        return new Memento("");
    }
}