package udistrital.edu.co.model;

public class BlocNotas {
    private String texto;

    public void setTexto(String texto) {
        this.texto = texto;
    }

    public String getTexto() {
        return texto;
    }

    public Memento crearMemento() {
        return new Memento(texto);
    }

    public void restaurar(Memento m) {
        this.texto = m.getEstado();
    }
}