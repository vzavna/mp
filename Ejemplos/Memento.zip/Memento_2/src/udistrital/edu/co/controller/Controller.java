package udistrital.edu.co.controller;

import udistrital.edu.co.model.BlocNotas;
import udistrital.edu.co.model.Historial;
import udistrital.edu.co.view.VistaConsola;

public class Controller {
    private VistaConsola vista;

    public Controller() {
        vista = new VistaConsola();
    }

    public void run() {
        BlocNotas bloc = new BlocNotas();
        Historial historial = new Historial();

        bloc.setTexto("Hola");
        historial.guardar(bloc.crearMemento());

        bloc.setTexto("Hola mundo");
        historial.guardar(bloc.crearMemento());

        bloc.setTexto("Hola mundo cruel");
        vista.mostrarInformacion("Texto actual: " + bloc.getTexto());

        bloc.restaurar(historial.deshacer());
        vista.mostrarInformacion("Deshacer: " + bloc.getTexto());

        bloc.restaurar(historial.deshacer());
        vista.mostrarInformacion("Deshacer otra vez: " + bloc.getTexto());
    }
}