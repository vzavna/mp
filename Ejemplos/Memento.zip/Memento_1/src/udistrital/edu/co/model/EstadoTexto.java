package udistrital.edu.co.model;

public class EstadoTexto {
    private String contenido;

    public EstadoTexto(String contenido) {
        this.contenido = contenido;
    }

    public String getContenido() {
        return contenido;
    }
}