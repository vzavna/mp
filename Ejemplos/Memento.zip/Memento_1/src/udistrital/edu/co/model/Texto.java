package udistrital.edu.co.model;

public class Texto {
    private String contenido;

    public Texto() {
        this.contenido = "";
    }

    public void escribir(String nuevo) {
        this.contenido += nuevo;
    }

    public void restaurar(EstadoTexto m) {
        this.contenido = m.getContenido();
    }

    public EstadoTexto guardar() {
        return new EstadoTexto(contenido);
    }

    public String getContenido() {
        return contenido;
    }
}