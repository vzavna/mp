package udistrital.edu.co.model;

import java.util.Stack;

public class Historial {
    private Stack<EstadoTexto> estados = new Stack<>();

    public void guardarEstado(EstadoTexto estado) {
        estados.push(estado);
    }

    public void borrarUltimo() {
        if (!estados.isEmpty()) {
            estados.pop();
        }
    }

    public EstadoTexto obtenerUltimo() {
        return estados.isEmpty() ? null : estados.peek();
    }
}