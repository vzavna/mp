package udistrital.edu.co.controller;

import udistrital.edu.co.model.EstadoTexto;
import udistrital.edu.co.model.Historial;
import udistrital.edu.co.model.Texto;
import udistrital.edu.co.view.VistaConsola;

public class Controller {
    private VistaConsola vista;

    public Controller() {
        vista = new VistaConsola();
    }

    public void run() {
        Texto texto = new Texto();
        Historial historial = new Historial();

        boolean salir = false;
        while (!salir) {
            vista.mostrarInformacion("\n1. Escribir\n2. Guardar estado\n3. Deshacer\n4. Ver texto\n5. Salir");
            String opcion = vista.leerCadenaDeTexto("Opción: ");

            switch (opcion) {
                case "1":
                    String linea = vista.leerCadenaDeTexto("Escribe algo: ");
                    texto.escribir(linea);
                    break;
                case "2":
                    historial.guardarEstado(texto.guardar());
                    vista.mostrarInformacion("Estado guardado.");
                    break;
                case "3":
                    EstadoTexto anterior = historial.obtenerUltimo();
                    if (anterior != null) {
                        texto.restaurar(anterior);
                        historial.borrarUltimo();
                        vista.mostrarInformacion("Estado anterior restaurado.");
                    } else {
                        vista.mostrarInformacion("No hay estados para restaurar.");
                    }
                    break;
                case "4":
                    vista.mostrarInformacion("Contenido actual: " + texto.getContenido());
                    break;
                case "5":
                    salir = true;
                    break;
                default:
                    vista.mostrarInformacion("Opción inválida.");
            }
        }
    }
}