package udistrital.edu.co.controller;

import udistrital.edu.co.model.CajaFuerte;
import udistrital.edu.co.model.Seguridad;
import udistrital.edu.co.view.VistaConsola;

public class Controller {
    private VistaConsola vista;

    public Controller() {
        vista = new VistaConsola();
    }

    public void run() {
        CajaFuerte caja = new CajaFuerte();
        Seguridad seguridad = new Seguridad();

        caja.setClave("1234");
        seguridad.guardar(caja.guardar());

        caja.setClave("5678");
        seguridad.guardar(caja.guardar());

        vista.mostrarInformacion("Clave actual: " + caja.getClave());

        caja.restaurar(seguridad.deshacer());
        vista.mostrarInformacion("Clave restaurada: " + caja.getClave());
    }
}