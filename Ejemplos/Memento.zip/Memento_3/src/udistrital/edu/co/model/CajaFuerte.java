package udistrital.edu.co.model;

public class CajaFuerte {
    private String clave;

    public void setClave(String clave) {
        this.clave = clave;
    }

    public String getClave() {
        return clave;
    }

    public Memento guardar() {
        return new Memento(clave);
    }

    public void restaurar(Memento m) {
        this.clave = m.getEstado();
    }
}