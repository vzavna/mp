package udistrital.edu.co.controller;

import udistrital.edu.co.view.VistaConsola;
import udistrital.edu.co.model.handler.*;

public class Controller {
    private VistaConsola vista;

    public Controller() {
        this.vista = new VistaConsola();
    }

    public void run() {
        SoporteInterfaz basico = new SoporteBasico();
        SoporteInterfaz tecnico = new SoporteTecnico();
        SoporteInterfaz especializado = new SoporteEspecializado();

        basico.setSiguiente(tecnico);
        tecnico.setSiguiente(especializado);

        String solicitud = vista.leerCadenaDeTexto("Describe tu problema (Contraseña, conexion, otro): ");
        basico.atender(solicitud);
    }
}