package udistrital.edu.co.model.handler;

public class SoporteBasico implements SoporteInterfaz {
    private SoporteInterfaz siguiente;

    @Override
    public void setSiguiente(SoporteInterfaz soporte) {
        this.siguiente = soporte;
    }

    @Override
    public void atender(String solicitud) {
        if (solicitud.contains("contraseña")) {
            System.out.println("Soporte básico atendió la solicitud.");
        } else if (siguiente != null) {
            siguiente.atender(solicitud);
        }
    }
}