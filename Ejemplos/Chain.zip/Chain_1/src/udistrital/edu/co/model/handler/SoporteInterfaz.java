package udistrital.edu.co.model.handler;

public interface SoporteInterfaz {
    void setSiguiente(SoporteInterfaz soporte);
    void atender(String solicitud);
}