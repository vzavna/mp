package udistrital.edu.co.model.handler;

public class SoporteTecnico implements SoporteInterfaz {
    private SoporteInterfaz siguiente;

    @Override
    public void setSiguiente(SoporteInterfaz soporte) {
        this.siguiente = soporte;
    }

    @Override
    public void atender(String solicitud) {
        if (solicitud.contains("conexion")) {
            System.out.println("Soporte técnico resolvió el problema.");
        } else if (siguiente != null) {
            siguiente.atender(solicitud);
        }
    }
}