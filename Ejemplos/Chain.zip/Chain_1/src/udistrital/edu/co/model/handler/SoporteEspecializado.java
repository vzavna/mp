package udistrital.edu.co.model.handler;

public class SoporteEspecializado implements SoporteInterfaz {
    private SoporteInterfaz siguiente;

    @Override
    public void setSiguiente(SoporteInterfaz soporte) {
        this.siguiente = soporte;
    }

    @Override
    public void atender(String solicitud) {
        System.out.println("Soporte especializado se encargará de la solicitud.");
    }
}