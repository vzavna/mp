package udistrital.edu.co.model;

public interface Evaluador {
    void setSiguiente(Evaluador siguiente);
    void evaluar(String tipo);
}