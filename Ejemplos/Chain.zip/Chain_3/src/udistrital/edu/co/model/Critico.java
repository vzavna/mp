package udistrital.edu.co.model;

public class Critico implements Evaluador {
    private Evaluador siguiente;

    public void setSiguiente(Evaluador siguiente) {
        this.siguiente = siguiente;
    }

    public void evaluar(String tipo) {
        if (tipo.equalsIgnoreCase("interpretacion")) {
            System.out.println("Crítico ofrece su interpretación de la obra.");
        } else {
            System.out.println("No se puede evaluar ese tipo.");
        }
    }
}