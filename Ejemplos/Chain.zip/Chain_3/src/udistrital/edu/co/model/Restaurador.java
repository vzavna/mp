package udistrital.edu.co.model;

public class Restaurador implements Evaluador {
    private Evaluador siguiente;

    public void setSiguiente(Evaluador siguiente) {
        this.siguiente = siguiente;
    }

    public void evaluar(String tipo) {
        if (tipo.equalsIgnoreCase("daño")) {
            System.out.println("Restaurador analiza los daños.");
        } else if (siguiente != null) {
            siguiente.evaluar(tipo);
        }
    }
}