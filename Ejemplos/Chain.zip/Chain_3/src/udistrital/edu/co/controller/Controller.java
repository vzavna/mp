package udistrital.edu.co.controller;

import udistrital.edu.co.view.VistaConsola;
import udistrital.edu.co.model.*;

public class Controller {
	private VistaConsola vista;

    public Controller() {
        vista = new VistaConsola();
    }

    public void run() {
        Evaluador curador = new Curador();
        Evaluador restaurador = new Restaurador();
        Evaluador critico = new Critico();

        curador.setSiguiente(restaurador);
        restaurador.setSiguiente(critico);

        String tipo = vista.leerCadenaDeTexto("Ingrese tipo de revisión (autenticidad, daño, interpretacion): ");
        curador.evaluar(tipo);
    }
}
