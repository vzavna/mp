package udistrital.edu.co.model;

public interface ProfesionalDental {
	void setSiguiente(ProfesionalDental siguiente);
    void atender(String caso);
}
