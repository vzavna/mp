package udistrital.edu.co.model;

public class Cirujano implements ProfesionalDental {
    private ProfesionalDental siguiente;

    public void setSiguiente(ProfesionalDental siguiente) {
        this.siguiente = siguiente;
    }

    public void atender(String caso) {
        if (caso.equalsIgnoreCase("extraccion")) {
            System.out.println("Cirujano realiza la extracción.");
        } else {
            System.out.println("Caso no reconocido.");
        }
    }
}