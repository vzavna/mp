package udistrital.edu.co.model;

public class Higienista implements ProfesionalDental {
    private ProfesionalDental siguiente;

    public void setSiguiente(ProfesionalDental siguiente) {
        this.siguiente = siguiente;
    }

    public void atender(String caso) {
        if (caso.equalsIgnoreCase("limpieza")) {
            System.out.println("Higienista realiza la limpieza dental.");
        } else if (siguiente != null) {
            siguiente.atender(caso);
        } else {
            System.out.println("Nadie pudo atender el caso.");
        }
    }
}