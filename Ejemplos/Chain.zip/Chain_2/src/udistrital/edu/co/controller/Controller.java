package udistrital.edu.co.controller;

import udistrital.edu.co.view.VistaConsola;
import udistrital.edu.co.model.*;

public class Controller {
	private VistaConsola vista;

    public Controller() {
        vista = new VistaConsola();
    }

    public void run() {
        ProfesionalDental higienista = new Higienista();
        ProfesionalDental odontologo = new Odontologo();
        ProfesionalDental cirujano = new Cirujano();

        higienista.setSiguiente(odontologo);
        odontologo.setSiguiente(cirujano);

        String caso = vista.leerCadenaDeTexto("Ingrese tipo de caso (limpieza, caries, extraccion): ");
        higienista.atender(caso);
    }
}
