package udistrital.edu.co.view;

import java.util.Scanner;

public class VistaConsola {
    private Scanner scanner;

    public VistaConsola() {
        scanner = new Scanner(System.in);
    }

    public String leerCadenaDeTexto(String mensaje) {
        System.out.print(mensaje);
        return scanner.nextLine();
    }
}